﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities
{
    public class QuestionEntity
    {
        public int QuestionId { get; set; }
        public string Text { get; set; }
        public QuestionCategoryEntity Category { get; set; }
        public TypeEntity Type { get; set; }
        public List<SectorOptionsEntity> QuestionOptions { get; set; }
    }
}
