﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace BusinessEntities
{
    public class UserEntity
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string HashedPassword { get; set; }
        public string UserName { get; set; }
        public OrganizationEntity organization { get; set; }
        public List<EventEntity> Events { get; set; }
        public string Token { get; set; }
        public string GUID { get; set; }
        public string DeviceId { get; set; }
        public bool isDeviceIdChanged { get; set; }
    }
}
