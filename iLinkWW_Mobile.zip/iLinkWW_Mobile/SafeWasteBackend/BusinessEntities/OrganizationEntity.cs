﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities
{
    public class OrganizationEntity
    {
        public string Code { get; set; }
        public int SectorId { get; set; }
        public int NegativeSegementImpact { get; set; }
        public int RatingDifference { get; set; }
        public int MaxEvents { get; set; }
    }
}
