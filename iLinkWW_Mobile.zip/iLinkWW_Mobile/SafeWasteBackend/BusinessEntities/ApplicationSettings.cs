﻿using System;

namespace BusinessEntities
{
    public class ApplicationSettings
    {
        public string ConnectionString { get; set; }
        public string Secret { get; set; }
    }
}
