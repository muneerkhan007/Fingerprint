﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities
{
    public class TypeEntity
    {
        public int TypeId { get; set; }
        public string TypeName { get; set; }
        public bool IsMultipleChoice { get; set; }
    }
}
