﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities
{
    public class SectorEntity
    {
        public int Sectorid { get; set; }
        public string SectorName { get; set; }
    }
}
