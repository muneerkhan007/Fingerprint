﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities
{
    public class EventEntity
    {
        public int EventId { get; set; }
        public int ID { get; set; }
        public DateTime EventDate { get; set; }
        public EventTypeEntity EventType { get; set; }
        public UserEntity User { get; set; }
        public List<EventAnswerEntity> Answers { get; set; }
        public string SentimentalValue { get; set; }
    }

    public class EventTypeEntity
    {
        public int EventTypeId { get; set; }
        public string EventType { get; set; }
        public StressLevel Value { get; set; }
    }
}
