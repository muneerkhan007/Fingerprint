﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities
{
    public class SectorOptionsEntity
    {
        public int OptionId { get; set; }
        public SectorEntity SectorEntity { get; set; }
        public string OptionText { get; set; }
        public int? Value { get; set; }
        public SentimentalValue SentimentalValue { get; set; }
    }

    public enum StressLevel
    {
        UNKNOWN = -1,
        MINOR = 1,
        MILD = 2,
        AVERAGE = 3,
        INTENSE = 4,
        SEVERE = 5
    }

    public enum SentimentalValue
    {
        Unknown = 0,
        positive = 1,
        neutral = 2,
        negative = 3
    }
}
