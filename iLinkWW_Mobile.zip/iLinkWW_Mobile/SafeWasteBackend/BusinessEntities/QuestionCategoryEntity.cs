﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities
{
    public class QuestionCategoryEntity
    {
        public int Id { get; set; }
        public string CategoryName { get; set; }
    }
}
