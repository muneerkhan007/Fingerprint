﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities
{
    public class EventAnswerEntity
    {
        public int ID { get; set; }
        public QuestionEntity Question { get; set; }
        
        public SectorOptionsEntity Option { get; set; }
        
    }
}
