﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using BusinessEntities;
using BusinessObjects;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SafeWasteWebAPI.Controllers
{
    [Route("api/DataSync")]
    [ApiController]
    public class DataSyncController : ControllerBase
    {
        private IOptions<ApplicationSettings> _settings;
        public DataSyncController(IOptions<ApplicationSettings> settings)
        {
            _settings = settings;
        }

        // GET: api/DataSync/0
        [HttpGet()]
        public IActionResult SyncData([FromQueryAttribute(Name = "UserId")] int UserId, [FromQueryAttribute(Name = "FromVersion")] int fromVersion)
        {
            JsonDocument result = null;

            UtilBO utilBO = new UtilBO(_settings.Value.ConnectionString);
            string strJSON = utilBO.SyncData(UserId, fromVersion);

            if (!string.IsNullOrEmpty(strJSON))
                result = JsonDocument.Parse(strJSON);
            else
                result = JsonDocument.Parse("[]");

            return Ok(result.RootElement);
        }
    }
}
