﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BusinessEntities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using SafeWasteWebAPI.Models;

namespace SafeWasteWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private IOptions<ApplicationSettings> _settings;

        public LoginController(IOptions<ApplicationSettings> settings)
        {
            _settings = settings;
        }

        [HttpPut]
        public IActionResult Login(UserModel user)
        {
           UserIdModel userIdModel =  user.Login(_settings.Value.ConnectionString) ;

            if (userIdModel != null && userIdModel.Id > 0)
                return Ok(userIdModel);
            else
                return Unauthorized();
        }
    }
}
