﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BusinessEntities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using SafeWasteWebAPI.Models;

namespace SafeWasteWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrganizationController : ControllerBase
    {
        private IOptions<ApplicationSettings> _settings;
        public OrganizationController(IOptions<ApplicationSettings> settings)
        {
            _settings = settings;
        }

        [HttpGet]
        [Route("{code}")]
        [Authorize]
        public IActionResult GetOrganizationByCode(string code)
        {
            if(String.IsNullOrEmpty(code))
                return BadRequest(new ErrorModel("Code is not valid"));

            OrganizationModel organization = new OrganizationModel(code,_settings.Value.ConnectionString);

            if(organization.Sector == null || organization.Sector.SectorId <=0)
                return StatusCode(500, new ErrorModel("Internal server error occured"));


            SectorModel sector = new SectorModel(organization.Sector.SectorId,_settings.Value.ConnectionString);

            if(sector == null || sector.SectorId <=0 || String.IsNullOrEmpty(sector.SectorName) )
                return StatusCode(500, new ErrorModel("Internal server error occured"));

             List<CategoryModel> categoryModels =  sector.GetCategorizedQuestions();

            return Ok(categoryModels);
        }

        [HttpGet("all/{code}")]
        public IActionResult GetAllEvents(string code)
        {
            OrganizationModel org = new OrganizationModel(code, _settings.Value.ConnectionString);
            List<EventEntity> Events = org.GetAllEvents();


            return Ok(Events);
        }

        [HttpGet]
        [Route("EventType/{code}")]
        [Authorize]
        public IActionResult GetOrganizationEventTypes(string code)
        {
            if (String.IsNullOrEmpty(code))
                return BadRequest(new ErrorModel("Code is not valid"));

            OrganizationModel organization = new OrganizationModel(code, _settings.Value.ConnectionString);

            List<EventTypeModel> EventTypes = organization.GetEventTypes();

            return Ok(EventTypes);
        }
    }
}
