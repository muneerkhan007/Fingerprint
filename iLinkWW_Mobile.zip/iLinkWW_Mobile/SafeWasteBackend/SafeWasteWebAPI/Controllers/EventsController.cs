﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Threading.Tasks;
using BusinessEntities;
using BusinessObjects;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using SafeWasteWebAPI.Models;

namespace SafeWasteWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : ControllerBase
    {
        private IOptions<ApplicationSettings> _settings;
        public EventsController(IOptions<ApplicationSettings> settings)
        {
            _settings = settings;
        }

        [HttpPost]
        [Route("")]
        [Authorize]
        public IActionResult PostEvent(EventModel eventModel)
        {
            if (!ModelState.IsValid)
                return BadRequest(new ErrorModel("Input not proper"));
            int eventID = -1;
            try
            { 

                var user = (UserModel)HttpContext.Items["User"];

                eventID = eventModel.Save(user,_settings.Value.ConnectionString);
                if (eventID <= 0)
                    return StatusCode(500, new ErrorModel("Internal Server Error"));
            }
            catch
            {
                return StatusCode(500, new ErrorModel("Internal Server Error"));
            }


            return Ok(new EventReturnModel(eventID));
        }
    }
}
