﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BusinessEntities;
using BusinessObjects;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using SafeWasteWebAPI.Models;
using SafeWasteWebAPI.Utils;
using Serilog;

namespace SafeWasteWebAPI.Controllers
{
    [Route("api/users")]
    [ApiController]
    public class UserController : ControllerBase
    {

        private IOptions<ApplicationSettings> _settings;
        public UserController(IOptions<ApplicationSettings> settings)
        {
            _settings = settings;
        }

        [HttpGet("")]
        [Authorize]
        public IActionResult GetUsers()
        {
            return Ok();
        }
        
        [HttpGet("{name}")]
        public IActionResult GetUserByName(string name)
        {
            UserModel user = null;
            try
            {
                if (String.IsNullOrEmpty(name))
                    return BadRequest(new ErrorModel("Name is not valid"));

                user = new UserModel(name, _settings.Value.ConnectionString, false);
                if (user.Id <= 0)
                    return NotFound();

                

                return Ok();

            }
            catch (Exception ex)
            {
                Log.ForContext("Get", typeof(UserController).FullName).Error("An exception occurred while getting the User with name " + name);
                throw ex;
            }

        }
        [HttpPost]
        public IActionResult RegisterUser(UserModel user)
        {
            
            if (!ModelState.IsValid)
                return BadRequest( new ErrorModel("Data not proper. Please enter the whole data"));

            if (user.Organization == null || String.IsNullOrEmpty(user.Organization.code))
                return BadRequest(new ErrorModel("Organization code not present"));

            OrganizationModel orgModel = new OrganizationModel(user.Organization.code, _settings.Value.ConnectionString);
            if (string.IsNullOrEmpty(orgModel.code))
                return BadRequest(new ErrorModel("Please provide a valid organization code"));



            Log.ForContext("Get", typeof(UserController).FullName).Information("Registering a new user " + user.UserName);

            UserModel existUser = new UserModel(user.UserName, _settings.Value.ConnectionString, false);
            if (existUser.Id > 0)
                return BadRequest(new ErrorModel("User name already exists"));
            UserIdModel uModel = new UserIdModel();
            user.Token = new JWTUtil(_settings).generateJwtToken(user);
            uModel = user.Save(_settings.Value.ConnectionString);


            if (uModel.Id <= 0)
                return StatusCode(500, new ErrorModel("Internal server error occured"));
            uModel.Token = user.Token;


            return Ok(uModel);
        }

        [HttpGet("profile-uri/{userName}")]
        public IActionResult GenerateProfileURI(string userName)
        {
            if (string.IsNullOrEmpty(userName))
                return BadRequest(new ErrorModel("Username was not provided"));

            UserModel user = new UserModel(userName, _settings.Value.ConnectionString, false);

            if (user == null || user.Id == 0)
                return BadRequest(new ErrorModel("User does not exist"));

            user.generateGUID();

            return Ok(new { profileReportURI = user.GUID });
        }

        [HttpGet("profile-report-questions/{guid}")]
        public IActionResult GetAllQuestionsWithAnswers(string GUID)
        {
            if (string.IsNullOrEmpty(GUID))
                return BadRequest(new ErrorModel("User's GUID was not provided"));

            UserModel user = new UserModel(GUID, _settings.Value.ConnectionString, true);

            if (user == null || user.Id == 0)
                return BadRequest(new ErrorModel("Requested user does not exist"));
            else
                user.GetAllQuestionsWithAnswers();

            return Ok(user.Events);
        }
    }
}
