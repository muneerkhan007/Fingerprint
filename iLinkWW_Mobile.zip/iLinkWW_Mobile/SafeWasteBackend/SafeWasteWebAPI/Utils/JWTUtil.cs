﻿using BusinessEntities;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using SafeWasteWebAPI.Models;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace SafeWasteWebAPI.Utils
{
    public class JWTUtil
    {
        private IOptions<ApplicationSettings> _settings;
        public JWTUtil(IOptions<ApplicationSettings> settings)
        {
            _settings = settings;
        }

        public string generateJwtToken(UserModel user)
        {
            // generate token that is valid for 7 days
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_settings.Value.Secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[] { new Claim("name", user.UserName.ToString()) }),
                Expires = DateTime.Now.AddYears(3),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}
