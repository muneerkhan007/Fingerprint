﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SafeWasteWebAPI.Models
{
    public class ErrorModel
    {
        public ErrorModel(string description)
        {
            this.errorDescription = description;
        }
        public string errorDescription { get; set; }
    }
}
