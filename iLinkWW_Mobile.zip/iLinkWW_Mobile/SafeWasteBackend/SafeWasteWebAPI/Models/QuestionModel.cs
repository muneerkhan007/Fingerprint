﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SafeWasteWebAPI.Models
{
    public class QuestionModel
    {

        public int QuestionId { get; set; }
        public string Text { get; set; }
        public TypeModel QuestionType { get; set; }
        public List<QuestionOptionsModel> QuestionOptions { get; set; }
    }
}
