﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SafeWasteWebAPI.Models
{
    public class TypeModel
    {
        public int TypeId { get; set; }
        public string TypeName { get; set; }
        public bool isMultipleChoice { get; set; }

    }
}
