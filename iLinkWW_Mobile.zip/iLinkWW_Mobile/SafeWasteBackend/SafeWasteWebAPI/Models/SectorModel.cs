﻿using BusinessEntities;
using BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SafeWasteWebAPI.Models
{
    public class SectorModel
    {
        public int SectorId { get; set; }
        public string SectorName { get; set; }

        public SectorModel()
        {
            this.SectorId = 0;
            this.SectorName = null;
        }
        SectorBO sectorBO = null;
        public SectorModel(int sectorId,string connectionString)
        {
            this.SectorId = sectorId;
            sectorBO = new SectorBO(sectorId, connectionString);
            SectorEntity sectorEntity = sectorBO.Get();
            if (sectorEntity != null)
                this.SectorName = sectorEntity.SectorName;

        }

        public List<CategoryModel> GetCategorizedQuestions()
        {
            List<CategoryModel> categoryModels = new List<CategoryModel>();
            List<QuestionEntity> questionEntities =  sectorBO.GetSectorQuestions();

            List<IGrouping<int, QuestionEntity>> lstCategoryQuestions  = questionEntities.Where(x => x.Category != null).GroupBy(x => x.Category.Id).ToList();

            foreach(IGrouping<int,QuestionEntity> questionEntityGroup in lstCategoryQuestions)
            {
                if (questionEntityGroup.Key <= 0)
                    continue;
                CategoryModel categoryModel = new CategoryModel();
                categoryModel.CategoryId = questionEntityGroup.Key;
                
                List<QuestionEntity> questions = questionEntityGroup.ToList();
                categoryModel.CategoryName = questions[0].Category.CategoryName;
                categoryModel.Questions = new List<QuestionModel>();
                foreach(QuestionEntity questionEntity in questions)
                {
                    QuestionModel qModel = new QuestionModel();
                    qModel.QuestionId = questionEntity.QuestionId;
                    if(questionEntity.Type != null)
                    { 
                        qModel.QuestionType = new TypeModel();
                        qModel.QuestionType.TypeId = questionEntity.Type.TypeId;
                        qModel.QuestionType.TypeName = questionEntity.Type.TypeName;
                        qModel.QuestionType.isMultipleChoice = questionEntity.Type.IsMultipleChoice;
                    }
                    qModel.Text = questionEntity.Text;
                    if(questionEntity.QuestionOptions != null )
                    { 
                        qModel.QuestionOptions = new List<QuestionOptionsModel>();
                        foreach(SectorOptionsEntity sectorOptionsEntity in questionEntity.QuestionOptions)
                        {
                            if(sectorOptionsEntity != null && sectorOptionsEntity.OptionId > 0)
                            {
                                QuestionOptionsModel questionOptionsModel = new QuestionOptionsModel();
                                questionOptionsModel.OptionText = sectorOptionsEntity.OptionText;
                                questionOptionsModel.Value = sectorOptionsEntity.Value;
                                questionOptionsModel.OptionId = sectorOptionsEntity.OptionId;
                                qModel.QuestionOptions.Add(questionOptionsModel);
                            }
                        }
                    }
                    categoryModel.Questions.Add(qModel);
                }
                categoryModels.Add(categoryModel);
            }


            return categoryModels;

        }
    }
}
