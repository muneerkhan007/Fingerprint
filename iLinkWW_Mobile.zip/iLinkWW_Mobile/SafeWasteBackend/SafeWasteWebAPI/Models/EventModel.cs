﻿using BusinessEntities;
using BusinessObjects;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;

namespace SafeWasteWebAPI.Models
{
    public class EventModel
    {
        public int EventId { get; set; }
        public int ID { get; set; }

        [Required]
        public DateTime EventDate { get; set; }
        
        public EventTypeModel EventType { get; set; }
        

        [Required]
        public List<EventQuestionAnswerModel> QuestionAnswerModels { get; set; }

        public EventModel()
        {

        }
        
        EventBO eventBO = null;
        internal int Save(UserModel user,string connectionstring)
        {
            EventEntity eventEntity = new EventEntity();
            eventEntity.ID = this.ID;
            eventEntity.EventDate = this.EventDate;
            eventEntity.User = new UserEntity();
            eventEntity.User.Id = user.Id;
            eventEntity.Answers = new List<EventAnswerEntity>();
            if(this.QuestionAnswerModels != null && this.QuestionAnswerModels.Count > 0)
            {
                foreach(EventQuestionAnswerModel model in QuestionAnswerModels)
                {
                    EventAnswerEntity eventAnswerEntity = new EventAnswerEntity();
                    eventAnswerEntity.ID = model.ID;
                    eventAnswerEntity.Option = new SectorOptionsEntity();
                    eventAnswerEntity.Option.OptionId = model.OptionId;
                    eventAnswerEntity.Option.OptionText = model.OptionText;
                    eventAnswerEntity.Question = new QuestionEntity();
                    eventAnswerEntity.Question.QuestionId = model.QuestionId;
                    eventAnswerEntity.Question.Text = model.QuestionText;

                    if (model.OptionId == -1)
                    {
                        int temp = (int)model.SentimentalValue;
                        if (temp != (int)SentimentalValue.Unknown)
                        {
                            eventAnswerEntity.Option.SentimentalValue = (SentimentalValue)temp;
                        }
                    }
                    else
                    {
                        eventAnswerEntity.Option.Value = model.Value;
                    }
                    eventEntity.Answers.Add(eventAnswerEntity);
                }
            }

            eventBO = new EventBO(eventEntity, connectionstring);
            return eventBO.Save();
        }
    }

    public class EventReturnModel
    {
        public int EventId { get; set; }
        public EventReturnModel(int id)
        {
            EventId = id;
        }
    }
}
