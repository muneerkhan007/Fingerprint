﻿using BusinessEntities;
using BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SafeWasteWebAPI.Models
{
    public class OrganizationModel
    {

        OrganizationBO _orgBO= null;
        public string code { get; set; }
        public SectorModel Sector { get; set; }

        public OrganizationModel()
        {
            code = null;
        }
        public OrganizationModel(string code, string connectionstring)
        {
            _orgBO = new OrganizationBO(code,connectionstring);
            OrganizationEntity organizationEntity = _orgBO.Get();

            if (organizationEntity != null && !String.IsNullOrEmpty(organizationEntity.Code))
            {
                this.code = organizationEntity.Code;
                this.Sector = new SectorModel();
                this.Sector.SectorId = organizationEntity.SectorId;
            }
        }

        public List<EventEntity> GetAllEvents()
        {
            return _orgBO.GetAllEvents();
        }

        public List<EventTypeModel> GetEventTypes()
        {
            List<EventTypeEntity> EventTypes = _orgBO.GetEventTypes();

            List<EventTypeModel> UIEventTypes = new List<EventTypeModel>();
            foreach (EventTypeEntity eventType in EventTypes)
            {
                EventTypeModel tEventType = new EventTypeModel();
                tEventType.EventTypeId = eventType.EventTypeId;
                tEventType.EventType = eventType.EventType;
                tEventType.Value = eventType.Value;

                UIEventTypes.Add(tEventType);
            }

            return UIEventTypes;
        }
    }
}
