﻿using BusinessEntities;
using BusinessObjects;
using Microsoft.AspNetCore.Identity;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Threading.Tasks;

namespace SafeWasteWebAPI.Models
{
    public class UserModel
    {

        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        [Required]
        public string Password { get; set; }

        [Required]
        public string UserName { get; set; }
        private UserBO userBO = null;

        public string Token { get; set; }

        public OrganizationModel Organization { get; set; }
        public List<EventModel> Events { get; set; }
        public string GUID { get; set; }
        public string DeviceId { get; set; }

        public UserModel(int id,string connectionstring)
        {
            userBO = new UserBO(connectionstring, id);
            UserEntity user = userBO.Get();
            if(user != null)
            {
                this.Id = user.Id;
                this.FirstName = user.FirstName;
                this.LastName = user.LastName;
                this.Password = user.HashedPassword;
                this.DeviceId = user.DeviceId;
            }
        }
        // IF isGUID is true, name will have the GUID for the user
        public UserModel(string name, string connectionstring, bool isGUID)
        {
            userBO = new UserBO(connectionstring, name, isGUID);
            UserEntity user = userBO.Get();
            if (user != null)
            {
                this.Id = user.Id;
                this.UserName = user.UserName;
                this.DeviceId = user.DeviceId;
            }
        }
        public UserModel()
        {

        }

        internal UserIdModel Save(string connectionstring)
        {
            int id = -1;

            UserEntity uEntity = new UserEntity();
            uEntity.HashedPassword = this.Password;
            uEntity.UserName = this.UserName;
            uEntity.organization = new OrganizationEntity();
            uEntity.organization.Code = this.Organization.code;
            uEntity.Token = this.Token;
            userBO = new UserBO(connectionstring, uEntity);
            
            uEntity = userBO.Save();

            UserIdModel uIdModel = new UserIdModel();
            if (uEntity != null && uEntity.Id > 0)
            {
                uIdModel = new UserIdModel();
                uIdModel.Id = uEntity.Id;
                uIdModel.Token = uEntity.Token;
                uIdModel.isDeviceIdChanged = uEntity.isDeviceIdChanged;
                if (uEntity.organization != null)
                {
                    uIdModel.OrganizationCode = uEntity.organization.Code;
                    uIdModel.NegativeSegementImpact = uEntity.organization.NegativeSegementImpact;
                    uIdModel.RatingDifference = uEntity.organization.RatingDifference;
                    uIdModel.MaxEvents = uEntity.organization.MaxEvents;
                }
            }
            return uIdModel;
        }
        public UserIdModel Login(string connectionstring)
        {
            UserIdModel uIdModel = null;

            UserEntity userEntity = new UserEntity();
            userEntity.UserName = this.UserName;
            userEntity.HashedPassword = this.Password;
            userEntity.DeviceId = this.DeviceId;

            userBO = new UserBO(connectionstring, userEntity);
            UserEntity retEntity  = userBO.Login();

            if (retEntity != null && retEntity.Id > 0)
            {
                uIdModel = new UserIdModel();
                uIdModel.Id = retEntity.Id;
                uIdModel.Token = retEntity.Token;
                uIdModel.isDeviceIdChanged = retEntity.isDeviceIdChanged;
                if(retEntity.organization != null)
                { 
                    uIdModel.OrganizationCode = retEntity.organization.Code;
                    uIdModel.NegativeSegementImpact = retEntity.organization.NegativeSegementImpact;
                    uIdModel.RatingDifference = retEntity.organization.RatingDifference;
                    uIdModel.MaxEvents = retEntity.organization.MaxEvents;
                }
            }
            return uIdModel;
        }

        public void GetAllQuestionsWithAnswers()
        {
            List<EventEntity> Events = new List<EventEntity>();
            Events = userBO.GetAllQuestionsWithAnswers();

            if (Events != null && Events.Count > 0)
            {
                this.Events = new List<EventModel>();

                foreach (EventEntity eve in Events)
                {
                    EventModel tempEvent = new EventModel();
                    
                    tempEvent.EventType = new EventTypeModel();
                    tempEvent.EventType.EventTypeId = eve.EventType.EventTypeId;
                    tempEvent.EventType.EventType = eve.EventType.EventType;
                    
                    tempEvent.QuestionAnswerModels = new List<EventQuestionAnswerModel>();

                    tempEvent.EventId = eve.EventId;
                    foreach (EventAnswerEntity answer in eve.Answers)
                    {
                        EventQuestionAnswerModel questionsAnswer = new EventQuestionAnswerModel();

                        questionsAnswer.CategoryId = answer.Question.Category.Id;

                        questionsAnswer.QuestionId = answer.Question.QuestionId;
                        questionsAnswer.QuestionText = answer.Question.Text;

                        questionsAnswer.OptionId = answer.Option.OptionId;
                        questionsAnswer.OptionText = answer.Option.OptionText;

                        if (answer.Option.OptionId == -1)
                            questionsAnswer.SentimentalValue = answer.Option.SentimentalValue;
                        else
                            questionsAnswer.Value = Convert.ToInt32(answer.Option.Value);

                        tempEvent.QuestionAnswerModels.Add(questionsAnswer);
                    }

                    this.Events.Add(tempEvent);
                }
            }
        }

        public void generateGUID()
        {
            UserEntity userEntity = new UserEntity();
            userEntity.UserName = this.UserName;

            this.GUID = userBO.generateGUID();
        }
    }
    public class UserIdModel
    {
        public int Id { get; set; }
        public string Token { get; set; }
        public string OrganizationCode { get; set; }
        public bool isDeviceIdChanged { get; set; }
        public int NegativeSegementImpact { get; set; }
        public int RatingDifference { get; set; }
        public int MaxEvents { get; set; }
    }
}
