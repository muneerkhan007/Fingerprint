﻿using BusinessEntities;
using DataObjects;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessObjects
{
    public class SectorBO
    {
        SectorDO dO = null;
        public SectorBO(int sectorId,string connectionstring)
        {
            dO = new SectorDO(sectorId, connectionstring);

        }
        public SectorEntity Get()
        {
            if (dO.Data == null || dO.Data.Sectorid <= 0)
                return null;
            else
                return dO.Data;
        }

        public List<QuestionEntity> GetSectorQuestions()
        {
            return dO.GetQuestions();
        }
    }
}
