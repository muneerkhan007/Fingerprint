﻿using BusinessEntities;
using DataObjects;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessObjects
{
    public class OrganizationBO
    {
        OrganizationDO _do = null;

        public OrganizationBO(string code,string connectionstring)
        {
            _do = new OrganizationDO(code,connectionstring);
        }
        public OrganizationEntity Get()
        {
            if (_do.Organization != null)
                return _do.Organization;
            else
                return null;
        }

        public List<EventEntity> GetAllEvents()
        {
            List<EventEntity> Events = _do.GetAllEvents();

            foreach(EventEntity eve in Events)
            {
                eve.SentimentalValue = null;
                decimal result = 0;
                foreach(EventAnswerEntity answer in eve.Answers)
                {
                    if (answer.Option.Value != null)
                        result += Convert.ToInt32(answer.Option.Value);
                    else if (answer.Option.SentimentalValue != SentimentalValue.Unknown)
                    {
                        if (answer.Option.SentimentalValue == SentimentalValue.positive)
                            result += Convert.ToInt32(StressLevel.MILD);
                        else if (answer.Option.SentimentalValue == SentimentalValue.neutral)
                            result += Convert.ToInt32(StressLevel.AVERAGE);
                        else if (answer.Option.SentimentalValue == SentimentalValue.neutral)
                            result += Convert.ToInt32(StressLevel.INTENSE);
                    }
                }
                result = Math.Ceiling((result / eve.Answers.Count));

                if (result == 0)
                    eve.SentimentalValue = "Neutral";
                if (result == Convert.ToInt32(StressLevel.MINOR) || result == Convert.ToInt32(StressLevel.MILD))
                    eve.SentimentalValue = "Positive";
                else if (result == Convert.ToInt32(StressLevel.AVERAGE))
                    eve.SentimentalValue = "Neutral";
                else if (result == Convert.ToInt32(StressLevel.INTENSE) || result == Convert.ToInt32(StressLevel.SEVERE))
                    eve.SentimentalValue = "Negative";
            }

            return Events;
        }

        public List<EventTypeEntity> GetEventTypes()
        {
            return _do.GetEventTypes();
        }
    }
}
