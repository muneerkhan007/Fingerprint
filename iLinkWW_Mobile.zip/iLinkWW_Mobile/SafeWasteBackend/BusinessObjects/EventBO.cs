﻿using BusinessEntities;
using DataObjects;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessObjects
{
    public class EventBO
    {
        EventDO eventDO = null;
        public EventBO(EventEntity evt, string connectionstring)
        {
            eventDO = new EventDO(evt, connectionstring);
        }
        public int Save()
        {
            return eventDO.Save();
        }
    }
}
