﻿using BusinessEntities;
using DataObjects;
using System;
using System.Collections.Generic;
using System.Data.Common;

namespace BusinessObjects
{
    public class UserBO
    {
        private UserDO _do = null;
        public UserBO(string connectionstring,int id)
        {
            _do = new UserDO(connectionstring, id);
        }
        public UserBO(string connectionstring, string username, bool isGUID)
        {
            _do = new UserDO(connectionstring, username, isGUID);
        }
        public UserBO(string connectionstring,UserEntity userEntity)
        {
            _do = new UserDO(connectionstring, userEntity);
        }

        public UserEntity Save()
        {
            return _do.Save();
        }

        public UserEntity Login()
        {

            if (_do.User == null)
                return null;

             UserEntity user = _do.Login();

            return user;

        }

        public List<EventEntity> GetAllQuestionsWithAnswers()
        {
            _do.GetAllQuestionsWithAnswers();
            return _do.User.Events;
        }

        public UserEntity Get()
        {
            if (_do.User != null && _do.User.Id > 0)
                return _do.User;
            else
                return null;
        }

        public string generateGUID()
        {
            _do.generateGUID();
            return _do.User.GUID;
        }
    }

}
