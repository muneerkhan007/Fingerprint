﻿using DataObjects;
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace BusinessObjects
{
    public class UtilBO
    {
        UtilDO _DO = null;

        public UtilBO() { }
        public UtilBO(string connectionstring)
        {
            _DO = new UtilDO(connectionstring);
        }

        public string SyncData(int userId, int fromVersion)
        {
            return _DO.SyncData(userId, fromVersion);
        }

        public string Encrypt(string plainText)
        {
            string Key = "InncrewinTechnologies123";

            byte[] IV = new byte[16];
            byte[] array;

            using (Aes AES = Aes.Create())
            {
                AES.Key = Encoding.UTF8.GetBytes(Key);
                AES.IV = IV;

                ICryptoTransform encryptor = AES.CreateEncryptor(AES.Key, AES.IV);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream((Stream)ms, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter sw = new StreamWriter((Stream)cs))
                        {
                            sw.Write(plainText);
                            sw.Dispose();
                        }

                        array = ms.ToArray();   
                        cs.Dispose();
                    }
                    ms.Dispose();
                }
                AES.Dispose();
            }
            return Convert.ToBase64String(array);
        }

        public string Decrypt(string cipherText)
        {
            string plainText = string.Empty;
            string Key = "InncrewinTechnologies123";

            byte[] IV = new byte[16];
            byte[] Buffer = Convert.FromBase64String(cipherText);

            using (Aes AES = Aes.Create())
            {
                AES.Key = Encoding.UTF8.GetBytes(Key);
                AES.IV = IV;

                ICryptoTransform decryptor = AES.CreateDecryptor(AES.Key, AES.IV);
                using (MemoryStream ms = new MemoryStream(Buffer))
                {
                    using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader sr = new StreamReader((Stream)cs))
                        {
                            plainText = sr.ReadToEnd();
                            sr.Dispose();
                        }

                        cs.Dispose();
                    }

                    ms.Dispose();
                }

                AES.Dispose();
            }
            return plainText;
        }
    }
}
