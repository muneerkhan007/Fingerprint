using System.Data.SqlTypes;

namespace DataObjects.Constants
{
    public static class DataConstants
    {
        #region Columns


        
        public static string COL_FIRST_NAME = "FirstName";
        public static string COL_LAST_NAME = "LastName";
        public static string COL_HASHED_PASSWORD = "HashedPassword";
        public static string COL_USER_NAME = "username";
        public static string COL_ID = "Id";
        public static string COL_CODE = "code";
        public static string COL_TOKEN = "Token";
        public static string COL_SECTOR_ID = "SectorId";
        public static string COL_SECTOR_NAME = "SectorName";
        public static string COL_QUESTION_ID = "QuestionId";
        public static string COL_QUESTION_TEXT = "QuestionText";
        public static string COL_QUESTION_CATEGORY_ID = "QuestionCategoryId";
        public static string COL_QUESTION_CATEGORY_NAME = "QuestionCategoryName";
        public static string COL_QUESTION_TYPE_ID = "QuestionTypeId";
        public static string COL_QUESTION_TYPE_NAME = "QuestionTypeName";
        public static string COL_QUESTION_TYPE_MULTIPLE_CHOICE = "IsMultipleChoice";
        public static string COL_OPTIONS = "options";
        public static string COL_EVENT_ID = "EventId";
        public static string COL_EVENT_DATE = "EventDate";
        public static string COL_EVENTTYPE_OPTIONS = "EventTypeOptions";
        public static string COL_EVENT_TYPE_ID = "EventTypeId";
        public static string COL_EVENT_TYPE_NAME = "EventTypeName";
        public static string COL_JSON = "JSON";
        public static string COL_OPTION_ID = "OptionId";
        public static string COL_ANSWER_TEXT = "AnswerText";
        public static string COL_VALUE = "Value";
        public static string COL_SENTIMENTAL_VALUE = "SentimentalValue";
        public static string COL_GUID = "GUID";
        public static string COL_DEVICE_ID = "DeviceId";
        public static string COL_NEGATIVE_SEGEMENT_IMPACT = "NegativeSegementImpact";
        public static string COL_RATING_DIFFERENCE = "RatingDifference";
        public static string COL_MAX_EVENTS = "MaxEvents";
        #endregion

        #region Parameters
        public static string PARAM_USER_NAME = "username";
        public static string PARAM_PASSWORD = "password";
        public static string PARAM_CODE = "code";
        public static string PARAM_DEVICE_ID = "DeviceId";
        public static string PARAM_TOKEN = "Token";
        public static string PARAM_SECTOR_ID = "SectorId";
        public static string PARAM_ID = "Id";
        public static string PARAM_USER_ID = "UserId";
        public static string PARAM_EVENT_DATE = "EventDate";
        public static string PARAM_EVENT_TYPE = "EventTypeId";
        public static string PARAM_EVENT_ID = "EventId";
        public static string PARAM_ANSWERS = "Answers";
        public static string PARAM_GUID = "GUID";
        public static string PARAM_FROM_VERSION = "fromVersion";
        public static string PARAM_JSON_OUTPUT = "JSONOutput";
        #endregion
    }
}