namespace DataObjects.Constants
{
    public static class StoredProcedureConstants
    {
        public static string SP_GET_USER = "ISP_GET_USER";
        public static string SP_GET_USER_BY_NAME = "ISP_GET_USER_BY_NAME";
        public static string SP_INSERT_USER = "ISP_INSERT_USER";
        public static string SP_UPDATE_DEVICE_ID = "ISP_UPDATE_DEVICE_ID";
        public static string SP_GET_ORGANIZATION_BY_CODE = "ISP_GET_ORGANIZATION_BY_CODE";
        public static string SP_GET_SECTOR = "ISP_GET_SECTOR";
        public static string SP_GET_SECTOR_QUESTIONS = "ISP_GET_SECTOR_QUESTIONS";
        public static string SP_INSERT_EVENT = "ISP_INSERT_EVENT";
        public static string SP_INSERT_EVENT_ANSWERS = "ISP_INSERT_EVENT_ANSWERS";

        public static string SP_SYNC_ALL_TABLES = "ISP_SYNC_ALL_TABLES";
        public static string SP_GET_ALL_QUESTIONS_WITH_ANSWERS_BY_USER_ID = "ISP_GET_ALL_QUESTIONS_WITH_ANSWERS_BY_USER_ID";
        public static string SP_GET_ALL_EVENTS_BY_ORGANIZATION_CODE = "ISP_GET_ALL_EVENTS_BY_ORGANIZATION_CODE";

        public static string SP_GET_GUID_BY_USERNAME = "ISP_GET_GUID_BY_USERNAME";
        public static string SP_GET_EVENT_TYPES = "ISP_GET_EVENT_TYPES";
    }
}