﻿using BusinessEntities;
using DataObjects.Connection;
using DataObjects.Constants;
using DataObjects.Utilities;
using DataObjects.Utils;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace DataObjects
{
    public class UserDO
    {
        private string connectionstring;
        private UserEntity _user = null;

        public UserDO(string connectionstring, int id)
        {
            this.connectionstring = connectionstring;
            _user = getUser(id);
        }

        public UserDO(string connectionstring, string username, bool isGUID)
        {
            this.connectionstring = connectionstring;
            _user = getUserByNameOrGUID(username, isGUID);
        }


        public UserEntity Login()
        {
            UserEntity dbuser = getUserByNameOrGUID(_user.UserName, false);

            if (dbuser == null || String.IsNullOrEmpty(dbuser.HashedPassword))
                return  null;

            bool bSuccess = ComparePassword(_user.HashedPassword, dbuser.HashedPassword);

            if (bSuccess)
            {
                // check IF user's device ID has changed. IF YES, update the database.
                // First login
                if (string.IsNullOrEmpty(dbuser.DeviceId))
                {
                    User.Id = dbuser.Id;
                    dbuser.isDeviceIdChanged = false;
                    _user.DeviceId = User.DeviceId;
                    updateDeviceId();
                }
                else if (dbuser.DeviceId != User.DeviceId)
                {
                    _user.Id = dbuser.Id;
                    dbuser.isDeviceIdChanged = true;
                    _user.DeviceId = User.DeviceId;
                    updateDeviceId();
                }
            }
            else
            {
                return null;
            }

            return dbuser;
        }

        public bool updateDeviceId()
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            
            if (_user.Id > 0)
                parameters.Add(new SqlParameter(DataConstants.PARAM_USER_ID, _user.Id));
            else
                throw new Exception("Required parameter missing");
            if (!string.IsNullOrEmpty(_user.DeviceId))
                parameters.Add(new SqlParameter(DataConstants.PARAM_DEVICE_ID, _user.DeviceId));
            else
                throw new Exception("Required parameter missing");

            DBConnection connection = new DBConnection(connectionstring);
            try
            {
                connection.ExecuteScalar(StoredProcedureConstants.SP_UPDATE_DEVICE_ID, parameters.ToArray());
            }
            catch (Exception exception)
            {
                Log.ForContext("UpdateDeviceId", typeof(UserDO).FullName).Error(exception, "Failed while trying to update device ID.");
                throw exception;
            }
            finally
            {
                connection.Dispose();
            }

            return _user.isDeviceIdChanged;
        }

        public UserEntity Save()
        {
            int id = -1;
            if (_user == null)
                return null;

            DBConnection connection = new DBConnection(connectionstring);
            UserEntity dbuser = new UserEntity();
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                if (!string.IsNullOrEmpty(_user.UserName))
                    parameters.Add(new SqlParameter(DataConstants.PARAM_USER_NAME, _user.UserName));
                else
                    throw new Exception("REquired parameter missing");

                if (!string.IsNullOrEmpty(_user.HashedPassword))
                    parameters.Add(new SqlParameter(DataConstants.PARAM_PASSWORD, GeneralUtil.HashPassword(_user.HashedPassword)));
                else
                    throw new Exception("REquired parameter missing");

                if (_user.organization != null && _user.organization.Code != null)
                    parameters.Add(new SqlParameter(DataConstants.PARAM_CODE, _user.organization.Code));
                else
                    throw new Exception("REquired parameter missing");

                if (!String.IsNullOrEmpty(_user.Token))
                    parameters.Add(new SqlParameter(DataConstants.PARAM_TOKEN, _user.Token));
                else
                    throw new Exception("REquired parameter missing");

                object obj = connection.ExecuteScalar(StoredProcedureConstants.SP_INSERT_USER, parameters.ToArray());
                if (obj != null)
                    id = System.Convert.ToInt32(obj);

                if (id > 0)
                    dbuser = getUserByNameOrGUID(_user.UserName, false);
            }
            catch (Exception exception)
            {
                Log.ForContext("Save", typeof(UserDO).FullName).Error(exception, "Failed in Save()");
                throw exception;
            }
           
            return dbuser;
        }

        public UserDO(string connectionstring,UserEntity user)
        {
            this.connectionstring = connectionstring;
            _user = user;
        }

        public bool ComparePassword(string password,string dbPassword)
        {
            bool bSuccess = false;

            bSuccess = GeneralUtil.ComparePassword(password, dbPassword);


            return bSuccess;
        }

        public  UserEntity getUserByNameOrGUID(string username, bool isGUID)
        {
            UserEntity user = new UserEntity();
            user.organization = new OrganizationEntity();

            DBConnection connection = new DBConnection(connectionstring);
            SqlDataReader reader = null;

            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                if (!isGUID && !string.IsNullOrEmpty(username))
                    parameters.Add(new SqlParameter(DataConstants.PARAM_USER_NAME, username));
                else if (!string.IsNullOrEmpty(username))
                    parameters.Add(new SqlParameter(DataConstants.PARAM_GUID, username));
                else
                    throw new Exception("Required parameter missing");

                reader = connection.ExecuteIncrReader(StoredProcedureConstants.SP_GET_USER_BY_NAME, parameters.ToArray());
                SQLUtilities utilSQL = new SQLUtilities();
                if (reader.Read())
                {
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_ID))
                        user.Id = Convert.ToInt32(reader[DataConstants.COL_ID]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_USER_NAME))
                        user.UserName = Convert.ToString(reader[DataConstants.COL_USER_NAME]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_HASHED_PASSWORD))
                        user.HashedPassword = Convert.ToString(reader[DataConstants.COL_HASHED_PASSWORD]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_TOKEN))
                        user.Token = Convert.ToString(reader[DataConstants.COL_TOKEN]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_GUID))
                        user.GUID = Convert.ToString(reader[DataConstants.COL_GUID]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_DEVICE_ID))
                        user.DeviceId = Convert.ToString(reader[DataConstants.COL_DEVICE_ID]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_CODE))
                        user.organization.Code = Convert.ToString(reader[DataConstants.COL_CODE]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_NEGATIVE_SEGEMENT_IMPACT))
                        user.organization.NegativeSegementImpact = Convert.ToInt32(reader[DataConstants.COL_NEGATIVE_SEGEMENT_IMPACT]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_RATING_DIFFERENCE))
                        user.organization.RatingDifference = Convert.ToInt32(reader[DataConstants.COL_RATING_DIFFERENCE]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_MAX_EVENTS))
                        user.organization.MaxEvents = Convert.ToInt32(reader[DataConstants.COL_MAX_EVENTS]);
                }
            }
            catch (Exception exception)
            {
                Log.ForContext("GetAllDocuments", typeof(UserDO).FullName).Error(exception, "Failed in getUser()");
                throw exception;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                connection.Dispose();
            }

            return user;
        }

        public UserEntity User
        {
            get { return _user; }
        }


        private UserEntity getUser(int id)
        {
            UserEntity user = new UserEntity();

            DBConnection connection = new DBConnection(connectionstring);
            SqlDataReader reader = null;

            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                if (id > 0)
                    parameters.Add(new SqlParameter(DataConstants.PARAM_ID, id));
                else
                    throw new Exception("Required parameter missing");

                reader = connection.ExecuteIncrReader(StoredProcedureConstants.SP_GET_USER, parameters.ToArray());
                SQLUtilities utilSQL = new SQLUtilities();
                if (reader.Read())
                {
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_ID))
                        user.Id = Convert.ToInt32(reader[DataConstants.COL_ID]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_USER_NAME))
                        user.UserName = Convert.ToString(reader[DataConstants.COL_USER_NAME]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_HASHED_PASSWORD))
                        user.HashedPassword = Convert.ToString(reader[DataConstants.COL_HASHED_PASSWORD]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_TOKEN))
                        user.Token = Convert.ToString(reader[DataConstants.COL_TOKEN]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_DEVICE_ID))
                        user.DeviceId = Convert.ToString(reader[DataConstants.COL_DEVICE_ID]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_CODE))
                    {
                        user.organization = new OrganizationEntity();
                        user.organization.Code = Convert.ToString(reader[DataConstants.COL_CODE]);
                    }
                }
            }
            catch (Exception exception)
            {
                Log.ForContext("GetAllDocuments", typeof(UserDO).FullName).Error(exception, "Failed in getUser()");
                throw exception;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                connection.Dispose();
            }

            return user;
        }

        public void GetAllQuestionsWithAnswers()
        {
            DBConnection connection = new DBConnection(connectionstring);
            SqlDataReader reader = null;
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                if (User.Id > 0)
                    parameters.Add(new SqlParameter(DataConstants.PARAM_USER_ID, User.Id));
                else
                    throw new Exception("Required parameter missing");

                reader = connection.ExecuteIncrReader(StoredProcedureConstants.SP_GET_ALL_QUESTIONS_WITH_ANSWERS_BY_USER_ID, parameters.ToArray());

                User.Events = new List<EventEntity>();
                while (reader.Read())
                {
                    SQLUtilities utilSQL = new SQLUtilities();

                    EventEntity eve = new EventEntity();

                    eve.EventType = new EventTypeEntity();
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_EVENT_TYPE_ID))
                        eve.EventType.EventTypeId = Convert.ToInt32(reader[DataConstants.COL_EVENT_TYPE_ID]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_EVENT_TYPE_NAME))
                        eve.EventType.EventType = Convert.ToString(reader[DataConstants.COL_EVENT_TYPE_NAME]);

                    eve.Answers = new List<EventAnswerEntity>();

                    EventAnswerEntity ans = new EventAnswerEntity();
                    ans.Question = new QuestionEntity();
                    ans.Question.Category = new QuestionCategoryEntity();
                    ans.Option = new SectorOptionsEntity();

                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_EVENT_ID))
                        eve.EventId = Convert.ToInt32(reader[DataConstants.COL_EVENT_ID]);

                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_QUESTION_ID))
                        ans.Question.QuestionId = Convert.ToInt32(reader[DataConstants.COL_QUESTION_ID]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_QUESTION_TEXT))
                        ans.Question.Text = Convert.ToString(reader[DataConstants.COL_QUESTION_TEXT]);

                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_QUESTION_CATEGORY_ID))
                        ans.Question.Category.Id = Convert.ToInt32(reader[DataConstants.COL_QUESTION_CATEGORY_ID]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_QUESTION_CATEGORY_NAME))
                        ans.Question.Category.CategoryName = Convert.ToString(reader[DataConstants.COL_QUESTION_CATEGORY_NAME]);
                    
                    if (ans.Question.QuestionId == 3)
                    {
                        if (utilSQL.ColumnInReader(reader, DataConstants.COL_EVENT_TYPE_ID))
                            ans.Option.OptionId = Convert.ToInt32(reader[DataConstants.COL_EVENT_TYPE_ID]);
                        if (utilSQL.ColumnInReader(reader, DataConstants.COL_EVENT_TYPE_NAME))
                            ans.Option.OptionText = Convert.ToString(reader[DataConstants.COL_EVENT_TYPE_NAME]);
                    }
                    else
                    {
                        if (utilSQL.ColumnInReader(reader, DataConstants.COL_OPTION_ID))
                            ans.Option.OptionId = Convert.ToInt32(reader[DataConstants.COL_OPTION_ID]);
                        if (utilSQL.ColumnInReader(reader, DataConstants.COL_ANSWER_TEXT))
                            ans.Option.OptionText = Convert.ToString(reader[DataConstants.COL_ANSWER_TEXT]);
                        if (utilSQL.ColumnInReader(reader, DataConstants.COL_VALUE))
                            ans.Option.Value = Convert.ToInt32(reader[DataConstants.COL_VALUE]);
                        if (utilSQL.ColumnInReader(reader, DataConstants.COL_SENTIMENTAL_VALUE))
                            ans.Option.SentimentalValue = (SentimentalValue)Convert.ToInt32(reader[DataConstants.COL_SENTIMENTAL_VALUE]);
                    }

                    EventEntity matchedEvent = User.Events.Find((tEvent) => tEvent.EventId == eve.EventId);
                    if (matchedEvent != null)
                        matchedEvent.Answers.Add(ans);
                    else
                    {
                        eve.Answers.Add(ans);
                        User.Events.Add(eve);
                    }
                }
            }
            catch (Exception exception)
            {
                Log.ForContext("GetAllQuestions", typeof(OrganizationDO).FullName).Error(exception, "Failed in GetAllQuestionsWithAnswers()");
                throw exception;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                connection.Dispose();
            }
        }

        public void generateGUID()
        {
            DBConnection connection = new DBConnection(connectionstring);
            SqlDataReader reader = null;
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                if (!string.IsNullOrEmpty(User.UserName))
                    parameters.Add(new SqlParameter(DataConstants.PARAM_USER_NAME, User.UserName));
                else
                    throw new Exception("Required parameter missing");

                reader = connection.ExecuteIncrReader(StoredProcedureConstants.SP_GET_GUID_BY_USERNAME, parameters.ToArray());

                if (reader.Read())
                {
                    SQLUtilities utilSQL = new SQLUtilities();

                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_ID))
                        User.Id = Convert.ToInt32(reader[DataConstants.COL_ID]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_USER_NAME))
                        User.UserName = Convert.ToString(reader[DataConstants.COL_USER_NAME]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_GUID))
                        User.GUID = Convert.ToString(reader[DataConstants.COL_GUID]);
                }
            }
            catch (Exception exception)
            {
                Log.ForContext("GetAllQuestions", typeof(OrganizationDO).FullName).Error(exception, "Failed in GetAllQuestionsWithAnswers()");
                throw exception;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                connection.Dispose();
            }
        }
    }
}
