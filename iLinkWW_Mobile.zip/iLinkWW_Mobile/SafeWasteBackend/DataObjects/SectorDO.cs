﻿using BusinessEntities;
using DataObjects.Connection;
using DataObjects.Constants;
using DataObjects.Utilities;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace DataObjects
{
    public class SectorDO
    {
        private SectorEntity _sector;
        private string _connectionstring = null;
        public SectorDO(int sectorId,string connectionString)
        {
            _connectionstring = connectionString;
            _sector = GetSectorById(sectorId);

        }

        public SectorEntity Data
        {
            get { return _sector; }
        }

        public List<QuestionEntity> GetQuestions()
        {
            List<QuestionEntity> questionEntities = new List<QuestionEntity>();
            DBConnection connection = new DBConnection(_connectionstring);
            SqlDataReader reader = null;

            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                if (_sector.Sectorid >=0)
                    parameters.Add(new SqlParameter(DataConstants.PARAM_SECTOR_ID, _sector.Sectorid));
                else
                    throw new Exception("REquired parameter missing");




                reader = connection.ExecuteIncrReader(StoredProcedureConstants.SP_GET_SECTOR_QUESTIONS, parameters.ToArray());
                SQLUtilities utilSQL = new SQLUtilities();
                while (reader.Read())
                {
                    QuestionEntity questionEntity = new QuestionEntity();

                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_QUESTION_ID))
                        questionEntity.QuestionId = Convert.ToInt32(reader[DataConstants.COL_QUESTION_ID]);

                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_QUESTION_TEXT))
                        questionEntity.Text = Convert.ToString(reader[DataConstants.COL_QUESTION_TEXT]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_QUESTION_CATEGORY_ID))
                    {
                        questionEntity.Category = new QuestionCategoryEntity();
                        questionEntity.Category.Id= Convert.ToInt32(reader[DataConstants.COL_QUESTION_CATEGORY_ID]); 
                        questionEntity.Category.CategoryName= Convert.ToString(reader[DataConstants.COL_QUESTION_CATEGORY_NAME]);

                    }
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_QUESTION_TYPE_ID))
                    {
                        questionEntity.Type = new TypeEntity();
                        questionEntity.Type.TypeId = Convert.ToInt32(reader[DataConstants.COL_QUESTION_TYPE_ID]);
                        questionEntity.Type.TypeName = Convert.ToString(reader[DataConstants.COL_QUESTION_TYPE_NAME]);
                        questionEntity.Type.IsMultipleChoice = Convert.ToBoolean(reader[DataConstants.COL_QUESTION_TYPE_MULTIPLE_CHOICE]);

                    }

                    if(questionEntity.QuestionId != 3)
                    { 
                        if (utilSQL.ColumnInReader(reader, DataConstants.COL_OPTIONS))
                        {
                            questionEntity.QuestionOptions = new List<SectorOptionsEntity>();
                            string options = Convert.ToString(reader[DataConstants.COL_OPTIONS]);
                            string[] individualOptions = options.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                            foreach(string individualOption in individualOptions)
                            {
                                SectorOptionsEntity option = new SectorOptionsEntity();
                                string[] optionVals = individualOption.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                                if (optionVals.Length == 0)
                                    continue;
                                option.OptionId = System.Convert.ToInt32(optionVals[0]);
                                if (optionVals.Length > 1)
                                    option.OptionText = optionVals[1];
                                if (optionVals.Length > 2)
                                    option.Value = Convert.ToInt32(optionVals[2]);
                                questionEntity.QuestionOptions.Add(option);
                            }

                        
                        }
                    }
                    else
                    {
                        if (utilSQL.ColumnInReader(reader, DataConstants.COL_EVENTTYPE_OPTIONS))
                        {
                            questionEntity.QuestionOptions = new List<SectorOptionsEntity>();
                            string options = Convert.ToString(reader[DataConstants.COL_EVENTTYPE_OPTIONS]);
                            string[] individualOptions = options.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                            foreach (string individualOption in individualOptions)
                            {
                                SectorOptionsEntity option = new SectorOptionsEntity();
                                string[] optionVals = individualOption.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                                if (optionVals.Length == 0)
                                    continue;
                                option.OptionId = System.Convert.ToInt32(optionVals[0]);
                                if (optionVals.Length > 1)
                                    option.OptionText = optionVals[1];

                                // option.Value = "";
                                questionEntity.QuestionOptions.Add(option);
                            }


                        }

                    }
                    questionEntities.Add(questionEntity);

                }

            }
            catch (Exception exception)
            {
                Log.ForContext("GetQuestions", typeof(UserDO).FullName).Error(exception, "Failed in GetQuestions()");
                throw exception;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                connection.Dispose();
            }

            return questionEntities;
        }

        private SectorEntity GetSectorById(int sectorId)
        {
            SectorEntity sector = null;
            DBConnection connection = new DBConnection(_connectionstring);
            SqlDataReader reader = null;

            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                if (sectorId >= 0)
                    parameters.Add(new SqlParameter(DataConstants.PARAM_SECTOR_ID, sectorId));
                else
                    throw new Exception("REquired parameter missing");




                reader = connection.ExecuteIncrReader(StoredProcedureConstants.SP_GET_SECTOR, parameters.ToArray());
                SQLUtilities utilSQL = new SQLUtilities();
                if (reader.Read())
                {
                    sector = new SectorEntity();

                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_SECTOR_ID))
                        sector.Sectorid = Convert.ToInt32(reader[DataConstants.COL_SECTOR_ID]);

                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_SECTOR_NAME))
                        sector.SectorName = Convert.ToString(reader[DataConstants.COL_SECTOR_NAME]);
                    

                }

            }
            catch (Exception exception)
            {
                Log.ForContext("GetSectorById", typeof(SectorDO).FullName).Error(exception, "Failed in GetSectorById()");
                throw exception;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                connection.Dispose();
            }

            return sector;
        }
    }
}
