using BusinessEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace DataObjects.Utilities
{
    public class SQLUtilities
    {
        private HashSet<string> _columns = null;

        public bool ColumnInReader(SqlDataReader rdr, string columnName)
        {
            if(_columns == null)
            {
                _columns = new HashSet<string>();
                for (int i = 0; i < rdr.FieldCount; i++)
                {
                    _columns.Add(rdr.GetName(i).ToLower());
                }
            }
            if (_columns.Contains(columnName.ToLower()) && !rdr.IsDBNull(rdr.GetOrdinal(columnName)))
                return true;
            return false;

        }

        public static DataTable GetEventAnswerTable(List<EventAnswerEntity> answers)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ID", typeof(Int32));
            dt.Columns.Add("QuestionId", typeof(Int32));
            dt.Columns.Add("QuestionText", typeof(string));
            dt.Columns.Add("OptionId", typeof(Int32));
            dt.Columns.Add("AnswerText", typeof(string));
            dt.Columns.Add("Value", typeof(int));
            dt.Columns.Add("SentimentalValue", typeof(string));
            if (answers != null && answers.Count > 0)
            {
                foreach (EventAnswerEntity eventAnswer in answers)
                {
                    dt.Rows.Add(eventAnswer.ID, eventAnswer.Question.QuestionId, eventAnswer.Question.Text, eventAnswer.Option.OptionId, eventAnswer.Option.OptionText, eventAnswer.Option.Value, (int)eventAnswer.Option.SentimentalValue);
                }
            }
            return dt;
        }
    }
}