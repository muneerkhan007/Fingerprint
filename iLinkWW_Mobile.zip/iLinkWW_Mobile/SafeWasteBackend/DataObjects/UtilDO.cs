﻿using DataObjects.Connection;
using DataObjects.Constants;
using DataObjects.Utilities;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Net.Http.Headers;
using System.Text;

namespace DataObjects
{
    public class UtilDO
    {
        private string connectionstring;

        public UtilDO(string connectionstring)
        {
            this.connectionstring = connectionstring;
        }

        public string SyncData(int UserId, int fromVersion)
        {
            string strJSON = string.Empty;
            DBConnection connection = new DBConnection(connectionstring);
            SqlDataReader reader = null;

            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                if (fromVersion >= 0)
                    parameters.Add(new SqlParameter(DataConstants.PARAM_FROM_VERSION, fromVersion));
                else
                    throw new Exception("Required parameter missing !");
                if (UserId >= 0)
                    parameters.Add(new SqlParameter(DataConstants.PARAM_USER_ID, UserId));
                else
                    throw new Exception("Required parameter missing !");

                parameters.Add(new SqlParameter(DataConstants.PARAM_JSON_OUTPUT, -1));

                reader = connection.ExecuteIncrReader(StoredProcedureConstants.SP_SYNC_ALL_TABLES, parameters.ToArray());
                SQLUtilities utilSQL = new SQLUtilities();
                if (reader.Read())
                {
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_JSON))
                        strJSON = Convert.ToString(reader[DataConstants.COL_JSON]);
                }
            }
            catch (Exception exception)
            {
                Log.ForContext("SyncAllTables", typeof(UtilDO).FullName).Error(exception, "Failed in SyncData()");
                throw exception;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                connection.Dispose();
            }
            
            return strJSON;
        }
    }
}
