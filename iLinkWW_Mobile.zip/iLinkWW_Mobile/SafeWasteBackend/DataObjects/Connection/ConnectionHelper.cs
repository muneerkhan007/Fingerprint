using System.Data;
using System.Data.SqlClient;

namespace DataObjects.Connection
{
    public class ConnectionHelper
    {
        private string _connectionString = string.Empty;
        private SqlConnection _sqlConnection = null;

        public ConnectionHelper(string ConnectionString)
        {
            _connectionString = ConnectionString;
        }

        public SqlConnection GetConnection()
        {
            if (_sqlConnection == null)
            {
                _sqlConnection = new SqlConnection(_connectionString);
                _sqlConnection.Open();
            }
            else if (_sqlConnection.State == ConnectionState.Closed)
            {
                _sqlConnection.Open();
            }

            return _sqlConnection;
        }

        public void Close()
        {
            if (_sqlConnection != null)
            {
                _sqlConnection.Close();
            }
            _sqlConnection.Dispose();
        } 
    }
}
