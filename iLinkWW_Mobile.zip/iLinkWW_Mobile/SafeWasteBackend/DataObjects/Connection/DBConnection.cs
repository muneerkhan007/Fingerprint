﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Data;

using Serilog;
using System.Data.SqlClient;

namespace DataObjects.Connection
{
    public class DBConnection
    {
        private string _connectionString = string.Empty;
        private ConnectionHelper connection = null;

        public DBConnection(string ConnectionString)
        {
            _connectionString = ConnectionString;
        }

        public object ExecuteScalar(string procName, params SqlParameter[] paramters)
        {
            string result = string.Empty;
            ConnectionHelper helper = new ConnectionHelper(_connectionString);
            SqlConnection connection = helper.GetConnection();
            object ret = null;
            try
            {
                if (connection != null)
                {
                    SqlCommand command = new SqlCommand(procName, connection);
                    command.CommandType = CommandType.StoredProcedure;
                    if (paramters != null)
                    {
                        command.Parameters.AddRange(paramters);
                    }
                    ret = command.ExecuteScalar();
                }
            }
            finally
            {
                helper.Close();
            }

            return ret;
        }

        public SqlDataReader ExecuteIncrReader(string strPocedureName, SqlParameter[] Params)
        {
            SqlDataReader retReader = null;

            ConnectionHelper helper = new ConnectionHelper(_connectionString);
            SqlConnection connection = helper.GetConnection();
            if (connection != null)
            {
                SqlCommand command = new SqlCommand(strPocedureName, connection);
                command.CommandType = CommandType.StoredProcedure;
                foreach (SqlParameter parameter in Params)
                {
                    command.Parameters.Add(parameter);
                }
                retReader = command.ExecuteReader(CommandBehavior.CloseConnection);
            }

            return retReader;
        }
        public SqlDataReader ExecuteIncrReader(string strPocedureName)
        {
            SqlDataReader retReader = null;
            ConnectionHelper helper = new ConnectionHelper(_connectionString);
            SqlConnection connection = helper.GetConnection();
            if (connection != null)
            {
                try
                {
                    SqlCommand AppCommand = new SqlCommand(strPocedureName, connection);
                    AppCommand.CommandType = System.Data.CommandType.StoredProcedure;
                    retReader = AppCommand.ExecuteReader(CommandBehavior.CloseConnection);
                }
                catch (Exception exception)
                {
                    Log.ForContext("DBConnection : ExecuteIncrReader ", typeof(DBConnection).FullName).Error(exception, "Failed in ExecuteIncrReader(procedure-name)");
                    throw exception;
                }
                finally
                {
                    Log.ForContext("DBConnection : ExecuteIncrReader", typeof(DBConnection).FullName).Information("Stored procedure successfully executed.");
                }
            }

            return retReader;
        }

        public void Dispose()
        {
            if (connection != null)
            {
                connection.Close();
            }
        }
    }
}
