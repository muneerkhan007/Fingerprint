﻿using BusinessEntities;
using DataObjects.Connection;
using DataObjects.Constants;
using DataObjects.Utilities;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace DataObjects
{
    public class OrganizationDO
    {
        OrganizationEntity _org = null;
        string connectionstring;
        public OrganizationDO(string code,string connectionstring)
        {
            this.connectionstring = connectionstring;
            _org = GetOrganization(code);            
        }

        private OrganizationEntity GetOrganization(string code)
        {
            OrganizationEntity organization = null;

            DBConnection connection = new DBConnection(connectionstring);
            SqlDataReader reader = null;

            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                if (!string.IsNullOrEmpty(code))
                    parameters.Add(new SqlParameter(DataConstants.PARAM_CODE, code));
                else
                    throw new Exception("Required parameter missing");

                reader = connection.ExecuteIncrReader(StoredProcedureConstants.SP_GET_ORGANIZATION_BY_CODE, parameters.ToArray());
                SQLUtilities utilSQL = new SQLUtilities();
                if (reader.Read())
                {
                    organization = new OrganizationEntity();
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_CODE))
                        organization.Code = Convert.ToString(reader[DataConstants.COL_CODE]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_SECTOR_ID))
                        organization.SectorId = Convert.ToInt32(reader[DataConstants.COL_SECTOR_ID]);
                }
            }
            catch (Exception exception)
            {
                Log.ForContext("GetAllDocuments", typeof(UserDO).FullName).Error(exception, "Failed in getUser()");
                throw exception;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                connection.Dispose();
            }

            return organization;
        }

        public OrganizationEntity Organization
        {
            get
            {
                return _org;
            }
        }

        public List<EventEntity> GetAllEvents()
        {
            List<EventEntity> Events = new List<EventEntity>();

            DBConnection connection = new DBConnection(connectionstring);
            SqlDataReader reader = null;
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                if (!string.IsNullOrEmpty(Organization.Code))
                    parameters.Add(new SqlParameter(DataConstants.PARAM_CODE, Organization.Code));
                else
                    throw new Exception("Required parameter missing");

                reader = connection.ExecuteIncrReader(StoredProcedureConstants.SP_GET_ALL_EVENTS_BY_ORGANIZATION_CODE, parameters.ToArray());

                while (reader.Read())
                {
                    SQLUtilities utilSQL = new SQLUtilities();

                    EventEntity eve = new EventEntity();
                    eve.Answers = new List<EventAnswerEntity>();

                    EventAnswerEntity ans = new EventAnswerEntity();
                    ans.Question = new QuestionEntity();
                    ans.Question.Category = new QuestionCategoryEntity();
                    ans.Option = new SectorOptionsEntity();

                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_EVENT_ID))
                        eve.EventId = Convert.ToInt32(reader[DataConstants.COL_EVENT_ID]);

                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_EVENT_DATE))
                        eve.EventDate = Convert.ToDateTime(reader[DataConstants.COL_EVENT_DATE]);

                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_QUESTION_ID))
                        ans.Question.QuestionId = Convert.ToInt32(reader[DataConstants.COL_QUESTION_ID]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_QUESTION_TEXT))
                        ans.Question.Text = Convert.ToString(reader[DataConstants.COL_QUESTION_TEXT]);

                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_QUESTION_CATEGORY_ID))
                        ans.Question.Category.Id = Convert.ToInt32(reader[DataConstants.COL_QUESTION_CATEGORY_ID]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_QUESTION_CATEGORY_NAME))
                        ans.Question.Category.CategoryName = Convert.ToString(reader[DataConstants.COL_QUESTION_CATEGORY_NAME]);

                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_OPTION_ID))
                        ans.Option.OptionId = Convert.ToInt32(reader[DataConstants.COL_OPTION_ID]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_ANSWER_TEXT))
                        ans.Option.OptionText = Convert.ToString(reader[DataConstants.COL_ANSWER_TEXT]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_VALUE))
                        ans.Option.Value = Convert.ToInt32(reader[DataConstants.COL_VALUE]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_SENTIMENTAL_VALUE))
                        ans.Option.SentimentalValue = (SentimentalValue)Convert.ToInt32(reader[DataConstants.COL_SENTIMENTAL_VALUE]);

                    EventEntity matchedEvent = Events.Find((tEvent) => tEvent.EventId == eve.EventId);
                    if (matchedEvent != null)
                        matchedEvent.Answers.Add(ans);
                    else
                    {
                        eve.Answers.Add(ans);
                        Events.Add(eve);
                    }
                }
            }
            catch (Exception exception)
            {
                Log.ForContext("GetAllEvents", typeof(OrganizationDO).FullName).Error(exception, "Failed in GetAllEvents()");
                throw exception;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                connection.Dispose();
            }

            return Events;
        }

        public List<EventTypeEntity> GetEventTypes()
        {
            List<EventTypeEntity> EventTypes = new List<EventTypeEntity>();

            DBConnection connection = new DBConnection(connectionstring);
            SqlDataReader reader = null;
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                if (!string.IsNullOrEmpty(Organization.Code))
                    parameters.Add(new SqlParameter(DataConstants.PARAM_CODE, Organization.Code));
                else
                    throw new Exception("Required parameter missing");

                reader = connection.ExecuteIncrReader(StoredProcedureConstants.SP_GET_EVENT_TYPES, parameters.ToArray());

                while (reader.Read())
                {
                    SQLUtilities utilSQL = new SQLUtilities();

                    EventTypeEntity eventType = new EventTypeEntity();
                    
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_EVENT_TYPE_ID))
                        eventType.EventTypeId = Convert.ToInt32(reader[DataConstants.COL_EVENT_TYPE_ID]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_EVENT_TYPE_NAME))
                        eventType.EventType = Convert.ToString(reader[DataConstants.COL_EVENT_TYPE_NAME]);
                    if (utilSQL.ColumnInReader(reader, DataConstants.COL_VALUE))
                        eventType.Value = (StressLevel)Convert.ToInt32(reader[DataConstants.COL_VALUE]);

                    EventTypes.Add(eventType);
                }
            }
            catch (Exception exception)
            {
                Log.ForContext("GetEventTypes", typeof(OrganizationDO).FullName).Error(exception, "Failed in GetEventTypes()");
                throw exception;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
                connection.Dispose();
            }

            return EventTypes;
        }
    }
}
