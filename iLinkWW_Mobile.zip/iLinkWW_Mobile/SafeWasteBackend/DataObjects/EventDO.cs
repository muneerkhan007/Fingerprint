﻿using BusinessEntities;
using DataObjects.Connection;
using DataObjects.Constants;
using DataObjects.Utilities;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Net.Http.Headers;
using System.Text;

namespace DataObjects
{
    public class EventDO
    {
        private string _connectionstring = null;
        private EventEntity eventEntity = null;

        public EventDO(EventEntity evt,string connectionstring)
        {
            eventEntity = evt;
            _connectionstring = connectionstring;
        }

        public int Save()
        {
            List<QuestionEntity> questionEntities = new List<QuestionEntity>();
            DBConnection connection = new DBConnection(_connectionstring);
            
            int eventId = -1;
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                if (eventEntity.EventDate != DateTime.MinValue)
                    parameters.Add(new SqlParameter(DataConstants.PARAM_EVENT_DATE, eventEntity.EventDate));
                else
                    throw new Exception("REquired parameter missing");
                if (eventEntity.User != null && eventEntity.User.Id > 0)
                    parameters.Add(new SqlParameter(DataConstants.PARAM_USER_ID, eventEntity.User.Id));
                else
                    throw new Exception("REquired parameter missing");
                if (eventEntity.ID > 0)
                    parameters.Add(new SqlParameter(DataConstants.PARAM_ID, eventEntity.ID));


                if (eventEntity.Answers != null && eventEntity.Answers.Count > 0)
                {
                   EventAnswerEntity eventAnswerEntity =  eventEntity.Answers.Find(x => x.Question != null && x.Question.QuestionId == 3);
                   if(eventAnswerEntity != null && eventAnswerEntity.Option != null && eventAnswerEntity.Option.OptionId > 0)
                        parameters.Add(new SqlParameter(DataConstants.PARAM_EVENT_TYPE, eventAnswerEntity.Option.OptionId));
                }
                object obj = connection.ExecuteScalar(StoredProcedureConstants.SP_INSERT_EVENT, parameters.ToArray());
                
                if (obj != null)
                    eventId = System.Convert.ToInt32(obj);
                else
                    return eventId;

                //remove question id 3 which is eventtype as this is part of event and not answers
                eventEntity.Answers.RemoveAll(x => x.Question != null && x.Question.QuestionId == 3);

                parameters.Clear();

                parameters.Add(new SqlParameter(DataConstants.PARAM_EVENT_ID, eventId));
                parameters.Add(new SqlParameter(DataConstants.PARAM_ANSWERS, SQLUtilities.GetEventAnswerTable(eventEntity.Answers)));

                connection.ExecuteScalar(StoredProcedureConstants.SP_INSERT_EVENT_ANSWERS, parameters.ToArray());



            }
            catch (Exception exception)
            {
                Log.ForContext("SaveEvent", typeof(UserDO).FullName).Error(exception, "Failed in event Save()");
                throw exception;
            }
            finally
            {
            
                connection.Dispose();
            }

            return eventId;
        }
    }
}
