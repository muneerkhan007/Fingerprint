﻿CREATE PROCEDURE [dbo].[ISP_GET_USER_BY_NAME]
	@username nvarchar(1024) = null,
	@guid nvarchar(1024) = null
AS
BEGIN
	if (@username is not null)
	begin
		SELECT
			*
		FROM [Users] U
		INNER JOIN Organization O ON U.OrganizationId = O.Id
		WHERE username = @username
	end
	else if (@guid is not null)
	begin
		SELECT
			*
		FROM [Users] U
		INNER JOIN Organization O ON U.OrganizationId = O.Id
		WHERE [GUID] = @guid
	end
END
