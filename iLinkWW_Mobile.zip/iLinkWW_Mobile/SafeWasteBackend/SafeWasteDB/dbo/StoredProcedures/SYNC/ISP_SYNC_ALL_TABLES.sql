﻿CREATE PROCEDURE [dbo].[ISP_SYNC_ALL_TABLES]
	@fromVersion int,
	@UserId int,
	@JSONOutput NVARCHAR(MAX) OUTPUT
AS
BEGIN
	declare @reason int = 0
	declare @curVer int = change_tracking_current_version();
	declare @minVer int = change_tracking_min_valid_version(object_id('dbo.TrainingSession'));


	if (@fromVersion = 0)
	begin
		set @reason = 0 -- First Sync
	end
	else if (@fromVersion < @minVer) begin
		set @fromVersion = 0
		set @reason = 1 -- fromVersion too old. New full sync needed
	end

	if (@fromVersion = 0)
	begin
		SET @JSONOutput = (select
			[MetaData.Sync] = json_query((
				select 
					'Full' as [Type],
					@curVer as 'Version',
					@reason as 'ReasonCode'
				for json path
			)),
			[Event_Question_Answers] = json_query((
				select
					EQA.ID as 'AnswerId',
					E.ID as 'EventId',
					Q.QuestionId,
					Q.QuestionText,
					case
						when Q.QuestionId = 3 and EQA.OptionId is null
							then E.EventTypeId
						else
							EQA.OptionId
					end as 'OptionId',
					case
						when Q.QuestionId = 3 and EQA.OptionId is null
							then ET.EventTypeName
						else
							EQA.AnswerText
					end as 'AnswerText',
					EQA.[Value],
					EQA.SentimentalValue
				from [Users] U
				left join [Event] E on E.UserId = U.Id
				left join [EventType] ET on ET.EventTypeId = E.EventTypeId
				left join [Sector] S on S.SectorId = ET.SectorId
				left join [Questions_Sectors] QS on QS.SectorId = S.SectorId
				left join [Questions] Q on Q.QuestionId = QS.QuestionId
				left join [Event_Question_Answers] EQA on EQA.QuestionId = QS.QuestionId and EQA.EventId = E.EventId
				where U.Id = @UserId
				for json path
			)),
			[EventType] = json_query((
				select ET.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Sector] S on S.SectorId = O.SectorId
				inner join [EventType] ET on ET.sectorid = S.SectorId
				where U.Id = @UserId
				for json auto
			)),
			[EventType_Organization_QuestionValue] = json_query((
				select ETOQV.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Sector] S on S.SectorId = O.SectorId
				inner join [EventType] ET on ET.sectorid = S.SectorId
				inner join [EventType_Organization_QuestionValue] ETOQV on ETOQV.OrganizationId = O.Id and ET.EventTypeId = ETOQV.EventTypeId
				where U.Id = @UserId
				for json auto
			)),
			[Organization] = json_query((
				select O.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				where U.Id = @UserId
				for json auto
			)),
			[Question_Categories] = json_query((
				select DISTINCT QC.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Sector] S on S.SectorId = O.SectorId
				inner join [Questions_Sectors] QS on QS.SectorId = S.SectorId
				inner join [Questions] Q on Q.QuestionId = QS.QuestionId
				inner join [Question_Categories] QC on QC.QuestionCategoryId = Q.QuestionCategoryId
				where U.Id = @UserId
				for json auto
			)),
			[Question_Types] = json_query((
				select DISTINCT QT.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Sector] S on S.SectorId = O.SectorId
				inner join [Questions_Sectors] QS on QS.SectorId = S.SectorId
				inner join [Questions] Q on Q.QuestionId = QS.QuestionId
				inner join [Question_Types] QT on QT.QuestionTypeId = Q.QuestionTypeId
				where U.Id = @UserId
				for json auto
			)),
			[Questions] = json_query((
				select Q.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Sector] S on S.SectorId = O.SectorId
				inner join [Questions_Sectors] QS on QS.SectorId = S.SectorId
				inner join [Questions] Q on Q.QuestionId = QS.QuestionId
				where U.Id = @UserId
				for json auto
			)),
			[Questions_Sectors] = json_query((
				select QS.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Sector] S on S.SectorId = O.SectorId
				inner join [Questions_Sectors] QS on QS.SectorId = S.SectorId
				where U.Id = @UserId
				for json auto
			)),
			[Sector] = json_query((
				select S.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Sector] S on S.SectorId = O.SectorId
				where U.Id = @UserId
				for json auto
			)),
			[Sector_Question_Options] = json_query((
				select SQO.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Sector] S on S.SectorId = O.SectorId
				inner join [Questions_Sectors] QS on QS.SectorId = S.SectorId
				inner join [Questions] Q on Q.QuestionId = QS.QuestionId
				inner join [Sector_Question_Options] SQO on SQO.QuestionId = Q.QuestionId and SQO.SectorId = S.SectorId
				where U.Id = @UserId
				for json auto
			)),
			[Users] = json_query((
				select U.*
				from [Users] U
				where U.Id = @UserId
				for json auto
			)),
			[Events] = json_query((
				select 
					E.ID as 'EventId',
					E.EventTypeId,
					E.UserId,
					E.EventDate
				from [Users] U
				inner join [Event] E on E.UserId = U.Id
				where U.Id = @UserId
				for json auto
			)),
			[Organization_Support_Details] = json_query((
				select OSD.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Organization_Support_Details] OSD on OSD.OrganizationId = O.Id
				where U.Id = @UserId
				for json auto
			)),
			[Organization_Support_Type] = json_query((
				select OST.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Organization_Support_Details] OSD on OSD.OrganizationId = O.Id
				inner join [Organization_Support_Type] OST on OST.Id = OSD.SupportType
				where U.Id = @UserId
				for json auto
			)),
			[StressLevels] = json_query((select * from Stress_Levels for json auto))
        for
            json path, ROOT('SYNCED_DATA'))

		SELECT @JSONOutput AS JSON
	end
	else
	begin
		SET @JSONOutput = (select
			[MetaData.Sync] = json_query((
				select 
					'Diff' as [Type],
					@curVer as 'Version',
					@reason as 'ReasonCode'
				for json path
			)),
			[Event_Question_Answers] = json_query((
				select
					CT.SYS_CHANGE_OPERATION as '$operation',
					EQA.*
				from [Users] U
				inner join [Event] E on E.UserId = U.Id
				left join [Event_Question_Answers] EQA on EQA.EventId = E.EventId
				right outer join changetable(changes dbo.Event_Question_Answers, @fromVersion) as CT on CT.AnswerId = EQA.AnswerId
				where U.Id = @UserId
				for json path
			)),
			[EventType] = json_query((
				select
					CT.SYS_CHANGE_OPERATION as '$operation',
					ET.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Sector] S on S.SectorId = O.SectorId
				inner join [EventType] ET on ET.sectorid = S.SectorId
				right outer join changetable(changes dbo.EventType, @fromVersion) as CT on CT.EventTypeId = ET.EventTypeId
				where U.Id = @UserId
				for json path
			)),
			[EventType_Organization_QuestionValue] = json_query((
				select
					CT.SYS_CHANGE_OPERATION as '$operation',
					ETOQV.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join EventType_Organization_QuestionValue ETOQV on ETOQV.OrganizationId = O.Id
				right outer join changetable(changes dbo.[EventType_Organization_QuestionValue], @fromVersion) as CT on CT.QuestionValueId = ETOQV.QuestionValueId
				where U.Id = @UserId
				for json path
			)),
			[Organization] = json_query((
				select
					CT.SYS_CHANGE_OPERATION as '$operation',
					O.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				right outer join changetable(changes dbo.Organization, @fromVersion) as CT on CT.Id = O.Id
				where U.Id = @UserId
				for json path
			)),
			[Question_Categories] = json_query((
				select 
					DISTINCT CT.SYS_CHANGE_OPERATION as '$operation',
					QC.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Sector] S on S.SectorId = O.SectorId
				inner join [Questions_Sectors] QS on QS.SectorId = S.SectorId
				inner join [Questions] Q on Q.QuestionId = QS.QuestionId
				inner join [Question_Categories] QC on QC.QuestionCategoryId = Q.QuestionCategoryId
				right outer join changetable(changes dbo.Question_Categories, @fromVersion) as CT on CT.QuestionCategoryId = QC.QuestionCategoryId
				where U.Id = @UserId
				for json path
			)),
			[Question_Types] = json_query((
				select
					DISTINCT CT.SYS_CHANGE_OPERATION as '$operation',
					QT.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Sector] S on S.SectorId = O.SectorId
				inner join [Questions_Sectors] QS on QS.SectorId = S.SectorId
				inner join [Questions] Q on Q.QuestionId = QS.QuestionId
				inner join [Question_Types] QT on QT.QuestionTypeId = Q.QuestionTypeId
				right outer join changetable(changes dbo.Question_Types, @fromVersion) as CT on CT.QuestionTypeId = QT.QuestionTypeId
				where U.Id = @UserId
				for json path
			)),
			[Questions] = json_query((
				select
					CT.SYS_CHANGE_OPERATION as '$operation',
					Q.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Sector] S on S.SectorId = O.SectorId
				inner join [Questions_Sectors] QS on QS.SectorId = S.SectorId
				inner join [Questions] Q on Q.QuestionId = QS.QuestionId
				right outer join changetable(changes dbo.Questions, @fromVersion) as CT on CT.QuestionId = Q.QuestionId
				where U.Id = @UserId
				for json path
			)),
			[Questions_Sectors] = json_query((
				select
					CT.SYS_CHANGE_OPERATION as '$operation',
					QS.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Sector] S on S.SectorId = O.SectorId
				inner join [Questions_Sectors] QS on QS.SectorId = S.SectorId
				right outer join changetable(changes dbo.Questions_Sectors, @fromVersion) as CT on CT.Question_Sector_Id = QS.Question_Sector_Id
				where U.Id = @UserId
				for json path
			)),
			[Sector] = json_query((
				select
					CT.SYS_CHANGE_OPERATION as '$operation',
					S.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Sector] S on S.SectorId = O.SectorId
				right outer join changetable(changes dbo.Sector, @fromVersion) as CT on CT.SectorId = S.SectorId
				where U.Id = @UserId
				for json path
			)),
			[Sector_Question_Options] = json_query((
				select
					CT.SYS_CHANGE_OPERATION as '$operation',
					SQO.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Sector] S on S.SectorId = O.SectorId
				inner join [Questions_Sectors] QS on QS.SectorId = S.SectorId
				inner join [Questions] Q on Q.QuestionId = QS.QuestionId
				inner join [Sector_Question_Options] SQO on SQO.QuestionId = Q.QuestionId and SQO.SectorId = S.SectorId
				right outer join changetable(changes dbo.Sector_Question_Options, @fromVersion) as CT on CT.SectorOptionId = SQO.SectorOptionId
				where U.Id = @UserId
				for json path
			)),
			[Users] = json_query((
				select 
					CT.SYS_CHANGE_OPERATION as '$operation',
					U.*
				from dbo.Users as U
				right outer join changetable(changes dbo.Users, @fromVersion) as CT on CT.Id = U.Id
				where U.Id = @UserId
				for json path
			)),
			[Events] = json_query((
				select
					CT.SYS_CHANGE_OPERATION as '$operation',
					E.*
				from [Users] U
				inner join [Event] E on E.UserId = U.Id
				right outer join changetable(changes dbo.[Event], @fromVersion) as CT on CT.EventId = E.EventId
				where U.Id = @UserId
				for json path
			)),
			[Organization_Support_Details] = json_query((
				select
					CT.SYS_CHANGE_OPERATION as '$operation',
					OSD.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Organization_Support_Details] OSD on OSD.OrganizationId = O.Id
				right outer join changetable(changes dbo.[Organization_Support_Details], @fromVersion) as CT on CT.Id = OSD.Id
				where U.Id = @UserId
				for json path
			)),
			[Organization_Support_Type] = json_query((
				select
					CT.SYS_CHANGE_OPERATION as '$operation',
					OST.*
				from [Users] U
				inner join [Organization] O on O.Id = U.OrganizationId
				inner join [Organization_Support_Details] OSD on OSD.OrganizationId = O.Id
				inner join [Organization_Support_Type] OST on OST.Id = OSD.SupportType
				right outer join changetable(changes dbo.[Organization_Support_Type], @fromVersion) as CT on CT.Id = OST.Id
				where U.Id = @UserId
				for json path
			)),
			[StressLevels] = json_query((
				select
					CT.SYS_CHANGE_OPERATION as '$operation',
					SL.*
				from Stress_Levels SL
				right outer join changetable(changes dbo.[Stress_Levels], @fromVersion) as CT on CT.Id = SL.Id
				for json path
			))
		for
			json path, ROOT('SYNCED_DATA'))
		
		SELECT @JSONOutput AS JSON
	end
END