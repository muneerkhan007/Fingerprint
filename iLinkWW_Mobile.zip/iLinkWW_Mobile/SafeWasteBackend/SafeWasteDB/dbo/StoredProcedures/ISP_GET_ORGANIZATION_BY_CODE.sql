﻿CREATE PROCEDURE [dbo].[ISP_GET_ORGANIZATION_BY_CODE]
	@code varchar(50)
AS
	SELECT * from Organization where Code=@code;
RETURN 0
