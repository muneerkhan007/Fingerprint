﻿CREATE PROCEDURE [dbo].[ISP_GET_ALL_EVENTS_BY_ORGANIZATION_CODE]
	@code nvarchar(max)
AS
BEGIN
	select
		E.EventId,
		E.EventDate,
		E.EventTypeId,
		ET.EventTypeName,
		ET.sectorid,
		S.SectorName,
		QS.QuestionId,
		Q.QuestionText,
		Q.QuestionCategoryId,
		QC.QuestionCategoryName,
		EQA.AnswerId,
		EQA.OptionId,
		EQA.AnswerText,
		EQA.[Value],
		EQA.SentimentalValue
	from
		[Users] U
	left join
		[Organization] O on O.Id = U.OrganizationId
	left join
		[Event] E on E.UserId = U.Id
	left join
		[EventType] ET on ET.EventTypeId = E.EventTypeId
	left join
		[Sector] S on S.SectorId = ET.SectorId
	left join
		[Questions_Sectors] QS on QS.SectorId = S.SectorId
	left join
		[Questions] Q on Q.QuestionId = QS.QuestionId
	left join
		[Question_Categories] QC on QC.QuestionCategoryId = Q.QuestionCategoryId
	left join
		[Event_Question_Answers] EQA on EQA.QuestionId = QS.QuestionId and EQA.EventId = E.EventId
	where O.Code = @code
END
