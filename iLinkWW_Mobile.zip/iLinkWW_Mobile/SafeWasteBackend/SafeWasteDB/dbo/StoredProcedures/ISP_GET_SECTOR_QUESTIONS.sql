﻿CREATE PROCEDURE [dbo].[ISP_GET_SECTOR_QUESTIONS]
	@SectorId int
AS
	select *, (Select STRING_AGG( Convert(VARCHAR(10),sqo.SectorOptionId) + ',' + sqo.OptionText + ',' + ISNULL(sqo.Value,''),'|') from Sector_Question_Options sqo where sqo.QuestionId=q.QuestionId and sqo.SectorId=@SectorId) as options,
	(Select STRING_AGG( Convert(VARCHAR(10),evt.EventTypeId) + ',' + evt.EventTypeName ,'|') from EventType evt where evt.SectorId=@SectorId) as EventTypeOptions from 
		Questions q 
		inner join Question_Categories qc on qc.QuestionCategoryId= q.QuestionCategoryId
		inner join Questions_Sectors qs on qs.QuestionId=q.QuestionId and qs.SectorId=@SectorId
		inner join Question_Types qt on qt.QuestionTypeId = q.QuestionTypeId




RETURN 0
