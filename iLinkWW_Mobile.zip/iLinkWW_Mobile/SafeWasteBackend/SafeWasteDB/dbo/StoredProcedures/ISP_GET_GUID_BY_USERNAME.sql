﻿CREATE PROCEDURE [dbo].[ISP_GET_GUID_BY_USERNAME]
	@username nvarchar(max)
AS
BEGIN
	UPDATE [Users]
		SET GUID = NEWID()
	WHERE username = @username

	SELECT 
		*
	FROM [Users]
	WHERE username = @username
END
