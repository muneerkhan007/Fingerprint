﻿CREATE PROCEDURE [dbo].[ISP_INSERT_EVENT]
	@Id int = NULL,
	@UserId int,
	@EventDate datetime,
	@EventTypeId int
AS
	INSERT INTO Event(ID, UserId,EventDate,EventTypeId) VALUES(isnull(@Id, 0), @UserId,@EventDate,@EventTypeId);
	SELECT @@IDENTITY;

RETURN 0
