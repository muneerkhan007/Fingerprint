﻿CREATE PROCEDURE [dbo].[ISP_GET_EVENT_TYPES]
	@code nvarchar(50)
AS
BEGIN
	declare @Id int = (select Id from Organization where Code = @code)
	if (@Id is not null)
	begin
		select
			ETOQV.OrganizationId,
			ETOQV.QuestionValueId,
			ETOQV.EventTypeId,
			ET.EventTypeName,
			ETOQV.[Value]
		from EventType_Organization_QuestionValue ETOQV 
		inner join EventType ET on ET.EventTypeId = ETOQV.EventTypeId
	end
END