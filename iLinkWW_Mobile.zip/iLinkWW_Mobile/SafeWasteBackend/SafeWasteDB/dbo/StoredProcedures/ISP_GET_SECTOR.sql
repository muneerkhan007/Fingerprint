﻿CREATE PROCEDURE [dbo].[ISP_GET_SECTOR]
	@SectorId int
AS
	SELECT * from Sector where SectorId=@SectorId;
RETURN 0
