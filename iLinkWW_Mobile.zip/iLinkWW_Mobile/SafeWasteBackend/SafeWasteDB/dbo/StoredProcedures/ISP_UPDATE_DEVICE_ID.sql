﻿CREATE PROCEDURE [dbo].[ISP_UPDATE_DEVICE_ID]
	@UserId int,
	@DeviceId nvarchar(500)
AS
BEGIN
	update [Users] set DeviceId = @DeviceId where Id = @UserId
END