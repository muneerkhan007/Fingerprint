﻿CREATE PROCEDURE [dbo].[ISP_GET_USER]
	@id int
AS
	SELECT *
	from [Users] U
	inner join Organization O on U.OrganizationId = O.Id
	where U.Id = @id
RETURN 0
