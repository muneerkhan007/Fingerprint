﻿CREATE PROCEDURE [dbo].[ISP_INSERT_USER]
	@username nvarchar(1024),
	@password nvarchar(1024),
	@Code nvarchar(50),
	@Token nvarchar(MAX)
AS
BEGIN

	DECLARE @OrganizationId INT

	SELECT @OrganizationId=Id from Organization where Code=@Code;
	if(@OrganizationId is null)
		RETURN;

	if(NOT EXISTS(SELECT * from [Users] where username = @username))
	BEGIN
		INSERT INTO Users (username, HashedPassword, OrganizationId, Token, [GUID])
		VALUES (@username, @password, @OrganizationId, @Token, NEWID())
	
		SELECT
			*
		FROM [Users] U
		INNER JOIN Organization O ON U.OrganizationId = O.Id
		WHERE U.Id = @@IDENTITY
	END
END
