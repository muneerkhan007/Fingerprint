﻿CREATE PROCEDURE [dbo].[ISP_INSERT_EVENT_ANSWERS]
	@EventId int,
	@Answers UDT_EventAnswersTable readonly
AS
	INSERT INTO Event_Question_Answers (ID, EventId, QuestionId, QuestionText, OptionId, AnswerText, [Value], SentimentalValue)
	SELECT
		ID,
		@EventId,
		QuestionId,
		QuestionText,
		OptionId,
		AnswerText,
		case
			when [Value] is null or [Value] = 0
				then (select
						  [Value]
					  from Sector_Question_Options
					  where SectorOptionId = OptionId)
			when [Value] is not null
				then [Value]
			end as 'Value',
		SentimentalValue
	FROM @Answers
RETURN 0
