﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/


DELETE FROM Sector_Question_Options where QuestionId= 3;

SET IDENTITY_INSERT Sector ON
IF NOT EXISTS(SELECT 1 from Sector where SectorId = 1)
BEGIN
    INSERT INTO Sector(SectorId,SectorName)VALUES(1,'Education');
END
IF NOT EXISTS(SELECT 1 from Sector where SectorId = 2)
BEGIN
    INSERT INTO Sector(SectorId,SectorName)VALUES(2,'Paramedics');
END
IF NOT EXISTS(SELECT 1 from Sector where SectorId = 3)
BEGIN
    INSERT INTO Sector(SectorId,SectorName)VALUES(3,'Mining');
END

SET IDENTITY_INSERT Sector OFF

SET IDENTITY_INSERT Organization ON
IF NOT EXISTS(SELECT 1 from Organization where Id = 1)
BEGIN
    INSERT INTO Organization(Id,Code,SectorId)VALUES(1,'Test',1);
END

SET IDENTITY_INSERT Organization OFF



SET IDENTITY_INSERT Question_Categories ON
IF NOT EXISTS(SELECT 1 from Question_Categories where QuestionCategoryId = 1)
BEGIN
    INSERT INTO Question_Categories(QuestionCategoryId,QuestionCategoryName)VALUES(1,'About You');
END
IF NOT EXISTS(SELECT 1 from Question_Categories where QuestionCategoryId = 2)
BEGIN
    INSERT INTO Question_Categories(QuestionCategoryId,QuestionCategoryName)VALUES(2,'Event Details');
END
IF NOT EXISTS(SELECT 1 from Question_Categories where QuestionCategoryId = 3)
BEGIN
    INSERT INTO Question_Categories(QuestionCategoryId,QuestionCategoryName)VALUES(3,'Your Views');
END
IF NOT EXISTS(SELECT 1 from Question_Categories where QuestionCategoryId = 4)
BEGIN
    INSERT INTO Question_Categories(QuestionCategoryId,QuestionCategoryName)VALUES(4,'In Your Own words');
END


SET IDENTITY_INSERT Question_Categories OFF

SET IDENTITY_INSERT Question_Types ON
IF NOT EXISTS(SELECT 1 from Question_Types where QuestionTypeId = 1)
BEGIN
    INSERT INTO Question_Types(QuestionTypeId,QuestionTypeName,IsMultipleChoice)VALUES(1,'option',1);
END

IF NOT EXISTS(SELECT 1 from Question_Types where QuestionTypeId = 2)
BEGIN
    INSERT INTO Question_Types(QuestionTypeId,QuestionTypeName,IsMultipleChoice)VALUES(2,'text',0);
END
IF NOT EXISTS(SELECT 1 from Question_Types where QuestionTypeId = 3)
BEGIN
    INSERT INTO Question_Types(QuestionTypeId,QuestionTypeName,IsMultipleChoice)VALUES(3,'grade',0);
END

SET IDENTITY_INSERT Question_Types OFF




SET IDENTITY_INSERT Questions ON
IF NOT EXISTS(SELECT 1 from Questions where QuestionId= 1)
BEGIN
    INSERT INTO Questions(QuestionId,QuestionText,QuestionCategoryId,QuestionTypeId)VALUES(1,'What is your role?',1,1);
END
IF NOT EXISTS(SELECT 1 from Questions where QuestionId= 2)
BEGIN
    INSERT INTO Questions(QuestionId,QuestionText,QuestionCategoryId,QuestionTypeId)VALUES(2,'What is your experience level?',1,1);
END
IF NOT EXISTS(SELECT 1 from Questions where QuestionId= 3)
BEGIN
    INSERT INTO Questions(QuestionId,QuestionText,QuestionCategoryId,QuestionTypeId)VALUES(3,'What was the event type?',2,1);
END
IF NOT EXISTS(SELECT 1 from Questions where QuestionId= 4)
BEGIN
    INSERT INTO Questions(QuestionId,QuestionText,QuestionCategoryId,QuestionTypeId)VALUES(4,'Have you experienced a similar event before?',3,1);
END

IF NOT EXISTS(SELECT 1 from Questions where QuestionId= 5)
BEGIN
    INSERT INTO Questions(QuestionId,QuestionText,QuestionCategoryId,QuestionTypeId)VALUES(5,'How would you rate the stress level of the event?',3,1);
END

IF NOT EXISTS(SELECT 1 from Questions where QuestionId= 6)
BEGIN
    INSERT INTO Questions(QuestionId,QuestionText,QuestionCategoryId,QuestionTypeId)VALUES(6,'Was there anything you could have done differently that would have affected the outcome?',3,1);
END
IF NOT EXISTS(SELECT 1 from Questions where QuestionId= 7)
BEGIN
    INSERT INTO Questions(QuestionId,QuestionText,QuestionCategoryId,QuestionTypeId)VALUES(7,'Have you thought about the event much since then?',3,1);
END
IF NOT EXISTS(SELECT 1 from Questions where QuestionId= 8)
BEGIN
    INSERT INTO Questions(QuestionId,QuestionText,QuestionCategoryId,QuestionTypeId)VALUES(8,'Say how you feel about the event in your own words',4,2);
END
SET IDENTITY_INSERT Questions OFF



IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 1 and SectorId = 1)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(1,1);
END
IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 1 and SectorId = 2)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(1,2);
END
IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 1 and SectorId = 3)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(1,3);
END


IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 2 and SectorId = 1)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(2,1);
END
IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 2 and SectorId = 2)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(2,2);
END
IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 2 and SectorId = 3)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(2,3);
END


IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 3 and SectorId = 1)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(3,1);
END
IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 3 and SectorId = 2)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(3,2);
END
IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 3 and SectorId = 3)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(3,3);
END

IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 4 and SectorId = 1)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(4,1);
END
IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 4 and SectorId = 2)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(4,2);
END
IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 4 and SectorId = 3)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(4,3);
END

IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 5 and SectorId = 1)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(5,1);
END
IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 5 and SectorId = 2)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(5,2);
END
IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 5 and SectorId = 3)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(5,3);
END

IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 6 and SectorId = 1)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(6,1);
END
IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 6 and SectorId = 2)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(6,2);
END
IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 6 and SectorId = 3)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(6,3);
END

IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 7 and SectorId = 1)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(7,1);
END
IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 7 and SectorId = 2)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(7,2);
END
IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 7 and SectorId = 3)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(7,3);
END

IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 8 and SectorId = 1)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(8,1);
END
IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 8 and SectorId = 2)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(8,2);
END
IF NOT EXISTS(SELECT 1 from Questions_Sectors where QuestionId = 8 and SectorId = 3)
BEGIN
    INSERT INTO Questions_Sectors(QuestionId,SectorId)VALUES(8,3);
END

-- Sector_Question_options
--Sector Id - 1 and Question id - 1

IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 1 and SectorId = 1 )
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(1,1,'Trainee');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(1,1,'NQT');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(1,1,'Experienced Teacher');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(1,1,'Teaching Assistant');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(1,1,'Special Needs');
END
--Sectorid=1 and Question Id - 2
IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 2 and SectorId = 1)
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(2,1,'Graduate');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(2,1,'1-2 Years');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(2,1,'3-5 Years');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(2,1,'6-10 Years');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(2,1,'10+ Years');
END



-- Sector id - 1 and QuestionId - 3
IF NOT EXISTS ( SELECT 1 from EventType where  SectorId = 1)
BEGIN
    INSERT INTO EventType(sectorid,EventTypeName) VALUES(1,'Staff Meeting');
    INSERT INTO EventType(sectorid,EventTypeName) VALUES(1,'Parents Evening');
    INSERT INTO EventType(sectorid,EventTypeName) VALUES(1,'Department Meeting');
   INSERT INTO EventType(sectorid,EventTypeName)VALUES(1,'Staff Appraisal');
    INSERT INTO EventType(sectorid,EventTypeName) VALUES(1,'Fight in playground');
    INSERT INTO EventType(sectorid,EventTypeName) VALUES(1,'Bullying Incident');
    INSERT INTO EventType(sectorid,EventTypeName) VALUES(1,'Teaching Assessment');
    INSERT INTO EventType(sectorid,EventTypeName) VALUES(1,'Placement');
END

-- Sector id - 1 and QuestionId - 4
IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 4 and SectorId = 1)
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(4,1,'Yes');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(4,1,'No');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(4,1,'Similar');
END
IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 5 and SectorId = 1)
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(5,1,'Mild');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(5,1,'Moderate');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(5,1,'High');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(5,1,'Severe');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(5,1,'Very Severe');
END
IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 6 and SectorId = 1)
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(6,1,'Yes');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(6,1,'No');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(6,1,'Similar');
    
END
IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 7 and SectorId = 1)
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(7,1,'Not at all');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(7,1,'Sometimes');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(7,1,'Frequently');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(7,1,'Yes all the time');
    
END

--Sectord Id 2

IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 1 and SectorId = 2 )
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(1,2,'Paramedic (Paramedic)');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(1,2,'Intensive care Paramedic (ICP)');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(1,2,'Retrieval Paramedic (RP)');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(1,2,'General Care Paramedic (GCP)');
END
--Sectorid=1 and Question Id - 2
IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 2 and SectorId = 2)
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(2,2,'Graduate');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(2,2,'1-2 Years');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(2,2,'3-5 Years');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(2,2,'6-10 Years');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(2,2,'10+ Years');
END
-- Sector id - 1 and QuestionId - 3
IF NOT EXISTS ( SELECT 1 from EventType where SectorId = 2)
BEGIN
    INSERT INTO EventType(sectorid,EventTypeName) VALUES(2,'Category 1');
    INSERT INTO EventType(sectorid,EventTypeName) VALUES(2,'Category 2');
    INSERT INTO EventType(sectorid,EventTypeName) VALUES(2,'Category 3');
    INSERT INTO EventType(sectorid,EventTypeName) VALUES(2,'Category 4');
    
END

-- Sector id - 1 and QuestionId - 4
IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 4 and SectorId = 2)
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(4,2,'Yes');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(4,2,'No');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(4,2,'Similar');
END
IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 5 and SectorId = 2)
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(5,2,'Mild');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(5,2,'Moderate');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(5,2,'High');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(5,2,'Severe');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(5,2,'Very Severe');
END
IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 6 and SectorId = 2)
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(6,2,'Yes');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(6,2,'No');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(6,2,'Similar');
    
END
IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 7 and SectorId = 2)
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(7,2,'Not at all');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(7,2,'Sometimes');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(7,2,'Frequently');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(7,2,'Yes all the time');
    
END

--Sector Id 3
IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 1 and SectorId = 3 )
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(1,3,'Contract Miner');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(1,3,'Development Miner');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(1,3,'Diamond Driller');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(1,3,'Electrician');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(1,3,'Environmental Coordinator');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(1,3,'Geologist');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(1,3,'Health & Safety Management');
END
--Sectorid=1 and Question Id - 2
IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 2 and SectorId = 3)
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(2,3,'Graduate');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(2,3,'1-2 Years');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(2,3,'3-5 Years');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(2,3,'6-10 Years');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(2,3,'10+ Years');
END
-- Sector id - 1 and QuestionId - 3
IF NOT EXISTS ( SELECT 1 from EventType where SectorId = 3)
BEGIN
    INSERT INTO EventType(sectorid,EventTypeName) VALUES(3,'Type 1');
    INSERT INTO EventType(sectorid,EventTypeName) VALUES(3,'Type 2');
    INSERT INTO EventType(sectorid,EventTypeName) VALUES(3,'Type 3');
    INSERT INTO EventType(sectorid,EventTypeName) VALUES(3,'Type 4');
    INSERT INTO EventType(sectorid,EventTypeName) VALUES(3,'Type 5');
    INSERT INTO EventType(sectorid,EventTypeName) VALUES(3,'Type 6');
    
END

-- Sector id - 1 and QuestionId - 4
IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 4 and SectorId = 3)
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(4,3,'Yes');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(4,3,'No');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(4,3,'Similar');
END
IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 5 and SectorId = 3)
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(5,3,'Mild');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(5,3,'Moderate');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(5,3,'High');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(5,3,'Severe');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(5,3,'Very Severe');
END
IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 6 and SectorId = 3)
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(6,3,'Yes');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(6,3,'No');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(6,3,'Similar');
    
END
IF NOT EXISTS ( SELECT 1 from Sector_Question_Options where QuestionId = 7 and SectorId = 3)
BEGIN
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(7,3,'Not at all');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(7,3,'Sometimes');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(7,3,'Frequently');
    INSERT INTO Sector_Question_Options(QuestionId,SectorId,OptionText) VALUES(7,3,'Yes all the time');
    
END

IF NOT EXISTS (SELECT 1 FROM Organization_Support_Type WHERE Id = 1 AND SupportType = 'Buddy')
BEGIN
	INSERT INTO Organization_Support_Type (Id, SupportType) VALUES (1, 'Buddy')
END

IF NOT EXISTS (SELECT 1 FROM Organization_Support_Type WHERE Id = 2 AND SupportType = 'Counsellor')
BEGIN
	INSERT INTO Organization_Support_Type (Id, SupportType) VALUES (2, 'Counsellor')
END

IF NOT EXISTS (SELECT 1 FROM Organization_Support_Type WHERE Id = 3 AND SupportType = 'Official')
BEGIN
	INSERT INTO Organization_Support_Type (Id, SupportType) VALUES (3, 'Official')
END

IF NOT EXISTS (SELECT 1 FROM Organization_Support_Type WHERE Id = 4 AND SupportType = 'Spiritual')
BEGIN
	INSERT INTO Organization_Support_Type (Id, SupportType) VALUES (4, 'Spiritual')
END

IF NOT EXISTS (SELECT 1 FROM Stress_Levels WHERE Id = 1 AND [Name] = 'Mild')
BEGIN
	INSERT INTO Stress_Levels (Id, [Name]) VALUES (1, 'Mild')
END

IF NOT EXISTS (SELECT 1 FROM Stress_Levels WHERE Id = 2 AND [Name] = 'Moderate')
BEGIN
	INSERT INTO Stress_Levels (Id, [Name]) VALUES (2, 'Moderate')
END

IF NOT EXISTS (SELECT 1 FROM Stress_Levels WHERE Id = 3 AND [Name] = 'High')
BEGIN
	INSERT INTO Stress_Levels (Id, [Name]) VALUES (3, 'High')
END

IF NOT EXISTS (SELECT 1 FROM Stress_Levels WHERE Id = 4 AND [Name] = 'Severe')
BEGIN
	INSERT INTO Stress_Levels (Id, [Name]) VALUES (4, 'Severe')
END

IF NOT EXISTS (SELECT 1 FROM Stress_Levels WHERE Id = 5 AND [Name] = 'Very Severe')
BEGIN
	INSERT INTO Stress_Levels (Id, [Name]) VALUES (5, 'Very Severe')
END

IF EXISTS (SELECT 1 FROM Organization WHERE Id = 1 AND Code = 'Test')
BEGIN
	UPDATE Organization SET NegativeSegementImpact = 20, RatingDifference = 30 WHERE Id = 1
END