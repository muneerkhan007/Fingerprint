﻿CREATE TABLE [dbo].[Sector_Question_Options]
(
	[SectorOptionId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [QuestionId] INT NOT NULL, 
    [SectorId] INT NOT NULL, 
    [OptionText] NVARCHAR(512) NOT NULL, 
    [Value] NVARCHAR(50) NULL, 
    CONSTRAINT [FK_Sector_Question_Options_Questions] FOREIGN KEY ([QuestionId]) REFERENCES [Questions]([QuestionId]), 
    CONSTRAINT [FK_Sector_Question_Options_Sector] FOREIGN KEY ([SectorId]) REFERENCES [Sector]([SectorId])
)
GO

ALTER TABLE [dbo].[Sector_Question_Options] ENABLE CHANGE_TRACKING
GO

