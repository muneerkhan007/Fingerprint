﻿CREATE TABLE [dbo].[Question_Types]
(
	[QuestionTypeId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [QuestionTypeName] NVARCHAR(MAX) NOT NULL, 
    [IsMultipleChoice] TINYINT NOT NULL
)
GO

ALTER TABLE [dbo].[Question_Types] ENABLE CHANGE_TRACKING
GO

