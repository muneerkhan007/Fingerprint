﻿CREATE TABLE [dbo].[Event]
(
	[EventId] INT NOT NULL PRIMARY KEY IDENTITY,
	[ID] INT NULL,
    [UserId] INT NOT NULL, 
    [EventTypeId] INT NULL, 
    [EventDate] DATETIME NOT NULL, 
    CONSTRAINT [FK_Event_To_Users] FOREIGN KEY ([UserId]) REFERENCES [Users]([Id]), 
    CONSTRAINT [FK_Event_ToTable_EventType] FOREIGN KEY ([EventTypeId]) REFERENCES [EventType]([EventTypeId])
)
GO

ALTER TABLE [dbo].[Event] ENABLE CHANGE_TRACKING
GO

