﻿CREATE TABLE [dbo].[Organization_Support_Type]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [SupportType] NVARCHAR(100) NOT NULL
)
GO

ALTER TABLE [dbo].[Organization_Support_Type] ENABLE CHANGE_TRACKING
GO