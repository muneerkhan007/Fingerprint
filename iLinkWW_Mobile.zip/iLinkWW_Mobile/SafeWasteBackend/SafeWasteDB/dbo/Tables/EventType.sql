﻿CREATE TABLE [dbo].[EventType]
(
	[EventTypeId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [EventTypeName] NVARCHAR(MAX) NULL, 
    [sectorid] INT NOT NULL, 
    CONSTRAINT [FK_EventType_Sector] FOREIGN KEY ([sectorid]) REFERENCES [Sector]([SectorId])
)
GO

ALTER TABLE [dbo].[EventType] ENABLE CHANGE_TRACKING
GO