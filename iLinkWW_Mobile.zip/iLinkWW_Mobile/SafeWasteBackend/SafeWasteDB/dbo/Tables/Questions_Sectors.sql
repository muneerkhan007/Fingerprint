﻿CREATE TABLE [dbo].[Questions_Sectors]
(
	[Question_Sector_Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [QuestionId] INT NOT NULL, 
    [SectorId] INT NOT NULL, 
    CONSTRAINT [FK_Questions_Sectors_Questions] FOREIGN KEY ([QuestionId]) REFERENCES [Questions]([QuestionId]), 
    CONSTRAINT [FK_Questions_Sectors_Sector] FOREIGN KEY ([SectorId]) REFERENCES [Sector]([SectorId])
)
GO

ALTER TABLE [dbo].[Questions_Sectors] ENABLE CHANGE_TRACKING
GO
