﻿CREATE TABLE [dbo].[Users]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [HashedPassword] NVARCHAR(1024) NOT NULL, 
    [username] NVARCHAR(1024) NULL, 
    [OrganizationId] INT NULL, 
    [Token] NVARCHAR(MAX) NULL, 
    [GUID] NVARCHAR(500) NULL,
    [DeviceId] NVARCHAR(500) NULL,
    CONSTRAINT [FK_Users_Organization] FOREIGN KEY ([OrganizationId]) REFERENCES [Organization]([Id])
)
GO

ALTER TABLE [dbo].[Users] ENABLE CHANGE_TRACKING
GO