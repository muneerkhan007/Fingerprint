﻿CREATE TABLE [dbo].[Organization]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Code] NVARCHAR(50) NOT NULL, 
    [SectorId] INT NULL, 
    [NegativeSegementImpact] INT NULL, 
    [RatingDifference] INT NULL, 
    [MaxEvents] INT NULL, 
    CONSTRAINT [FK_Organization_Sector] FOREIGN KEY ([SectorId]) REFERENCES [Sector]([SectorId])
)
GO

ALTER TABLE [dbo].[Organization] ENABLE CHANGE_TRACKING
GO

