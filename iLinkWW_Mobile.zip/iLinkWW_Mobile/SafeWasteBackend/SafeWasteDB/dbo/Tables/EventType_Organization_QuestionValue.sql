﻿CREATE TABLE [dbo].[EventType_Organization_QuestionValue]
(
	[QuestionValueId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [EventTypeId] INT NOT NULL, 
    [OrganizationId] INT NOT NULL, 
    [Value] INT NOT NULL, 
    CONSTRAINT [FK_EventType_Organization_QuestionValue_EventType] FOREIGN KEY ([EventTypeId]) REFERENCES [EventType]([EventTypeId]), 
    CONSTRAINT [FK_EventType_Organization_QuestionValue_Organization] FOREIGN KEY ([OrganizationId]) REFERENCES [Organization]([Id]),
	CONSTRAINT [FK_EventType_Organization_QuestionValue_Stress_Levels] FOREIGN KEY ([Value]) REFERENCES [Stress_Levels]([Id]) 
)
GO

ALTER TABLE [dbo].[EventType_Organization_QuestionValue] ENABLE CHANGE_TRACKING
GO
