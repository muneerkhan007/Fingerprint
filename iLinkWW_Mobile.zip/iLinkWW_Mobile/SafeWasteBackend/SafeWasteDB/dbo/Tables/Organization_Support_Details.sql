﻿CREATE TABLE [dbo].[Organization_Support_Details]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [OrganizationId] INT NOT NULL, 
    [SupportType] INT NOT NULL, 
    [ContactNumber] NVARCHAR(250) NULL, 
    [Email] NVARCHAR(500) NULL,
	CONSTRAINT [FK_Organization_Support_Details_To_Organization_Support_Type] FOREIGN KEY ([SupportType]) REFERENCES [Organization_Support_Type]([Id]), 
)
GO

ALTER TABLE [dbo].[Organization_Support_Details] ENABLE CHANGE_TRACKING
GO
