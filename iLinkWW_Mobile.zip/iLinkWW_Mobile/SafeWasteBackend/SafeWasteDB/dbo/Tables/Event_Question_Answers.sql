﻿CREATE TABLE [dbo].[Event_Question_Answers]
(
	[AnswerId] INT NOT NULL PRIMARY KEY IDENTITY,
	[ID] INT NULL,
    [EventId] INT NOT NULL, 
    [QuestionId] INT NOT NULL, 
    [QuestionText] NVARCHAR(MAX) NOT NULL, 
    [OptionId] INT NULL, 
    [AnswerText] NVARCHAR(MAX) NOT NULL, 
    [Value] INT NULL,
	[SentimentalValue] INT NULL,
    CONSTRAINT [FK_Event_Question_Answers_Event] FOREIGN KEY ([EventId]) REFERENCES [Event]([EventId]), 
    CONSTRAINT [FK_Event_Question_Answers_Questions] FOREIGN KEY ([QuestionId]) REFERENCES [Questions]([QuestionId]),
	CONSTRAINT [FK_Event_Question_Answers_Stress_Levels] FOREIGN KEY ([Value]) REFERENCES [Stress_Levels]([Id]) 
)
GO

ALTER TABLE [dbo].[Event_Question_Answers] ENABLE CHANGE_TRACKING
GO