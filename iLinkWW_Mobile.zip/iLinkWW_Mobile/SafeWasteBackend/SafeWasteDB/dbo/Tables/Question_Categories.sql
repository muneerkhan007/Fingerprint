﻿CREATE TABLE [dbo].[Question_Categories]
(
	[QuestionCategoryId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [QuestionCategoryName] NVARCHAR(512) NOT NULL
)
GO

ALTER TABLE [dbo].[Question_Categories] ENABLE CHANGE_TRACKING
GO
