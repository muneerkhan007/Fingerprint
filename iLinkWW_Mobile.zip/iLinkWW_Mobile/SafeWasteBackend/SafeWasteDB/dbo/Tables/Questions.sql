﻿CREATE TABLE [dbo].[Questions]
(
	[QuestionId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [QuestionText] NVARCHAR(MAX) NOT NULL, 
    [QuestionCategoryId] INT NOT NULL, 
    [QuestionTypeId] INT NOT NULL, 
    CONSTRAINT [FK_Questions_Question_Categories] FOREIGN KEY ([QuestionCategoryId]) REFERENCES [Question_Categories]([QuestionCategoryId]), 
    CONSTRAINT [FK_Questions_Question_Types] FOREIGN KEY ([QuestionTypeId]) REFERENCES [Question_Types]([QuestionTypeId])
)
GO

ALTER TABLE [dbo].[Questions] ENABLE CHANGE_TRACKING
GO
