﻿CREATE TABLE [dbo].[Stress_Levels]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Name] NVARCHAR(250) NOT NULL
)
GO

ALTER TABLE [dbo].[Stress_Levels] ENABLE CHANGE_TRACKING
GO
