﻿CREATE TYPE [dbo].[UDT_EventAnswersTable] AS TABLE
(
	ID INT,
	QuestionId INT, 
	QuestionText nvarchar(MAX),
	OptionId INT,
	AnswerText nvarchar(MAX),
	[Value] int,
	SentimentalValue int
)
