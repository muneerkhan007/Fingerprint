import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { EventModel } from 'src/Shared/Models/API/EventModel';

@Injectable({ providedIn: "root", })

export class UserService {
    private apiURL: string = null;
    private appURL: string = '/users';

    constructor (private http: HttpClient) {
        this.apiURL = environment.apiURL;
    }

    public getProfileLinkURI(userName: string): Observable<object> {
        return this.http.get<object>(this.apiURL + this.appURL + '/profile-uri/' + userName, {responseType: 'json'});
    }

    public getQuestionsWithAnswers(cipherUserId: string): Observable<Array<EventModel>> {
        return this.http.get<Array<EventModel>>(this.apiURL + this.appURL + '/profile-report-questions/' + cipherUserId, {responseType: 'json'});
    }
}