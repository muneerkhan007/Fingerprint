import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, observable } from 'rxjs';

import { UserService } from './services/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {
  public isShow: boolean = false;
  public userName: string;

  constructor(private router: Router, private userService: UserService) { }

  public ngOnInit() {
    this.userName = 'abhinav@inncrewin.com';
  }

  public generateProfileLink(): void {
    if (this.userName != '')
      this.userService.getProfileLinkURI(this.userName).subscribe(
        (response: any) =>
        {
          if (response.profileReportURI && response.profileReportURI != '')
            this.router.navigate(["/profile-report/" + response.profileReportURI]);
          this.isShow = true;
        }
      );
  }
}
