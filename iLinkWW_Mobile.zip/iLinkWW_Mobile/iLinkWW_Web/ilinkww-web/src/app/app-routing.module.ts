import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { ProfileReportViewerComponent } from './components/profile-report-viewer/profile-report-viewer.component';

const routes: Routes = [
  { path: 'profile-report/:id', component: ProfileReportViewerComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule {
  
}
