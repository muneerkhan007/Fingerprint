import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { strict } from 'assert';
import { UserService } from 'src/app/services/user.service';
import { EventModel, EventsUIModel, QuestionAnswerModel, QuestionCategories, SentimentalStress, SortOrder, StressLevel } from 'src/Shared/Models/API/EventModel';

declare var $: any;

@Component({
  selector: 'app-profile-report-viewer',
  templateUrl: './profile-report-viewer.component.html',
  styleUrls: ['./profile-report-viewer.component.scss']
})

export class ProfileReportViewerComponent implements OnInit {
  public isLoaded: boolean = false;
  public currentFilter: number = 0;
  public questions: Array<QuestionAnswerModel>;
  public eventAnswers: EventsUIModel;
  public filterText: string;
  public searchText: string;

  constructor(private route: ActivatedRoute, private userService: UserService) { }

  ngOnInit(): void {
    if (this.route.snapshot.paramMap.get('id'))
      this.userService.getQuestionsWithAnswers(this.route.snapshot.paramMap.get('id')).subscribe((response: Array<EventModel>) => {
        this.isLoaded = true;

        this.questions = new Array<QuestionAnswerModel>();
        this.eventAnswers = new EventsUIModel();
        this.eventAnswers.Events = new Array<EventModel>();

        for (var eIdx: number = 0; eIdx < response.length; eIdx++) {
          var answeredCount: number = 0;
          response[eIdx].display = true;
          for (var qIdx: number = 0; qIdx < response[eIdx].questionAnswerModels.length; qIdx++) {
            var question: QuestionAnswerModel = new QuestionAnswerModel();

            question.categoryId = response[eIdx].questionAnswerModels[qIdx].categoryId;
            question.questionId = response[eIdx].questionAnswerModels[qIdx].questionId;
            question.questionText = response[eIdx].questionAnswerModels[qIdx].questionText;

            // change role and experience related questions to single words.
            if (question.categoryId == QuestionCategories.ABOUT_YOU) {
              if (question.questionText.includes('role'))
                question.questionText = "Role";
              else if (question.questionText.includes('experience'))
                question.questionText = "Experience";
            }
            if (!this.questions.find((que: QuestionAnswerModel) => que.questionId == question.questionId))
              this.questions.push(question);

            // update answeredCount
            if (response[eIdx].questionAnswerModels[qIdx].optionId > 0 || (response[eIdx].questionAnswerModels[qIdx].optionText != ''
              && response[eIdx].questionAnswerModels[qIdx].optionText))
              answeredCount++;

            // put - for un-answered questions
            if (!response[eIdx].questionAnswerModels[qIdx].optionText || response[eIdx].questionAnswerModels[qIdx].optionText == '') {
              response[eIdx].questionAnswerModels[qIdx].optionText = '-'
            }

            if (response[eIdx].questionAnswerModels[qIdx].optionId == -1) {
              if (response[eIdx].questionAnswerModels[qIdx].sentimentalValue == SentimentalStress.positive)
                response[eIdx].questionAnswerModels[qIdx].optionText = 'Positive';
              else if (response[eIdx].questionAnswerModels[qIdx].sentimentalValue == SentimentalStress.negative)
                response[eIdx].questionAnswerModels[qIdx].optionText = 'Negative';
              else if (response[eIdx].questionAnswerModels[qIdx].sentimentalValue == SentimentalStress.neutral)
                response[eIdx].questionAnswerModels[qIdx].optionText = 'Neutral';
              else
                response[eIdx].questionAnswerModels[qIdx].optionText = 'Unknown';
            }
          }

          // sort by question id
          response[eIdx].questionAnswerModels.sort(function (a, b) {
            return a.questionId - b.questionId;
          });
          this.questions.sort(function (a, b) {
            return a.questionId - b.questionId;
          });

          // percentage of answered questions value 
          var completedPercentage: QuestionAnswerModel = new QuestionAnswerModel();
          completedPercentage.questionId = -1
          completedPercentage.questionText = 'Completed'

          var percentageValue: number = Number(((answeredCount / response[eIdx].questionAnswerModels.length) * 100).toFixed(2))
          if (percentageValue == 100)
            completedPercentage.value = StressLevel.MINOR;
          else if (percentageValue >= 70 && percentageValue <= 100)
            completedPercentage.value = StressLevel.AVERAGE;
          else
            completedPercentage.value = StressLevel.SEVERE;

          completedPercentage.optionText = ((answeredCount / response[eIdx].questionAnswerModels.length) * 100).toFixed(2) + ' %'

          response[eIdx].questionAnswerModels.push(completedPercentage)
          // response[eIdx].completedPercentage = ((answeredCount / response[eIdx].questionAnswerModels.length) * 100).toFixed(2);
        }

        // percentage of answered questions value 
        var completedPercentage: QuestionAnswerModel = new QuestionAnswerModel()
        completedPercentage.questionId = -1
        completedPercentage.questionText = 'Completed'
        this.questions.push(completedPercentage);


        this.eventAnswers.Events = response;
      });
  }

  getClass(question: QuestionAnswerModel): string {
    if (question.value) {
      switch (parseInt(String(question.value))) {
        case StressLevel.NOT_APPLICABLE:
          return "#9BA0A4";
        case StressLevel.MINOR:
        case StressLevel.MILD:
          return "#4DFA90";
        case StressLevel.AVERAGE:
          return '#FABE4D';
        case StressLevel.INTENSE:
        case StressLevel.SEVERE:
          return '#FF5468';
        default:
          return '#FFFFFF';
      }
    }
    else if (question.sentimentalValue) {
      switch (parseInt(String(question.sentimentalValue))) {
        case SentimentalStress.positive:
          return "#4DFA90";
        case SentimentalStress.neutral:
          return '#FABE4D';
        case SentimentalStress.negative:
          return '#FF5468';
        default:
          return '#DDDDDD';
      }
    }
    else {
      return '#FFFFFF'
    }
  }

  search(event: any) {
    this.eventAnswers.Events.forEach((eve: any) => {
      var matched: boolean = false;

      eve.questionAnswerModels.forEach((answer: any) => {
        if (answer.optionText && answer.optionText.toLowerCase().indexOf(this.searchText.toLowerCase()) > -1) {
          matched = true;
        }
      });

      eve.display = matched;
    });
  }

  sort(questionId: number) {
    // get current sort order of the table.
    this.questions.forEach((question: QuestionAnswerModel) => {
      if (question.questionId == questionId) {
        if (this.eventAnswers.selectedQuestion && this.eventAnswers.selectedQuestion.questionId == questionId) {
          if (this.eventAnswers.sortedBy == SortOrder.ASCENDING)
            this.eventAnswers.sortedBy = SortOrder.DESCENDING;
          else
            this.eventAnswers.sortedBy = SortOrder.ASCENDING;
        }
        else {
          this.eventAnswers.selectedQuestion = question;
          this.eventAnswers.sortedBy = SortOrder.ASCENDING;
        }
      }
    })

    // find the elements and create an array.
    var strArray: Array<string> = new Array<string>();
    this.eventAnswers.Events.forEach((tEvent: EventModel) => {
      tEvent.questionAnswerModels.forEach((answer: QuestionAnswerModel) => {
        if (answer.questionId == questionId)
          strArray.push(answer.optionText);
      });
    });

    // sort the newly created array
    if (this.eventAnswers.sortedBy == SortOrder.DESCENDING)
      strArray = strArray.sort().reverse();
    else
      strArray = strArray.sort();

    // re-arrange the main array as per the sorting order.
    var tEvents: Array<EventModel> = new Array<EventModel>()
    strArray.forEach((value: string) => {
      this.eventAnswers.Events.forEach((tEvent: EventModel) => {
        for (var idx: number = 0; idx < tEvent.questionAnswerModels.length; idx++) {
          var answer: QuestionAnswerModel = tEvent.questionAnswerModels[idx]
          if (answer.questionId == questionId) {
            if ((!answer.optionText && answer.optionText == value) || (answer.optionText && value && answer.optionText.toLowerCase() == value.toLowerCase())) {
              var matchedEvent: EventModel = tEvents.find((eve: EventModel) => { return eve.eventId == tEvent.eventId })
              if (!matchedEvent)
                tEvents.push(tEvent)
            }
            break;
          }
        }
      })
    })

    // refresh the original array.
    if (this.eventAnswers.Events.length != tEvents.length)
      alert('Sorting failed !');
    else
      this.eventAnswers.Events = tEvents;
  }

  filter() {
    this.eventAnswers.Events.forEach((eve: any) => {
      var matched: boolean = false
      eve.display = true;
      if (this.currentFilter != 0 && this.filterText != '') {
        eve.questionAnswerModels.forEach((answer: any) => {
          if (answer.questionId == this.currentFilter && answer.optionText && answer.optionText.toLowerCase().indexOf(this.filterText.toLowerCase()) > -1)
            matched = true
        })

        eve.display = matched
      }
    })
  }

  display(value: string) {
    return value;
  }

  update(questionId: number) {
    this.filterText = '';
    this.currentFilter = questionId;
  }

  clearAllFilters() {
    this.searchText = '';
    this.filterText = '';
    this.currentFilter = 0;
    this.filter();
  }
}
