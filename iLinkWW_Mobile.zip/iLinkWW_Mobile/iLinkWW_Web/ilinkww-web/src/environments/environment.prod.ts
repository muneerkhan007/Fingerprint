export const environment = {
  production: true,
  apiURL: 'https://ilinkww.azurewebsites.net/api'
};
