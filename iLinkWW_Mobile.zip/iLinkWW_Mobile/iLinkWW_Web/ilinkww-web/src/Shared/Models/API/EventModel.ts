// export class Organization {
//     public code: string;
//     public sector: SectorModel;
//     public events: Array<EventModel>;
// }

export class SectorModel {
    public sectorId: number;
    public sectorName: string;
}

export class EventsUIModel {
    public Events: Array<EventModel> = new Array<EventModel>();
    public display: boolean = false;
    public selectedQuestion: QuestionAnswerModel;
    public sortedBy: SortOrder = SortOrder.NONE;
}

export class EventModel {
    public eventId: number;
    public eventDate: Date;
    public completedPercentage: number;
    public questionAnswerModels: Array<QuestionAnswerModel>;
    public display: boolean = false;
}

export class QuestionAnswerModel {
    public categoryId: number;
    public questionId: number;
    public questionText: string;
    public optionId: number;
    public optionText: string;
    public value: StressLevel;
    public sentimentalValue: SentimentalStress;
}

export enum SortOrder {
    NONE = 0,
    ASCENDING = 1,
    DESCENDING = 2
}

export enum QuestionCategories {
    ABOUT_YOU = 1,
    EVENT_DETAILS = 2,
    YOUR_VIEWS = 3,
    IN_YOUR_OWN_WORDS = 4
}

export enum StressLevel {
    MINOR = 1,
    MILD = 2,
    AVERAGE = 3,
    INTENSE = 4,
    SEVERE = 5,
    NOT_APPLICABLE = 6 
}
export enum SentimentalStress {
    positive = 1,
    neutral = 2,
    negative = 3
}