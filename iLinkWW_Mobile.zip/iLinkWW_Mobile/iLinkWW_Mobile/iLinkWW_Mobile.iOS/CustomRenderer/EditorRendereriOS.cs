﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Foundation;
using iLinkWW_Mobile.CustomControls;
using iLinkWW_Mobile.iOS.CustomRenderer;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(CustomEditor), typeof(EditorRendereriOS))]
namespace iLinkWW_Mobile.iOS.CustomRenderer
{
    class EditorRendereriOS:EditorRenderer
    {
        protected override void OnElementChanged(ElementChangedEventArgs<Editor> e)
        {
            base.OnElementChanged(e);
            if (Control != null)
                Control.BackgroundColor =UIColor.Clear;
        }
    }
}