﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Foundation;
using iLinkWW_Mobile.CustomControls;
using iLinkWW_Mobile.iOS.CustomRenderer;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(CustomEntry), typeof(EntryRendereriOS))]
namespace iLinkWW_Mobile.iOS.CustomRenderer
{
    public class EntryRendereriOS:EntryRenderer
    {
        protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
        {
            base.OnElementChanged(e);
            if(Control!=null)
            Control.BorderStyle = UITextBorderStyle.None;
        }
    }
}