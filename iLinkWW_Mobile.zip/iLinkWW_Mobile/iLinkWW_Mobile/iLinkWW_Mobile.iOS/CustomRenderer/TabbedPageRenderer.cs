﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CoreGraphics;
using Foundation;
using iLinkWW_Mobile.iOS.CustomRenderer;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;
[assembly:ExportRenderer(typeof(TabbedPage),typeof(TabbedPageRenderer))]
namespace iLinkWW_Mobile.iOS.CustomRenderer
{
    public class TabbedPageRenderer : TabbedRenderer
    {
        public override void ViewDidLayoutSubviews()
        {
            base.ViewDidLayoutSubviews();
            TabBar.Frame = new CGRect(x: 0, y: 0, width: TabBar.Frame.Size.Width, height: TabBar.Frame.Size.Height);
        }


    }
}