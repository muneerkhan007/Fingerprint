﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace iLinkWW_Mobile.Models
{
    public class EventTypeModel
    {
        [JsonProperty("$operation")]
        public string Operation { get; set; }
        [PrimaryKey]
        public int EventTypeId { get; set; }

        [JsonProperty("EventTypeName")]
        public string EventType { get; set; }
        [SQLiteNetExtensions.Attributes.ForeignKey(typeof(QuestionModel))]
        public int QuestionId { get; set; }
    }
}
