﻿using iLinkWW_Mobile.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;



public class MetaData
{
    public List<DBMetaDataModel> Sync { get; set; }
}



public class OrganizationData
{
    [JsonProperty("$operation")]
    public string Operation { get; set; }
    public int Id { get; set; }
    public string Code { get; set; }
    public int SectorId { get; set; }
}





public class QuestionsSector
{
    public int Question_Sector_Id { get; set; }
    public int QuestionId { get; set; }
    public int SectorId { get; set; }

    [JsonProperty("$operation")]
    public string Operation { get; set; }
}

public class Sector
{
    public int SectorId { get; set; }
    public string SectorName { get; set; }
    [JsonProperty("$operation")]
    public string Operation { get; set; }
}


public class User
{
    public int Id { get; set; }
    public string HashedPassword { get; set; }
    public string username { get; set; }
    public int? OrganizationId { get; set; }
    public string Token { get; set; }
}

public class SYNCEDDATA
{
    public MetaData MetaData { get; set; }
    public List<Event_Question_AnswersModel> Event_Question_Answers { get; set; }
    public List<EventTypeModel> EventType { get; set; }
    public List<OrganizationData> Organization { get; set; }

    public List<EventType_Organization_QuestionValueModel> EventType_Organization_QuestionValue { get; set; }
    public List<QuestionCategoryModel> Question_Categories { get; set; }
    public List<TypeModel> Question_Types { get; set; }
    public List<QuestionModel> Questions { get; set; }
    public List<QuestionsSector> Questions_Sectors { get; set; }
    public List<Sector> Sector { get; set; }
    public List<Sector_Question_OptionModel> Sector_Question_Options { get; set; }
    public List<User> Users { get; set; }

    public List<EventModel> Events { get; set; }
    public List<OrgnizationSupportDetailModel> Organization_Support_Details { get; set; }
    public List<OrganizationSupportTypeModel> Organization_Support_Type { get; set; }
}

public class ResponseSyncGetTableDataModal
{
    public List<SYNCEDDATA> SYNCED_DATA { get; set; }
}