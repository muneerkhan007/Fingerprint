﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Xamarin.Forms;

namespace iLinkWW_Mobile.Models
{
    public class QuestionType
    {
        public int typeId { get; set; }
        public string typeName { get; set; }
        public bool isMultipleChoice { get; set; }
    }

    public class QuestionOption
    {
        public int optionId { get; set; }
        public string optionText { get; set; }
        public string value { get; set; }
    }

    public class Question
    {
        public int questionId { get; set; }
        public string text { get; set; }

        public bool IsMandatory { get; set; }
        public QuestionType questionType { get; set; }
        public List<QuestionOption> questionOptions { get; set; }
        /// <summary>
        /// This property is used for getting answer through binding and not related to json converstion process
        /// </summary>
        public int OptionId { get; set; }
        public string OptionText { get; set; }
        public int Value { get; set; }
        public SentimentalEnum SentimentalValue { get; set; }
    }

    public class Category
    {
        public int categoryId { get; set; }
        public string categoryName { get; set; }
        public List<Question> questions { get; set; }

        /// <summary>
        /// This property is used for getting answer through binding and not related to json converstion process
        /// </summary>
        public ObservableCollection<QuestionAnswerModel> AnswerModel { get; set; } = new ObservableCollection<QuestionAnswerModel>();
    }

    public class ResponseGetEventModel 
    {
        public List<Category> MyArray { get; set; }
    }


}
