﻿using Newtonsoft.Json;
using SQLite;
using SQLiteNetExtensions.Attributes;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace iLinkWW_Mobile.Models
{
    public class QuestionCategoryModel
    {
        [PrimaryKey, AutoIncrement]
        public int QuestionCategoryId { get; set; }
        public string QuestionCategoryName { get; set; }

        [OneToMany(CascadeOperations = CascadeOperation.All)]      // One to many relationship with Valuation
        public ObservableCollection<QuestionModel> QuestionModel { get; set; }
   
        [JsonProperty("$operation")]
        public string Operation { get; set; }
    }
}
