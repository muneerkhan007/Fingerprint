﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace iLinkWW_Mobile.Models
{
   public class OrgnizationSupportDetailModel
    {
        [PrimaryKey,AutoIncrement]
        public int Id { get; set; }
        public int OrganizationId { get; set; }
        public int SupportType { get; set; }
        public string ContactNumber { get; set; }
        public string Email { get; set; }
    }

   public class OrganizationSupportTypeModel
    {
        [PrimaryKey,AutoIncrement]
        public int Id { get; set; }
        public string SupportType { get; set; }
    }
}
