﻿using Newtonsoft.Json;
using SQLite;
using SQLiteNetExtensions.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace iLinkWW_Mobile.Models
{
    public class Sector_Question_OptionModel
    {
        [PrimaryKey]
        public int SectorOptionId { get; set; }
        public string OptionText { get; set; }
        [JsonProperty("QuestionId")]
        [ForeignKey(typeof(QuestionModel))]
        public int Questionid { get; set; }
        public int SectorId { get; set; }

        [JsonProperty("$operation")]
        public string Operation { get; set; }
    }
}
