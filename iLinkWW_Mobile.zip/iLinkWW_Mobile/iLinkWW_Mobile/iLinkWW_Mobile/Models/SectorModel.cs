﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace iLinkWW_Mobile.Models
{
    public class SectorModel
    {

        [PrimaryKey, AutoIncrement, NotNull]
        public int PrimaryKey { get; set; }
        public int SectorId { get; set; }
        public string SectorName { get; set; }
    }
}
