﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace iLinkWW_Mobile.Models
{
    public class Stress_EventModel
    {
        [PrimaryKey]
        public int Stress_EventId { get; set; }
        public int Event_Type_Id { get; set; }
        public string EventType { get; set; }
        public string StressValue { get; set; }
    }
}
