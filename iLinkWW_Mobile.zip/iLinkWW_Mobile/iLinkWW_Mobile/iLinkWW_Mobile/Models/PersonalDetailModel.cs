﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace iLinkWW_Mobile.Models
{
    
    public class PersonalDetailModel
    {
        [PrimaryKey,AutoIncrement,NotNull]
        public int PrimaryKey { get; set; }

        public string Api_Token{ get; set; }
        public int UUID { get; set; }

        public String UserID { get; set; }
        public string Password { get; set; }
        public string Name { get; set; }
        public string OrgnizationCode { get; set; }
        public int MaxEvent { get; set; }
    }
}
