﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iLinkWW_Mobile.Models
{
    public class RequestLoginModel
    {
        public string Password { get; set; }
        public string UserName { get; set; }

        public string DeviceId { get; set; }
    }
}
