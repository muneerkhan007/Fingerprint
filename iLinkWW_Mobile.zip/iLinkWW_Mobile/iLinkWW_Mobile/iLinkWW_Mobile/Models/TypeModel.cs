﻿using Newtonsoft.Json;
using SQLite;
using SQLiteNetExtensions.Attributes;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace iLinkWW_Mobile.Models
{
    public class TypeModel
    {
        [JsonProperty("QuestionTypeId")]
        [PrimaryKey,AutoIncrement]
        public int TypeId { get; set; }
        [JsonProperty("QuestionTypeName")]
        public string TypeName { get; set; }
        public bool IsMultipleChoice { get; set; }
        [OneToMany(CascadeOperations = CascadeOperation.All)]      // One to many relationship with Valuation
        public ObservableCollection<QuestionModel> QuestionModel_Lists { get; set; }
        
        [JsonProperty("$operation")]
        public string Operation { get; set; }
    }
}
