﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using SQLite;
using SQLiteNetExtensions.Attributes;

namespace iLinkWW_Mobile.Models
{
    public class QuestionModel
    {
        [PrimaryKey,AutoIncrement]
        public int QuestionId { get; set; }
        [JsonProperty("QuestionText")]
        public string Text { get; set; }
        [ForeignKey(typeof(QuestionCategoryModel))]
        public int QuestionCategoryId { get; set; }

        [Ignore]
        public bool IsMandatory { get; set; }

        [ForeignKey(typeof(TypeModel))]
        public int QuestionTypeId { get; set; }

        [ManyToOne]
        public QuestionCategoryModel CategoryModel { get; set; }

        [ManyToOne]
        public TypeModel TypeModal { get; set; }

        [OneToMany(CascadeOperations = CascadeOperation.All)]      // One to many relationship with Valuation
        public List<Sector_Question_OptionModel> sector_Question_Options { get; set; }

        /// <summary>
        /// This property is used for only event type option binding
        /// </summary>
        [OneToMany(CascadeOperations = CascadeOperation.All)]      // One to many relationship with Valuation
        public List<EventTypeModel> eventTypeModels { get; set; }

        [JsonProperty("$operation")]
        public string Operation { get; set; }

    }
}
 