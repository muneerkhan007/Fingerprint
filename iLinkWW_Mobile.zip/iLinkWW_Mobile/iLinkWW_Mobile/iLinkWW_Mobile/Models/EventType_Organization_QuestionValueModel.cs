﻿     using System;
using System.Collections.Generic;
using System.Text;

namespace iLinkWW_Mobile.Models
{
    public class EventType_Organization_QuestionValueModel
    {
        public int QuestionValueId { get; set; }
        public int EventTypeId { get; set; }
        public int OrganizationId { get; set; }
        public string Value { get; set; }
    }
}
