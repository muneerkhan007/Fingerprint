﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iLinkWW_Mobile.Models
{
    public class Organization
    {
        public string Code { get; set; }
    }
    class RequestRegisterModel
    {
        public string Password { get; set; }
        public string UserName { get; set; }
        public Organization Organization { get; set; }
        public string DeviceId { get; set; }


    }
}
