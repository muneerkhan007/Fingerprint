﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iLinkWW_Mobile.Models
{

    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class ConfidenceScores
    {
        public double positive { get; set; }
        public double neutral { get; set; }
        public double negative { get; set; }
    }

    public class ConfidenceScores2
    {
        public double positive { get; set; }
        public double neutral { get; set; }
        public double negative { get; set; }
    }

    public class Sentence
    {
        public string sentiment { get; set; }
        public ConfidenceScores2 confidenceScores { get; set; }
        public int offset { get; set; }
        public int length { get; set; }
        public string text { get; set; }
    }

    public class SentimentDocument
    {
        public string id { get; set; }
        public string sentiment { get; set; }
        public ConfidenceScores confidenceScores { get; set; }
        public List<Sentence> sentences { get; set; }
        public List<object> warnings { get; set; }
    }

    public class ResponseAzureSentimentModel
    {
        public List<SentimentDocument> documents { get; set; }
        public List<object> errors { get; set; }
        public string modelVersion { get; set; }
    }

}
