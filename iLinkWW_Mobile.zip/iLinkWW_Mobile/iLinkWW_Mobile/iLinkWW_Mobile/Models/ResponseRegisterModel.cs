﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iLinkWW_Mobile.Models
{
    class ResponseRegisterModel
    {
        public int id { get; set; }
        public string errorDescription { get; set; }
        public string token { get; set; }

        public int ratingDifference { get; set; }

    }
}
