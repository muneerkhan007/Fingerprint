﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iLinkWW_Mobile.Models
{
    class ResponseLoginModel
    {
        public string type { get; set; }
        public string organizationCode { get; set; }
        public string title { get; set; }
        public int status { get; set; }
        public string traceId { get; set; }
        public int id { get; set; }
        public string token { get; set; }
        public int ratingDifference { get; set; }

        public bool isDeviceIdChanged { get; set; }
    }
}
    