﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iLinkWW_Mobile.Models
{
    public class ResponseSubmitEventModel
    {
        public string type { get; set; }
        public string title { get; set; }
        public int status { get; set; }
        public string traceId { get; set; }
        public int eventId { get; set; }
    }
}
