﻿using System;
using System.Collections.Generic;
using System.Text;
    
namespace iLinkWW_Mobile.Models
{
    public class Question_SectorModel
    {
        public int QuestionSectorId { get; set; }
        public int SectorId { get; set; }
        public int QuestionId { get; set; }

    }
}
