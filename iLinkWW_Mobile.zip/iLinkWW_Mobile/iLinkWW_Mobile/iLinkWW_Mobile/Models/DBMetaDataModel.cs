﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace iLinkWW_Mobile.Models
{
    public  class DBMetaDataModel
    {
        [PrimaryKey]
        public int PrimaryKey { get; set; }
        public string Type { get; set; }
        public int Version { get; set; }
        public int ReasonCode { get; set; }
    }
}
