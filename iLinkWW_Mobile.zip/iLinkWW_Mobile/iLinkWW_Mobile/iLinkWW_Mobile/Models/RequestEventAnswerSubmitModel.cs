﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace iLinkWW_Mobile.Models
{
    public class QuestionAnswerModel
    {
        public int ID { get; set; }
        public int QuestionId { get; set; }
        public string QuestionText { get; set; }
        public int OptionId { get; set; }
        public string OptionText { get; set; }
        public int Value { get; set; }

        public SentimentalEnum SentimentalValue { get; set; }
    }

    public class RequestEventAnswerSubmitModel
    {
        public int ID { get; set; }
        public string EventDate { get; set; }
        public List<QuestionAnswerModel> QuestionAnswerModels { get; set; }
    }
}
