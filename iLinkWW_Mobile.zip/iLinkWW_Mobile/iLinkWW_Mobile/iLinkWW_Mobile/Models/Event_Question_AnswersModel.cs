﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace iLinkWW_Mobile.Models
{
    public class Event_Question_AnswersModel
    {
        [PrimaryKey,AutoIncrement]
        public int AnswerId { get; set; }
        public int EventId { get; set; }
        public int QuestionId { get; set; }
        public string QuestionText { get; set; }
        public int OptionId { get; set; }
        public string AnswerText { get; set; }
        public int value { get; set; }

        public SentimentalEnum SentimentalValue { get; set; }

        /// <summary>
        /// This property is used for syncing 
        /// IsSynced - true : specific data is synced
        /// IsSynced - false : specifc data is ready to sync
        /// </summary>
        public bool IsSynced { get; set; }
    }

    public enum SentimentalEnum:int
    {
        Unknown,
        positive,
        neutral,
        negative,
    }
}
