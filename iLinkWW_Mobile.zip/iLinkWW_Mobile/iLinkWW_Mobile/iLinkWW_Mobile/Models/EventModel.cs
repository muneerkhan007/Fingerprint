﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace iLinkWW_Mobile.Models
{
    public class EventModel
    {
        [PrimaryKey,AutoIncrement]
        public int EventId { get; set; }
        public int UserId { get; set; }
        public int? EventTypeId { get; set; }
        public string EventDate { get; set; }
        /// <summary>
        /// This property is used for syncing 
        /// IsSynced - true : specific data is synced
        /// IsSynced - false : specifc data is ready to sync
        /// </summary>
        public bool IsSync { get; set; }        
    }
}
