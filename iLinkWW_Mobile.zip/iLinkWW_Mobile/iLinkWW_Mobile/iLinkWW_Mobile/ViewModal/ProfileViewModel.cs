﻿using iLinkWW_Mobile.Database;
using iLinkWW_Mobile.Models;
using iLinkWW_Mobile.Utils;
using Microsoft.AppCenter.Crashes;
using Mono.Cecil.Cil;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace iLinkWW_Mobile.ViewModal
{
    public class ProfileViewModel : BaseViewModel
    {
        private ObservableCollection<ChartData> neutralData = new ObservableCollection<ChartData>();
        private ObservableCollection<ChartData> positiveData = new ObservableCollection<ChartData>();
        private ObservableCollection<ChartData> nagativeData = new ObservableCollection<ChartData>();
        private ObservableCollection<ChartData> personalData = new ObservableCollection<ChartData>();
        private ObservableCollection<ChartData> actualData = new ObservableCollection<ChartData>();

        public ObservableCollection<ChartData> NagativeData { get => nagativeData; set { nagativeData = value; OnPropertyChanged(); } }
        public ObservableCollection<ChartData> NeutralData { get => neutralData; set { neutralData = value; OnPropertyChanged(); } }
        public ObservableCollection<ChartData> PositiveData { get => positiveData; set { positiveData = value; OnPropertyChanged(); } }
        public ObservableCollection<ChartData> PersonalData { get => personalData; set => personalData = value; }
        public ObservableCollection<ChartData> ActualData { get => actualData; set => actualData = value; }

        public ProfileViewModel()
        {
          //  UpdateGraphs();
            HomeViewModel.Instance.ProfileIndexChanged = new Command(TabSelectMethod);
        }
        int previoustab;
       

        private void TabSelectMethod(object obj)
        {

            if (HomeViewModel.Instance.TabSelectIndex == 1 && previoustab != 1)
            {
                UpdateGraphs();
            }
            previoustab = HomeViewModel.Instance.TabSelectIndex;
        }

        private async void UpdateGraphs()
        {
            try
            {
                HomeViewModel.Instance.IsLoading = true;
                var Event_Data = await AppDatabase.GetItemsAsync<EventModel>();
                List<PersonalDetailModel> data = await AppDatabase.GetItemsAsync<PersonalDetailModel>();
                if (data.Count != 0)
                {
                    Event_Data = Event_Data?.Where(event_data => event_data.IsSync)?.ToList();
                }
                Event_Data?.Reverse();
                int i = 0;
                int j = 0;
                int Positive_10Events = 0;
                int Negative_10Events = 0;
                int Neutral_10Events = 0;
                int Positive_20Events = 0;
                int Negative_20Events = 0;
                int Neutral_20Events = 0;
                int Positive_40Events = 0;
                int Negative_40Events = 0;
                int Neutral_40Events = 0;  

                for(int k=0;k<Event_Data.Count;k++)
                 {   
                        var AnswerList = await AppDatabase.QueryAsync<Event_Question_AnswersModel>($"select * from {typeof(Event_Question_AnswersModel).Name} where {nameof(Event_Question_AnswersModel.EventId)}==?", Event_Data[k]?.EventId.ToString());
                        if (AnswerList == null)
                            break;
                        Event_Question_AnswersModel _AnswersModel = AnswerList?.Find(AnswerList => AnswerList.QuestionText == AppConstants.FreeTextQuestion);
                        Console.WriteLine(_AnswersModel?.SentimentalValue + ":  " + i.ToString() + "/    ");
                    if (_AnswersModel == null)
                    {
                        HomeViewModel.Instance.IsLoading = false;
                        return;
                    }
                        switch (_AnswersModel.SentimentalValue)
                        {
                            case SentimentalEnum.positive:
                                if (i < 10)
                                    Positive_10Events++;
                                if (i < 20)
                                    Positive_20Events++;
                                if (i < 40)
                                    Positive_40Events++;
                                break;
                            case SentimentalEnum.neutral:
                                if (i < 10)
                                    Neutral_10Events++;
                                if (i < 20)
                                    Neutral_20Events++;
                                if (i < 40)
                                    Neutral_40Events++;
                                break;
                            case SentimentalEnum.negative:
                                if (i < 10)
                                    Negative_10Events++;
                                if (i < 20)
                                    Negative_20Events++;
                                if (i < 40)
                                    Negative_40Events++;
                                break;
                            default:
                                break;
                        }
                        i++;
                    }
                NagativeData.Clear();

                if(Event_Data.Count>20)
                NagativeData.Add(new ChartData("Last 40 Events", Negative_40Events));
                if (Event_Data.Count > 10)
                    NagativeData.Add(new ChartData("Last 20 Events", Negative_20Events));
                NagativeData.Add(new ChartData("Last 10 Events", Negative_10Events));

                NeutralData.Clear();
                if (Event_Data.Count > 20)
                    NeutralData.Add(new ChartData("Last 40 Events", Neutral_40Events));
                if (Event_Data.Count > 10)
                    NeutralData.Add(new ChartData("Last 20 Events", Neutral_20Events));
                NeutralData.Add(new ChartData("Last 10 Events", Neutral_10Events));

                PositiveData.Clear();
                if (Event_Data.Count > 20)
                    PositiveData.Add(new ChartData("Last 40 Events", Positive_40Events));
                if (Event_Data.Count > 10)
                    PositiveData.Add(new ChartData("Last 20 Events", Positive_20Events));
                PositiveData.Add(new ChartData("Last 10 Events", Positive_10Events));

                var Event_Org_ValueList = await AppDatabase.GetItemsAsync<EventType_Organization_QuestionValueModel>();
                var Personal_ValueList = await AppDatabase.GetItemsAsync<Event_Question_AnswersModel>();
                PersonalData.Clear();
                ActualData.Clear();
                Event_Data.ForEach((item) =>
                {
                    Event_Question_AnswersModel event_Question_AnswersModel = Personal_ValueList?.Where(per => per.EventId == item.EventId && per.QuestionText == AppConstants.StressLevelQuestion).FirstOrDefault();
                    Event_Question_AnswersModel event_Question_AnswersModel_EventType = Personal_ValueList?.Where(per => per.EventId == item.EventId && per.QuestionText == AppConstants.EventQuestion).FirstOrDefault();
                    PersonalData?.Add(new ChartData
                    {
                        Name = "e" + (Event_Data?.Count-j )?.ToString(),
                        Number = Convert.ToDouble(event_Question_AnswersModel?.value)
                    });
                    ActualData?.Add(new ChartData
                    {
                        Name = "e" + (Event_Data?.Count - j )?.ToString(),
                        Number=Convert.ToDouble(Event_Org_ValueList.Find(Event_Data=>Event_Data.EventTypeId== event_Question_AnswersModel_EventType?.OptionId)?.Value)
                    });
                    j++;
                });

                HomeViewModel.Instance.IsLoading = false;
            }
            catch (Exception ex)
            {
                HomeViewModel.Instance.IsLoading = false;
                Crashes.TrackError(ex);
              //  await App.NaviationPage.DisplayAlert("", AppConstants.GenralError, AppConstants.OkStr);
            }
        }
    }
    public class ChartData
    {
        public string Name { get; set; }

        public double Number { get; set; }
        public ChartData()
        {

        }

        public ChartData(string name, double Number)
        {
            this.Name = name;
            this.Number = Number;
        }
    }
}
