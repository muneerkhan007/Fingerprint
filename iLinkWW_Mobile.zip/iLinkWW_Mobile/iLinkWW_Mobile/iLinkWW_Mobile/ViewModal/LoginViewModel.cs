﻿using iLinkWW_Mobile.Api;
using iLinkWW_Mobile.Database;
using iLinkWW_Mobile.Models;
using iLinkWW_Mobile.Utils;
using iLinkWW_Mobile.Interface;
using iLinkWW_Mobile.Views;
using Microsoft.AppCenter.Crashes;
using Plugin.DeviceInfo;
using Plugin.Fingerprint;
using Plugin.Fingerprint.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace iLinkWW_Mobile.ViewModal
{
    public class LoginViewModel : BaseViewModel
    {
        private string passwordText;

        private bool isloading;

        private string Flag;
        public bool IsLoading
        {
            get { return isloading; }
            set
            {
                isloading = value;
                OnPropertyChanged();
            }
        }

        public String PasswordText { get => passwordText; set { passwordText = value; OnPropertyChanged(); } }

        public ICommand RegisterCommand { get; set; }
        public ICommand SubmitCommand { get; set; }
        public ICommand FingerPrintCommand { get; set; }

        public ICommand HelpCommand { get; set; }

        private bool showSignup = true;

        public bool ShowSignUp
        {
            get { return showSignup; }
            set { showSignup = value; OnPropertyChanged(); }
        }


        private string usrname;

        public string UserName
        {
            get { return usrname; }
            set
            {
                usrname = value;
                OnPropertyChanged();
            }
        }

        public ICommand OnApeareCommand { get; set; }


        public LoginViewModel(string flag = "")
        {
            Flag = flag;
            // ShowSignUp = flag != AppConstants.Home_Route;
            RegisterCommand = new Command(RegisterTapMethod);
            SubmitCommand = new Command(SubmitMethod);
            HelpCommand = new Command(HelpMethod);
            FingerPrintCommand = new Command(FingerPrintMethod);
            OnApeareCommand = new Command(OnApeareMethod);
            Finger_Print();
        }

        private void OnApeareMethod(object obj)
        {
            Finger_Print();
        }

        private async void HelpMethod(object obj)
        {
            await App.NaviationPage.DisplayAlert("", "1. The user should have a Touch ID-capable device. \n 2. Fingerprint should configured in the phone security settings.", "Ok");
        }

        private  void FingerPrintMethod(object obj)
        {
            Finger_Print();
        }

        private async void Finger_Print()
        {
            if (AppDatabase.TableExists<PersonalDetailModel>(AppDatabase.Database))
            {
                List<PersonalDetailModel> data = await AppDatabase.GetItemsAsync<PersonalDetailModel>();
                ShowSignUp = data.Count == 0;
                if (data.Count != 0)
                {
                    if(await ValidateDevice(data)) return;
                    try
                    {
                        var request = new AuthenticationRequestConfiguration("Prove you have fingers!", "Because without it you can't have access");
                        request.AllowAlternativeAuthentication = true;
                        var cancel = new CancellationToken();
                        var result = await CrossFingerprint.Current.AuthenticateAsync(request, cancel);
                        if (result.Authenticated)
                        {
                            IsLoading = true;
                            App.PersonalDetail = data[0];
                            App.NaviationPage.Navigation.InsertPageBefore(new HomePage(), App.NaviationPage.Navigation.NavigationStack[0]);
                            await App.NaviationPage.Navigation.PopToRootAsync();
                            IsLoading = false;

                        }
                    }
                    catch (Exception ex)
                    {
                        IsLoading = false;
                        Crashes.TrackError(ex);
                    }
                }
            }
        }

        private async Task<bool> ValidateDevice(List<PersonalDetailModel> data)
        {
            try
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    IsLoading = true;
                    ResponseLoginModel response = await ApiService.PutApiAsync<RequestLoginModel, ResponseLoginModel>(AppConstants.LoginUri, new RequestLoginModel
                    {
                        UserName = data[0].UserID,
                        Password = data[0].Password,
                        DeviceId = CrossDeviceInfo.Current.Id
                    });

                    if (response.isDeviceIdChanged)
                    {
                        await AppDatabase.DropTable<PersonalDetailModel>();
                        await AppDatabase.DropTable<DBMetaDataModel>();
                        await AppDatabase.DeleteDataFromAllTables();
                        OnApeareCommand.Execute(null);

                    }
                    IsLoading = false;
                    return response.isDeviceIdChanged;
                }
                else
                {
                    return false;
                }
            }
            catch(Exception ex)
            {
                IsLoading = false;
                Crashes.TrackError(ex);
                return false;
            }

        }

        //private async void  FingerPrintMethod()
        //{
        //    var result = await CrossFingerprint.Current.AuthenticateAsync(new AuthenticationRequestConfiguration("iLinkWW", "Please tab here"));
        //    if (result.Authenticated)
        //    {
        //        await App.Current.MainPage.DisplayAlert("Results are here", "Valid fingerprint found", "Ok");
        //    }
        //    else
        //    {
        //        //await App.Current.MainPage.DisplayAlert("Results are here", "Invalid fingerprint", "Ok");
        //    }
        //}

        private async void SubmitMethod(object obj)
        {
           
                
                    if (string.IsNullOrWhiteSpace(UserName))
                    {
                        await App.NaviationPage.DisplayAlert("", AppConstants.UserNameText, AppConstants.OkStr);
                        return;
                    }
                    if (string.IsNullOrWhiteSpace(PasswordText))
                    {
                        await App.NaviationPage.DisplayAlert("", AppConstants.PasswordText, AppConstants.OkStr);
                        return;
                    }
                    try
                    {
                        IsLoading = true;
                if (!ShowSignUp && AppDatabase.TableExists<PersonalDetailModel>(AppDatabase.Database))
                {
                    List<PersonalDetailModel> localdata = await AppDatabase.GetItemsAsync<PersonalDetailModel>();
                    if (localdata.Count != 0)
                    {
                        if (localdata[0].UserID == UserName && localdata[0].Password == PasswordText)
                        {
                            App.PersonalDetail = localdata[0];
                            App.NaviationPage.Navigation.InsertPageBefore(new HomePage(), App.NaviationPage.Navigation.NavigationStack[0]);
                            await App.NaviationPage.Navigation.PopToRootAsync();
                        }
                        else
                        {
                            await App.NaviationPage.DisplayAlert("", AppConstants.UnAuthrizeText, AppConstants.OkStr);
                        }
                            IsLoading = false;
                            return;
                        }
                    }
                    if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                    {
                        ResponseLoginModel response = await ApiService.PutApiAsync<RequestLoginModel, ResponseLoginModel>(AppConstants.LoginUri, new RequestLoginModel
                        {
                            UserName = UserName,
                            Password = PasswordText,
                            DeviceId = CrossDeviceInfo.Current.Id
                        });

                

                    if (response.isDeviceIdChanged)
                        {
                            await App.NaviationPage.DisplayAlert("",AppConstants.DeviceChangeText, AppConstants.OkStr);
                            
                        }
                        if (response?.status == 401)
                        {
                            IsLoading = false;
                            await App.NaviationPage.DisplayAlert("", AppConstants.UnAuthrizeText, "OK");
                        }
                        else
                        {

                            await AppDatabase.InsertItem<PersonalDetailModel>(new PersonalDetailModel
                            {
                                Api_Token = response.token,
                                UUID = response.id,
                                UserID = UserName,
                                Password = PasswordText,
                                OrgnizationCode = response.organizationCode,
                                MaxEvent = response.ratingDifference
                            });
                            var data = await AppDatabase.GetItemsAsync<PersonalDetailModel>();
                            App.PersonalDetail = data[0];

                            App.NaviationPage.Navigation.InsertPageBefore(new HomePage(), App.NaviationPage.Navigation.NavigationStack[0]);
                            await App.NaviationPage.Navigation.PopToRootAsync();
                            IsLoading = false;
                        }
                    }
                    else
                    {
                    IsLoading = false;
                    await App.NaviationPage.DisplayAlert("", AppConstants.InternetConnectionText, AppConstants.OkStr);
                    }
                }
                    catch (Exception ex)
                    {
                        IsLoading = false;
                await App.NaviationPage.DisplayAlert("", AppConstants.UnAuthrizeText, "OK");

                //   DependencyService.Get<IToastMsg>().ShortAlert(AppConstants.GenralError);
                Crashes.TrackError(ex);
                    }
               }

        private async void RegisterTapMethod(object obj)
        {
            await App.NaviationPage.PushAsync(new RegistrationPage());
        }
    }
}
