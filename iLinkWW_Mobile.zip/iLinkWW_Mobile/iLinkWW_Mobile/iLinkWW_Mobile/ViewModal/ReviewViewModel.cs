﻿using System;
using System.Collections.Generic;
using System.Linq;
using iLinkWW_Mobile.Utils;
using iLinkWW_Mobile.Database;
using iLinkWW_Mobile.Models;
using Microsoft.AppCenter.Crashes;
using Xamarin.Forms;
using Microsoft.AppCenter.Analytics;

namespace iLinkWW_Mobile.ViewModal
{
    public class TypeModels
    {
        public int? typeId { get; set; }
        public int value { get; set; }
    }

    public class ReviewViewModel: BaseViewModel
    {
        private bool _showMessage1 = false;
        private bool _showMessage2 = false;
        private bool _showMessage3 = false;
        private string _message1 = "";
        private string _message2 = "";
        private string _message3 = "";
        private string _msgGathered = "";
        private bool _isNoData = false;

        public bool IsNodata
        {
            get { return _isNoData; }
            set { _isNoData = value; OnPropertyChanged(); }
        }

        public bool ShowMessage1
        {
            get { return _showMessage1; }
            set { _showMessage1 = value; OnPropertyChanged(); }
        }
        public bool ShowMessage2
        {
            get { return _showMessage2; }
            set { _showMessage2 = value; OnPropertyChanged();}
        }
        public bool ShowMessage3
        {
            get { return _showMessage3; }
            set { _showMessage3 = value; OnPropertyChanged(); }
        }

        public string Message1
        {
            get { return _message1; }
            set { _message1 = value; OnPropertyChanged(); }
        }
        public string Message2
        {
            get { return _message2; }
            set { _message2 = value; OnPropertyChanged(); }
        }
        public string Message3
        {
            get { return _message3; }
            set { _message3 = value; OnPropertyChanged(); }
        }
        public string MsgGathered
        {
            get { return _msgGathered; }
            set { _msgGathered = value; OnPropertyChanged(); }
        }

        public ReviewViewModel()
        {
            UpdateReviewData();
            HomeViewModel.Instance.ReviewIndexChanged = new Command(TabSelectMethod);
        }
        int previoustab;

        private void TabSelectMethod(object obj)
        {

            if (HomeViewModel.Instance.TabSelectIndex == 2 && previoustab != 2)
            {
                UpdateReviewData();
            }
            previoustab = HomeViewModel.Instance.TabSelectIndex;
        }

        public async void UpdateReviewData()
        {            
            int MaxEvent = 7;

            //if (App.PersonalDetail.MinEvent >= 0)
            //{
            //    MinEvent = App.PersonalDetail.MinEvent;
            //}

            if (App.PersonalDetail.MaxEvent > 0)
            {
                MaxEvent = App.PersonalDetail.MaxEvent;
            }

            Message1 = "Your mood tracker indicates you should reach out to a Counsellor";
            Message2 = "You should consider additional training to help cope with the recent events you experienced";
            Message3 = "You need to record at least "+ MaxEvent.ToString()+" events before you see any recommendations";
            MsgGathered = "(Gathered from the last "+ MaxEvent.ToString()+" events)";
            ShowMessage1 = false;
            ShowMessage2 = false;
            ShowMessage3 = true;
            try
            {
                HomeViewModel.Instance.IsLoading = true;
                var Event_Data = await AppDatabase.GetItemsAsync<EventModel>();
                List<PersonalDetailModel> data = await AppDatabase.GetItemsAsync<PersonalDetailModel>();
                if (data.Count != 0)
                {
                    Event_Data = Event_Data?.Where(event_data => event_data.UserId == App.PersonalDetail?.UUID)?.ToList();
                }
                Event_Data?.Reverse();

                int i = 0;
                int j = 0;
                int negativeIn1st = 0;
                int negativeIn2nd = 0;
                int personalValue = 0;               
                int rating_diff_perc = 30;
                int native_impact_perc = 20;
                List<TypeModels> typesvalues = new List<TypeModels>();

                //int _count = 0;

                //for (int index = 0; index < Event_Data.Count; index++)
                //{                    
                //    if (Convert.ToDateTime(Event_Data[index].EventDate).Date >= DateTime.UtcNow.AddDays(-7).Date)                    
                //        _count++;
                        
                    
                //}

                if (Event_Data.Count >= MaxEvent)
                {
                    ShowMessage3 = false;
                    for (int k = 0; k < MaxEvent - 1; k++)
                    {
                        var AnswerList = await AppDatabase.QueryAsync<Event_Question_AnswersModel>
                            ($"select * from {typeof(Event_Question_AnswersModel).Name} " +
                            $"where {nameof(Event_Question_AnswersModel.EventId)}==?", Event_Data[k]?.EventId.ToString());
                        if (AnswerList == null)
                            return;

                        Analytics.TrackEvent("Answers count - event: " + Event_Data[k]?.EventId.ToString() + " count: " + AnswerList.Count.ToString());
                        int avgVal = 0;
                        foreach (Event_Question_AnswersModel answer in AnswerList)
                        {
                            if (answer.QuestionId == 5)
                                avgVal = answer.value;

                            if ((answer.QuestionId == 8) && (answer.SentimentalValue == SentimentalEnum.negative))
                                negativeIn1st++;
                        }
                        typesvalues.Add(new TypeModels { typeId = Event_Data[k]?.EventTypeId, value = avgVal });
                        i++;
                    }
                }

                int MaxEvent2 = MaxEvent * 2;
                if (Event_Data.Count >= MaxEvent2)
                {
                    for (int k = MaxEvent; k < MaxEvent2-1; k++)
                    {
                        var AnswerList = await AppDatabase.QueryAsync<Event_Question_AnswersModel>
                            ($"select * from {typeof(Event_Question_AnswersModel).Name} " +
                            $"where {nameof(Event_Question_AnswersModel.EventId)}==?", Event_Data[k]?.EventId.ToString());
                        if (AnswerList == null)
                            return;


                        foreach (Event_Question_AnswersModel answer in AnswerList)
                        {
                            if ((answer.QuestionId == 8) && (answer.SentimentalValue == SentimentalEnum.negative))
                                negativeIn2nd++;
                        }

                        i++;
                    }

                    if (negativeIn1st > 0 && negativeIn2nd > 0)
                    {
                        double Increase = 0;
                        double val1 = (negativeIn1st - negativeIn2nd);

                        if (val1 > 0) { 
                            double val2 = val1 / negativeIn2nd;
                            Increase = val2 * 100;
                        }
                        if (Increase > native_impact_perc)
                        {
                            ShowMessage1 = true;
                        }
                    }

                    if(negativeIn1st > 0 && negativeIn2nd == 0)
                    {
                        ShowMessage1 = true;
                    }
                }


                var Event_Org_ValueList = await AppDatabase.GetItemsAsync<EventType_Organization_QuestionValueModel>();

                int personal_avg = typesvalues.Sum(x => Convert.ToInt32(x.value))/typesvalues.Count;

                if (personal_avg > 0)
                {
                    List<TypeModels> actual_typs = new List<TypeModels>();
                   
                    foreach (var val in typesvalues)
                    {
                        var eventtype = Event_Org_ValueList.Find(X => X.EventTypeId == val.typeId);
                        if (eventtype != null && !actual_typs.Exists(y=> y.typeId == eventtype.EventTypeId))
                        {
                            actual_typs.Add(new TypeModels { typeId = eventtype.EventTypeId, value = Convert.ToInt32(eventtype.Value) });                                                        
                        }                        
                    }

                    double perc = 0;
                    int actual_sum = actual_typs.Sum(x => Convert.ToInt32(x.value));

                    if (actual_typs.Count > 0 && actual_sum > 0)
                    {
                        int actual_avg = actual_sum / actual_typs.Count;
                        double val1 = (personal_avg - actual_avg);

                        if (val1 > 0 && actual_avg > 0)
                        {
                            double val2 = val1 / actual_avg;
                            perc = val2 * 100;
                        }
                    }
                    if (perc > rating_diff_perc)
                        ShowMessage2 = true;
                }

                //var Personal_ValueList = await AppDatabase.GetItemsAsync<Event_Question_AnswersModel>();

                IsNodata = (!ShowMessage1 && !ShowMessage2 && !ShowMessage3);
                HomeViewModel.Instance.IsLoading = false;
            }
            catch (Exception ex)
            {
                IsNodata = (!ShowMessage1 && !ShowMessage2 && !ShowMessage3);
                HomeViewModel.Instance.IsLoading = false;
                Crashes.TrackError(ex);
                //  await App.NaviationPage.DisplayAlert("", AppConstants.GenralError, AppConstants.OkStr);
            }
        }

    }
}