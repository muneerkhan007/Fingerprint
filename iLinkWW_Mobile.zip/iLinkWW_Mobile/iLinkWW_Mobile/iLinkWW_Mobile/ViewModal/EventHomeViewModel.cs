﻿using iLinkWW_Mobile.Database;
using iLinkWW_Mobile.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace iLinkWW_Mobile.ViewModal
{
    public class EventHomeViewModel:BaseViewModel
    {
        public ICommand PlusButtonCommand { get; set; }
        private string usernametext;


        public string UserNameText
        {
            get { return usernametext; }
            set
            {
                usernametext = value;
                OnPropertyChanged();
            }
        }
        private async void GetUserName()
        {
            var personalDetail = await AppDatabase.GetItemAsync<PersonalDetailModel>(nameof(PersonalDetailModel.PrimaryKey), 1);
            UserNameText = personalDetail?.UserID ?? "";


        }
        public EventHomeViewModel()
        {
            GetUserName();
            PlusButtonCommand = new Command(PlusButtonMethod);
    }
        private void PlusButtonMethod(object obj)
        {
           HomeViewModel.Instance.TabSelectIndex = 4;
            HomeViewModel.Instance?.InitEventCommand.Execute(null);
        }
    }
}
