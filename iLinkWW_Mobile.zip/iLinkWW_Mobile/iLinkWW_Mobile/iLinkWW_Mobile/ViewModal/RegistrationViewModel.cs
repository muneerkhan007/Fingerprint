﻿using iLinkWW_Mobile.Api;
using iLinkWW_Mobile.Database;
using iLinkWW_Mobile.Models;
using iLinkWW_Mobile.Utils;
using iLinkWW_Mobile.Views;
using Microsoft.AppCenter.Crashes;
using Plugin.DeviceInfo;
using System;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace iLinkWW_Mobile.ViewModal
{
    public class RegistrationViewModel : BaseViewModel
    {
        public ICommand AcceptBtnCommand { get; set; }

        public ICommand DeclineBtnCommand { get; set; }

        private bool isdiscshow;

        public bool IsDiscShow
        {
            get { return isdiscshow; }
            set
            {
                isdiscshow = value;
                OnPropertyChanged();
            }
        }



        private String orgnizationCode;

        private String userid;

        private bool isloading;

        public bool IsLoading
        {
            get { return isloading; }
            set
            {
                isloading = value;
                OnPropertyChanged();
            }
        }


        public String UserID
        {
            get { return userid; }
            set
            {
                userid = value;
                OnPropertyChanged();
            }
        }


        public String OrgnizationCode
        {
            get { return orgnizationCode; }
            set
            {
                orgnizationCode = value;
                OnPropertyChanged();
            }
        }

        private string password;

        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        private string re_password;

        public string Re_password
        {
            get { return re_password; }
            set { re_password = value; }
        }

        private bool isuseridloading;

        public bool IsUserIdLoading
        {
            get { return isuseridloading; }
            set
            {
                isuseridloading = value;
                if (value == true)
                {
                    IsUserIDValid = false;
                    IsUserNotValid = false;
                }
                OnPropertyChanged();
            }
        }

        private bool isuseridvalid;

        public bool IsUserIDValid
        {
            get { return isuseridvalid; }
            set
            {
                isuseridvalid = value;
                OnPropertyChanged();
            }
        }

        private bool isusernotvalid;

        public bool IsUserNotValid
        {
            get { return isusernotvalid; }
            set
            {
                isusernotvalid = value;
                OnPropertyChanged();
            }
        }



        public ICommand BackCommand { get; set; }

        public ICommand RegisterButtonCommand { get; set; }

        public ICommand UnFocesedUserIDCommand { get; set; }

        public RegistrationViewModel()
        {
            UnFocesedUserIDCommand = new Command(UnFocesedUserIDMethod);
            BackCommand = new Command(BackClickMethod);
            RegisterButtonCommand = new Command(RegistrationButtonMethod);
            AcceptBtnCommand = new Command(AcceptBtnMethod);
            DeclineBtnCommand = new Command(DeclineBtnMethod);
        }

        private void DeclineBtnMethod(object obj)
        {
            IsDiscShow = false;
        }

        private async void AcceptBtnMethod(object obj)
        {
            IsDiscShow = false;
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                UserRegisterApiMethod();
            else
                await App.NaviationPage.DisplayAlert("", AppConstants.InternetConnectionText, AppConstants.OkStr);
        }

        private async void UnFocesedUserIDMethod(object obj)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(UserID))
                    return;
                IsUserIdLoading = true;
                ResponseVerifyUserIdModel responseVerify = await ApiService.GetApiAsync<ResponseVerifyUserIdModel>(String.Format(AppConstants.VerifyUserIDUri, UserID));
                IsUserIdLoading = false;
                if (responseVerify?.status == 404 && responseVerify != null)
                {
                    IsUserIDValid = true;
                    IsUserNotValid = false;
                    // await App.Current.MainPage.DisplayAlert("", "valid string", "OK");
                }
                else
                {
                    IsUserNotValid = true;
                    IsUserIDValid = false;
                }
                //await App.Current.MainPage.DisplayAlert("", "not valid", "OK");
            }
            catch (Exception ex)
            {
                IsUserIdLoading = false;
                Crashes.TrackError(ex);
                //   await App.NaviationPage.DisplayAlert("", AppConstants.GenralError, AppConstants.OkStr);
            }
        }

        private async void RegistrationButtonMethod(object obj)
        {
            try
            {
                if (Connectivity.NetworkAccess != NetworkAccess.Internet)
                {
                    await App.NaviationPage.DisplayAlert("", AppConstants.InternetConnectionText, AppConstants.OkStr);
                    return;
                }
                if (string.IsNullOrWhiteSpace(Password)
                    || string.IsNullOrWhiteSpace(Re_password)
                    || string.IsNullOrWhiteSpace(OrgnizationCode)
                    || string.IsNullOrWhiteSpace(UserID))
                {
                    await App.NaviationPage.DisplayAlert("", AppConstants.AllfieldMendatoryText, AppConstants.OkStr);
                    return;
                }

                if (!IsUserIDValid)
                {
                    await App.NaviationPage.DisplayAlert("", AppConstants.UserIdNotVerifyText, AppConstants.OkStr);
                    return;
                }

                if (Password.Length < AppConstants.MinimumPasswordValidation)
                {
                    await App.NaviationPage.DisplayAlert("", AppConstants.PasswordValidationText, AppConstants.OkStr);
                    return;
                }

                if (Password != Re_password)
                {
                    await App.NaviationPage.DisplayAlert("", AppConstants.PasswordSameText, AppConstants.OkStr);
                    return;
                }
                IsDiscShow = true;

                //    PersonalDetailModal personal = await AppDatabase.GetItemAsync<PersonalDetailModal>("Name", Name);
                //       await App.Current.MainPage.DisplayAlert("", personal?.Name, "Ok");
            }
            catch (Exception)
            {
                IsLoading = false;
                //   await App.NaviationPage.DisplayAlert("", AppConstants.GenralError, AppConstants.OkStr);
            }
        }

        private async void UserRegisterApiMethod()
        {
            IsLoading = true;
            ResponseRegisterModel data = await ApiService.PostApiAsyc<RequestRegisterModel, ResponseRegisterModel>(AppConstants.RegisterUri, new RequestRegisterModel
            {
                UserName = UserID,
                Organization = new Organization
                {
                    Code = OrgnizationCode
                },
                Password = Password,
                DeviceId=CrossDeviceInfo.Current.Id
            });
            IsLoading = false;
            if (data == null)
            {
                //  await App.NaviationPage.DisplayAlert("", AppConstants.GenralError, AppConstants.OkStr);
                return;
            }
            if (!string.IsNullOrWhiteSpace(data.errorDescription))
            {
                await App.NaviationPage.DisplayAlert("", data.errorDescription, AppConstants.OkStr);
                return;
            }
            if (data.id == 0)
            {
                await App.NaviationPage.DisplayAlert("", data.errorDescription, AppConstants.OkStr);
                return;
            }

            await AppDatabase.InsertItem<PersonalDetailModel>(new PersonalDetailModel
            {
                OrgnizationCode = this.OrgnizationCode,
                Password = Password,
                UUID = data.id,
                UserID = UserID,
                Api_Token = data.token,
                MaxEvent = data.ratingDifference
            });
            var database = await AppDatabase.GetItemsAsync<PersonalDetailModel>();
            App.PersonalDetail = database[0];
            await App.NaviationPage.DisplayAlert("", AppConstants.RegisetSuccessText, AppConstants.OkStr);
            App.NaviationPage.Navigation.InsertPageBefore(new HomePage("Route_Reg"), App.NaviationPage.Navigation.NavigationStack[0]);
            await App.NaviationPage.Navigation.PopToRootAsync();
        }

        private async void BackClickMethod(object obj)
        {

            await App.NaviationPage.PopAsync();
        }
    }
}
