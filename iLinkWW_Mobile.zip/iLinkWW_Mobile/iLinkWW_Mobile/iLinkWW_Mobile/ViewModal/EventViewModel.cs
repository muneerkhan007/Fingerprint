﻿using iLinkWW_Mobile.Api;
using iLinkWW_Mobile.Database;
using iLinkWW_Mobile.Interface;
using iLinkWW_Mobile.Models;
using iLinkWW_Mobile.Utils;
using iLinkWW_Mobile.Views;
using Microsoft.AppCenter.Crashes;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Internals;

namespace iLinkWW_Mobile.ViewModal
{
    public class EventViewModel : BaseViewModel
    {
        public int Position { get => position; set { position = value;OnPropertyChanged(); } }
        public bool IsLoading { get => isLoading; set { isLoading = value; OnPropertyChanged(); } }

        private ObservableCollection<Category> eventModel;

        public ObservableCollection<EventData> EventListData
        {
            get => eventListData; set
            {
                eventListData = value;
                OnPropertyChanged();
            }
        }

        private bool isLoading;
        private ObservableCollection<EventData> eventListData = new ObservableCollection<EventData>();

        public ObservableCollection<Category> EventModel
        {
            get { return eventModel; }
            set
            {
                eventModel = value;
                OnPropertyChanged();
            }
        }

        private Category selectedcategory;
        private int position;

        public Category SelectedCategory
        {
            get { return selectedcategory; }
            set
            {
                selectedcategory = value;
                OnPropertyChanged();
            }
        }


        public ICommand AddEvent { get; set; }

        public ICommand NextSubmitCmd { get; set; }
        public EventViewModel()
        {
            AddEvent = new Command(AddEventMethod);
            HomeViewModel.Instance.InitEventCommand = new Command(() =>
            {
                CallApiMethod();
            });
            SubmitEventCommand = new Command(SubmitEventMethod);
            NextSubmitCmd = new Command(NextSubmitMethod);
        }

        private void NextSubmitMethod(object obj)
        {
            var qcount = SelectedCategory.questions.Count;
            
            if(Position==qcount-1)
            {
                if (SelectedCategory == EventModel[EventModel.Count - 1])
                {
                    SubmitEventCommand?.Execute(null);
                    return;
                }
                SelectedCategory = EventModel[EventModel.IndexOf(SelectedCategory)+1];
                
                Position = 0;
                return;
            }
                Position++;
            
        }

        private async void SubmitEventMethod(object obj)
        {
            try
            {
                List<QuestionAnswerModel> questionAnswerModels = new List<QuestionAnswerModel>();
                EventModel.ForEach((itm) =>
                {
                    itm.questions.ForEach((ans) =>
                    {
                        questionAnswerModels.Add(new QuestionAnswerModel
                        {
                            OptionId = ans.OptionId,
                            OptionText = ans.OptionText,
                            QuestionId = ans.questionId,
                            QuestionText = ans.text,
                        });
                    });
                });


                if (questionAnswerModels.Find(data => data.QuestionText == AppConstants.EventQuestion).OptionId == 0)
                {
                    Category category = EventModel.Where(itm => itm.questions.Any(a => a.text == AppConstants.EventQuestion))?.FirstOrDefault();
                    SelectedCategory = category;
                    Position = category.questions.IndexOf(category.questions.Find(question => question.text == AppConstants.EventQuestion));
                    DependencyService.Get<IToastMsg>().ShortAlert(AppConstants.EventTypeValidationMsg);
                    return;
                }

                if (string.IsNullOrWhiteSpace(questionAnswerModels.Find(data => data.QuestionText == AppConstants.ExperienceQuestion).OptionText))
                {

                    Category category = EventModel.Where(itm => itm.questions.Any(a => a.text == AppConstants.ExperienceQuestion))?.FirstOrDefault();
                    SelectedCategory = category;
                    Position = category.questions.IndexOf(category.questions.Find(question => question.text == AppConstants.ExperienceQuestion));
                    DependencyService.Get<IToastMsg>().ShortAlert(AppConstants.ExperienceMsg);
                    return;
                }

                if (string.IsNullOrWhiteSpace(questionAnswerModels.Find(data => data.QuestionText == AppConstants.RoleQuestion).OptionText))
                {

                    Category category = EventModel.Where(itm => itm.questions.Any(a => a.text == AppConstants.RoleQuestion))?.FirstOrDefault();
                    SelectedCategory = category;
                    Position = category.questions.IndexOf(category.questions.Find(question => question.text == AppConstants.RoleQuestion));
                    DependencyService.Get<IToastMsg>().ShortAlert(AppConstants.RolevalidationMsg);
                    return;
                }

                if (string.IsNullOrWhiteSpace(questionAnswerModels.Find(data => data.QuestionText == AppConstants.FreeTextQuestion).OptionText))
                {

                    Category category = EventModel.Where(itm => itm.questions.Any(a => a.text == AppConstants.FreeTextQuestion))?.FirstOrDefault();
                    SelectedCategory = category;
                    Position = category.questions.IndexOf(category.questions.Find(question => question.text == AppConstants.FreeTextQuestion));
                    DependencyService.Get<IToastMsg>().ShortAlert(AppConstants.FreeTextValidationMsg);
                    return;
                }

                if (string.IsNullOrWhiteSpace(questionAnswerModels.Find(data => data.QuestionText == AppConstants.StressLevelQuestion).OptionText))
                {
                    Category category = EventModel.Where(itm => itm.questions.Any(a => a.text == AppConstants.StressLevelQuestion))?.FirstOrDefault();
                    SelectedCategory = category;
                    Position = category.questions.IndexOf(category.questions.Find(question => question.text == AppConstants.StressLevelQuestion));
                    DependencyService.Get<IToastMsg>().ShortAlert(AppConstants.StressLevelValidationMsg);
                    return;
                }

                questionAnswerModels = questionAnswerModels?.Where(item => !string.IsNullOrWhiteSpace(item.OptionText)).ToList();
                var answer_stresstype = questionAnswerModels.Find(data => data.QuestionText == AppConstants.StressLevelQuestion);
                switch (answer_stresstype.OptionText)
                {
                    case "Mild":
                        answer_stresstype.Value = 1;
                        break;
                    case "Moderate":
                        answer_stresstype.Value = 2;
                        break;
                    case "High":
                        answer_stresstype.Value = 3;
                        break;
                    case "Severe":
                        answer_stresstype.Value = 4;
                        break;
                    case "Very Severe":
                        answer_stresstype.Value = 5;
                        break;
                    default:
                        break;
                }



                var AnswerModal = new RequestEventAnswerSubmitModel
                {
                    EventDate = DateTime.Now.ToString("yyyy-MM-dd" + "T" + "HH:mm:ss"),
                    QuestionAnswerModels = questionAnswerModels
                };
               
                List<Event_Question_AnswersModel> Answerdata = await SaveDataLocalDB(questionAnswerModels, AnswerModal);
                if (Answerdata == null)
                    return;

                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    HomeViewModel.Instance.IsLoading = true;
                    await App.SyncOfflineQuestion(new ConnectivityChangedEventArgs(Connectivity.NetworkAccess,null));
                    ResponseSubmitEventModel responseSubmitEvent = await ApiService.PostApiAsyc<RequestEventAnswerSubmitModel, ResponseSubmitEventModel>(AppConstants.SubmitEventDataUri, AnswerModal);
                    HomeViewModel.Instance.IsLoading = false;
                    if (responseSubmitEvent == null || !string.IsNullOrWhiteSpace(responseSubmitEvent?.title))
                    {
                        
                        Preferences.Set(AppConstants.SyncFlagPrefrence, true);

                        //  await App.NaviationPage.DisplayAlert("", AppConstants.GenralError, AppConstants.OkStr);
                        return;
                    }

                    HomeViewModel.Instance.IsLoading = false;
                }
                else
                {
                    Preferences.Set(AppConstants.SyncFlagPrefrence, true);
                }

                DependencyService.Get<IToastMsg>().ShortAlert(AppConstants.EventSuccessMessage);
                HomeViewModel.Instance.TabSelectIndex = 0;
            }
            catch (Exception ex)
            {
                HomeViewModel.Instance.IsLoading = false;
                Crashes.TrackError(ex);
              //  await App.NaviationPage.DisplayAlert("", AppConstants.GenralError, AppConstants.OkStr);
            }
        }

        private static async Task<List<Event_Question_AnswersModel>> SaveDataLocalDB(List<QuestionAnswerModel> questionAnswerModels, RequestEventAnswerSubmitModel AnswerModal)
        {
            try
            {
                var eventtypeid = questionAnswerModels.Find(data => data.QuestionText == AppConstants.EventQuestion).OptionId;
                var EventModal = new EventModel
                {
                    EventDate = AnswerModal.EventDate,
                    EventTypeId = eventtypeid,
                    UserId = Convert.ToInt32(App.PersonalDetail.UUID),
                    IsSync = (Connectivity.NetworkAccess == NetworkAccess.Internet)
                };
                await AppDatabase.InsertItem<EventModel>(EventModal);

                var eventlist = await AppDatabase.GetItemsAsync<EventModel>();
                AnswerModal.ID = eventlist.Last().EventId;

                var eventid = eventlist.Last().EventId;

                await CallSentimentalApi(questionAnswerModels);

                var Answerdata = AnswerModal?.QuestionAnswerModels.Select(obj => new Event_Question_AnswersModel
                {
                    AnswerText = obj.OptionText,
                    EventId = eventid,
                    OptionId = obj.OptionId,
                    QuestionId = obj.QuestionId,
                    QuestionText = obj.QuestionText,
                    value = obj.Value,
                    SentimentalValue = obj.SentimentalValue
                }).ToList();

                for (int i = 0; i < Answerdata.Count; i++)
                {
                    await AppDatabase.InsertItem<Event_Question_AnswersModel>(Answerdata[i]);
                    var list_itm = await AppDatabase.GetItemsAsync<Event_Question_AnswersModel>();
                    var last = list_itm.Last();
                    AnswerModal.QuestionAnswerModels.Find(Answerdata => Answerdata.QuestionText == last.QuestionText).ID = last.AnswerId;
                }

                return Answerdata;
            }
            catch(Exception ex)
            {
                Crashes.TrackError(ex);
                return null;
            }
        }

        private static async Task CallSentimentalApi(List<QuestionAnswerModel> questionAnswerModels)
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                var FreetextObject = questionAnswerModels.Find(freetextobj => freetextobj.OptionId == -1 && !string.IsNullOrWhiteSpace(freetextobj.OptionText));
                if (FreetextObject != null)
                {
                    var request = new RequestAzureSentimentModel
                    {
                        documents = new List<Document>
                                {
                                    new Document
                                    {
                                        id="1",
                                        language="en",
                                        text=FreetextObject.OptionText
                                    }

                                }
                    };
                    HomeViewModel.Instance.IsLoading = true;
                    ResponseAzureSentimentModel responseAzureSentiment = await ApiService.Azure_PostAsync<RequestAzureSentimentModel, ResponseAzureSentimentModel>(AppConstants.Azure_Sentiment_Uri, request);
                    HomeViewModel.Instance.IsLoading = false;

                    if (responseAzureSentiment?.documents != null)
                    {
                        var sentimentalEnum = SentimentalEnum.Unknown;
                        Enum.TryParse(responseAzureSentiment.documents.FirstOrDefault().sentiment, out sentimentalEnum);
                        FreetextObject.SentimentalValue = sentimentalEnum;
                    }
                }
            }
            else
            {
                Preferences.Set(AppConstants.SyncFlagPrefrence, true);
            }
        }

        public ICommand SubmitEventCommand { get; set; }

        private async void CallApiMethod()
        {
            try
            {

                /// Api call section
                //HomeViewModel.Instance.IsLoading = true;
                //List<PersonalDetailModel> data = await AppDatabase.GetItemsAsync<PersonalDetailModel>();
                //List<Category> getEventModal = await ApiService.GetApiAsync<List<Category>>(string.Format(AppConstants.GetEventDataUri, data[0]?.OrgnizationCode));
                //EventModel =new ObservableCollection<Category>(getEventModal);
                //HomeViewModel.Instance.IsLoading = false;

                //return;


                var a = await AppDatabase.GetAllWithChildrenAsync<QuestionModel>();
                var b = await AppDatabase.GetAllWithChildrenAsync<QuestionCategoryModel>();
                var c = await AppDatabase.GetAllWithChildrenAsync<TypeModel>();
                var d = await AppDatabase.GetAllWithChildrenAsync<Sector_Question_OptionModel>();
                var e = await AppDatabase.GetAllWithChildrenAsync<EventTypeModel>();
                var f = await AppDatabase.GetAllWithChildrenAsync<EventModel>();
                var g = await AppDatabase.GetAllWithChildrenAsync<Event_Question_AnswersModel>();


                EventModel?.Clear();
                b.ForEach((item) =>
                {
                    Category item1 = new Category
                    {
                        categoryId = item.QuestionCategoryId,
                        categoryName = item.QuestionCategoryName,
                    };
                    var questions = a.Where(question => question.QuestionCategoryId == item.QuestionCategoryId).ToList();
                    questions.ForEach(item2 =>
                    {
                        if (item1.questions == null)
                            item1.questions = new List<Question>();
                        Question item3 = new Question
                        {
                            text = item2.Text,
                            questionId = item2.QuestionId,
                        };
                        var tabletype = c.Find(type => type.TypeId == item2.QuestionTypeId);
                        item3.questionType = new QuestionType
                        {
                            isMultipleChoice = tabletype.IsMultipleChoice,
                            typeName = tabletype.TypeName,
                            typeId = tabletype.TypeId
                        };
                        if (item2.Text == AppConstants.EventQuestion)
                        {
                            e.ForEach(item =>
                            {
                                var EventOption = new QuestionOption
                                {
                                    optionId = item.EventTypeId,
                                    optionText = item.EventType
                                };
                                if (item3.questionOptions == null)
                                    item3.questionOptions = new List<QuestionOption>();
                                item3.questionOptions.Add(EventOption);
                            });

                        }
                        else
                        {
                            var options = d.Where(opt => opt.Questionid == item2.QuestionId).ToList();
                            options.ForEach(item4 =>
                            {
                                var optiontemp = new QuestionOption
                                {
                                    optionId = item4.SectorOptionId,
                                    optionText = item4.OptionText
                                };
                                if (item3.questionOptions == null)
                                    item3.questionOptions = new List<QuestionOption>();

                                item3.questionOptions.Add(optiontemp);
                            });


                        }
                        if (item2.Text == AppConstants.RoleQuestion
                        || item2.Text == AppConstants.ExperienceQuestion
                        || item2.Text == AppConstants.StressLevelQuestion
                        || item2.Text == AppConstants.FreeTextQuestion
                        || item2.Text==AppConstants.EventQuestion)
                            item3.IsMandatory = true;
                        item1.questions.Add(item3);
                    });
                    if (EventModel == null)
                        EventModel = new ObservableCollection<Category>();
                    if (f != null && f?.Count != 0 && g != null && g?.Count != 0 && item1.categoryName==AppConstants.AboutYouCategory)
                    {
                        var last_event_data = f.Last();
                        var answer_list = g.Where(data => data.EventId == last_event_data.EventId).ToList();
                        Event_Question_AnswersModel event_Question_AnswersModel = answer_list.Find(ans => ans.QuestionText == AppConstants.ExperienceQuestion);
                        item1.questions.Find(question => question.text == AppConstants.ExperienceQuestion).OptionText = event_Question_AnswersModel?.AnswerText;
                        item1.questions.Find(question => question.text == AppConstants.ExperienceQuestion).OptionId = answer_list.Find(ans => ans.QuestionText == AppConstants.ExperienceQuestion).OptionId;
                        item1.questions.Find(question => question.text == AppConstants.RoleQuestion).OptionId = answer_list.Find(ans => ans.QuestionText == AppConstants.RoleQuestion).OptionId;
                        item1.questions.Find(question => question.text == AppConstants.RoleQuestion).OptionText = answer_list.Find(ans => ans.QuestionText == AppConstants.RoleQuestion).AnswerText;
                    }
                    EventModel.Add(item1);
                });
                if (EventModel != null && EventModel?.Count != 0)
                    SelectedCategory = EventModel[0];
            }
            catch (Exception ex)
            {
                HomeViewModel.Instance.IsLoading = false;
                Crashes.TrackError(ex);
            }
        }

        private void AddEventMethod(object obj)
        {

        }
    }
    public class EventData : BaseViewModel
    {
        private ObservableCollection<string> questionText;

      
        public string CatogaryName { get; set; }
        public ObservableCollection<string> QuestionText { get => questionText; set { questionText = value; OnPropertyChanged(); } }
    }

}
