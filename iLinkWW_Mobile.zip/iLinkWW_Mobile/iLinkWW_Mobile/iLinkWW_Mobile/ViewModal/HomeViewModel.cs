﻿using iLinkWW_Mobile.Api;
using iLinkWW_Mobile.Database;
using iLinkWW_Mobile.Models;
using iLinkWW_Mobile.Utils;
using iLinkWW_Mobile.Views;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using Plugin.Fingerprint;
using Plugin.Fingerprint.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace iLinkWW_Mobile.ViewModal
{
    public class HomeViewModel : BaseViewModel
    {
        private int tabSelectIndex = 0;
        private bool isLoading;

        public ICommand ProfileIndexChanged { get; set; }
        public ICommand SelectIndexchanged { get; set; }

        public ICommand ConnectIndexChanged { get; set; }

        public ICommand ReviewIndexChanged { get; set; }
        public bool IsLoading { get => isLoading; set { isLoading = value;
                OnPropertyChanged();
            } }
        public static HomeViewModel Instance { get; set; }
        public ICommand PlusButtonCommand { get; set; }

        public ICommand OnApperingCommand { get; set; }
        public ICommand InitEventCommand { get; set; }

        public int TabSelectIndex { get => tabSelectIndex; set { tabSelectIndex = value; OnPropertyChanged(); } }

        private string Flag;
        public HomeViewModel(string flag)
        {
            Analytics.TrackEvent(DateTime.Now.ToString() + "HomeViewModal start");
            Flag = flag;
            PlusButtonCommand = new Command(PlusButtonMethod);
            OnApperingCommand = new Command(OnApperingMethod);
            SelectIndexchanged = new Command(SelectIndexchangedMethod);
            Instance = this;
            FillocalDatabase();
            //if(Flag!= "Route_Login" && Flag!="Route_Reg")
            ////Finger_Print();

        }

        private void SelectIndexchangedMethod(object obj)
        {
            ProfileIndexChanged?.Execute(null);
            ConnectIndexChanged?.Execute(null);
            ReviewIndexChanged?.Execute(null);
        }

        private void OnApperingMethod(object obj)
        {
           
        }

        private async void Finger_Print()
        {
            try
            {
                var request = new AuthenticationRequestConfiguration("Prove you have fingers!", "Because without it you can't have access");
                request.AllowAlternativeAuthentication = true;
                var result = await CrossFingerprint.Current.AuthenticateAsync(request);
                if (result.Authenticated)
                {

                }
                else
                {
                    App.NaviationPage.Navigation.InsertPageBefore(new LoginPage(AppConstants.Home_Route), App.NaviationPage.Navigation.NavigationStack[0]);
                    await App.NaviationPage.Navigation.PopToRootAsync();
                }
            }
            catch(Exception ex)
            {
                Crashes.TrackError(ex);
            }
        }



        private async void FillocalDatabase()
        {
            try
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    var Event_Data = await AppDatabase.GetItemsAsync<EventModel>();
                    List<PersonalDetailModel> data = await AppDatabase.GetItemsAsync<PersonalDetailModel>();
                    if (data==null || data?.Count == 0)
                    {
                        return;
                    }
                        ResponseSyncGetTableDataModal responseSync = await ApiService.GetApiAsync<ResponseSyncGetTableDataModal>(string.Format(iLinkWW_Mobile.Utils.AppConstants.DataGetSyncUri,data[0].UUID, 0));
                    
                        var sync_data = responseSync?.SYNCED_DATA?.FirstOrDefault();
                    if (sync_data == null || sync_data?.MetaData == null)
                    {   
                        return;
                    }
                    var Sync = sync_data.MetaData.Sync?.FirstOrDefault();
                    var MetaData_List = await AppDatabase.GetItemsAsync<DBMetaDataModel>();
                    if (MetaData_List.Count == 0)
                    {
                        IsLoading = true;
                        await AppDatabase.InsertItem<DBMetaDataModel>(Sync);
                        await AppDatabase.FillingData(sync_data);
                        IsLoading = false;
                    }
                    else
                    {
                        var Sync_MetaData = MetaData_List.FirstOrDefault();
                        if (Sync_MetaData.Version != Sync.Version)
                        {
                            IsLoading = true;
                            await AppDatabase.UpdateItem<DBMetaDataModel>(Sync);
                            sync_data.EventType?.ForEach(async (itm) =>
                            {
                                switch (itm.Operation)
                                {
                                    case "U":
                                        await AppDatabase.UpdateItem(itm);
                                        break;
                                    case "I":
                                        await AppDatabase.InsertItem<EventTypeModel>(itm);
                                        break;
                                    case "D":
                                        await AppDatabase.DeleteAsync(itm);
                                        break;
                                };
                            });
                            sync_data.Questions?.ForEach(async (itm) =>
                            {
                                switch (itm.Operation)
                                {
                                    case "U":
                                        await AppDatabase.UpdateItem(itm);
                                        break;
                                    case "I":
                                        await AppDatabase.InsertItem<QuestionModel>(itm);
                                        break;
                                    case "D":
                                        await AppDatabase.DeleteAsync(itm);
                                        break;
                                };
                            });

                            sync_data.Question_Categories?.ForEach(async (itm) =>
                            {
                                switch (itm.Operation)
                                {
                                    case "U":
                                        await AppDatabase.UpdateItem(itm);
                                        break;
                                    case "I":
                                        await AppDatabase.InsertItem<QuestionCategoryModel>(itm);
                                        break;
                                    case "D":
                                        await AppDatabase.DeleteAsync(itm);
                                        break;
                                };
                            });

                            sync_data.Question_Types?.ForEach(async (itm) =>
                            {
                                switch (itm.Operation)
                                {
                                    case "U":
                                        await AppDatabase.UpdateItem(itm);
                                        break;
                                    case "I":
                                        await AppDatabase.InsertItem<TypeModel>(itm);
                                        break;
                                    case "D":
                                        await AppDatabase.DeleteAsync(itm);
                                        break;
                                };
                            });

                            sync_data.Sector_Question_Options?.ForEach(async (itm) =>
                            {
                                switch (itm.Operation)
                                {
                                    case "U":
                                        await AppDatabase.UpdateItem(itm);
                                        break;
                                    case "I":
                                        await AppDatabase.InsertItem<Sector_Question_OptionModel>(itm);
                                        break;
                                    case "D":
                                        await AppDatabase.DeleteAsync(itm);
                                        break;
                                };
                            });
                            IsLoading = false;
                        }
                    }
                }
                Analytics.TrackEvent(DateTime.Now.ToString() + "FillLocalDatabase End");
             }
            catch(Exception ex)
            {
                IsLoading = false;
                Crashes.TrackError(ex);
            }

        }

        private void PlusButtonMethod(object obj)
        {
            TabSelectIndex = 4;
            InitEventCommand?.Execute(null);
        }
    }
}
