﻿using iLinkWW_Mobile.Api;
using iLinkWW_Mobile.Database;
using iLinkWW_Mobile.Interface;
using iLinkWW_Mobile.Models;
using iLinkWW_Mobile.Utils;
using Microsoft.AppCenter.Crashes;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace iLinkWW_Mobile.ViewModal
{
    public class ConnectViewModel : BaseViewModel
    {
        private bool firstconnectmsgsvisible;

        public bool First_ConnectMsgsVisible
        {
            get { return firstconnectmsgsvisible; }
            set
            {
                firstconnectmsgsvisible = value;
                OnPropertyChanged();
            }
        }

        private bool first_userreply;
        private OrgnizationSupportDetailModel supportdetail;

        


        public bool First_UserReplyVisible
        {
            get { return first_userreply; }
            set
            {
                first_userreply = value;
                OnPropertyChanged();
            }
        }

        private string first_userReplytext;

        public string First_UserReplyText
        {
            get { return first_userReplytext; }
            set
            {
                first_userReplytext = value;
                OnPropertyChanged();
            }
        }


        private bool second_connectMsgvisible;
        private int previoustab;
        private ObservableCollection<OrganizationSupportTypeModel> organizationSupporttype1;

        public bool Second_ConnectMsgVisible
        {
            get { return second_connectMsgvisible; }
            set
            {
                second_connectMsgvisible = value;
                OnPropertyChanged();
            }
        }

      

        private string myVar;

        public string MyProperty
        {
            get { return myVar; }
            set { myVar = value; }
        }



        public ICommand BuddyCommand { get; set; }
        public ICommand CounsellorCommand { get; set; }
        public ICommand OfficialCommand { get; set; }
        public ICommand SpritualCommand { get; set; }

        public ICommand EmailSentCommand { get; set; }

        public ICommand MassegeSentCommand { get; set; }

        public ICommand SupportTypeClickCommand { get; set; }

        public ObservableCollection<OrganizationSupportTypeModel> organizationSupporttype { get => organizationSupporttype1; set { organizationSupporttype1 = value; OnPropertyChanged(); } }
        public ObservableCollection<OrgnizationSupportDetailModel> orgnizationSupportDetails { get; set; }


        public ConnectViewModel()
        {
            
            First_ConnectMsgsVisible = true;
            BuddyCommand = new Command(BuddyMethod);
            CounsellorCommand = new Command(CounsellorMethod);
            OfficialCommand = new Command(OfficialMethod);
            SpritualCommand = new Command(SpritualMethod);
            EmailSentCommand = new Command(EmailSentMethod);
            MassegeSentCommand = new Command(MassegeSentMethod);
            SupportTypeClickCommand = new Command(SupportTypeClickMethod);
            HomeViewModel.Instance.ConnectIndexChanged = new Command(TabSelectMethod);
           // InitMethod();
        }

        private void SupportTypeClickMethod(object obj)
        {
            var itm= obj as OrganizationSupportTypeModel;
            if (itm == null)
                return;
             supportdetail = orgnizationSupportDetails.Where(a => a.SupportType == itm.Id).FirstOrDefault();
            First_UserReplyVisible = true;
            Second_ConnectMsgVisible = true;
            First_UserReplyText = itm.SupportType;
        }

        private async void TabSelectMethod(object obj)
        {
            if (HomeViewModel.Instance.TabSelectIndex == 3 && previoustab != 3)
            {
                await InitMethod();
                First_UserReplyVisible = false;
                Second_ConnectMsgVisible = false;
            }
            previoustab = HomeViewModel.Instance.TabSelectIndex;
        }

        private async Task InitMethod()
        {
            HomeViewModel.Instance.IsLoading = true;
            organizationSupporttype = new ObservableCollection<OrganizationSupportTypeModel>(await AppDatabase.GetItemsAsync<OrganizationSupportTypeModel>());
            orgnizationSupportDetails = new ObservableCollection<OrgnizationSupportDetailModel>(await AppDatabase.GetItemsAsync<OrgnizationSupportDetailModel>());
            HomeViewModel.Instance.IsLoading = false;

        }

        private async void MassegeSentMethod(object obj)
        {
            try
            {
                if (Connectivity.NetworkAccess != NetworkAccess.Internet)
                {
                    await App.NaviationPage.DisplayAlert("", AppConstants.InternetConnectionText, AppConstants.OkStr);
                    return;
                }
                if (supportdetail == null)
                    return;
                HomeViewModel.Instance.IsLoading = true;
                ResponseGetGuid_Mail getGuid_Mail = await ApiService.GetApiAsync<ResponseGetGuid_Mail>(string.Format(AppConstants.GetEmailGuid_userUri, App.PersonalDetail.UserID));
                HomeViewModel.Instance.IsLoading = false;
                if (string.IsNullOrWhiteSpace(getGuid_Mail.profileReportURI))
                {
                    // await App.NaviationPage.DisplayAlert("", AppConstants.GenralError, AppConstants.OkStr);
                    return;
                }
                var Smsmsg = new SmsMessage(AppConstants.MsgBodyTemplate,supportdetail.ContactNumber);
                await Sms.ComposeAsync(Smsmsg);
                HomeViewModel.Instance.TabSelectIndex = 0;
            }
            catch(FeatureNotSupportedException ex)
            {
                HomeViewModel.Instance.IsLoading = false;
                DependencyService.Get<IToastMsg>().ShortAlert(AppConstants.MsgNotSupportedErrorMsg);
            }
            catch (Exception ex)
            {
                HomeViewModel.Instance.IsLoading = false;
                Crashes.TrackError(ex);
                //   await App.NaviationPage.DisplayAlert("", AppConstants.GenralError, AppConstants.OkStr);
            }
        }

        private async void EmailSentMethod(object obj)
        {
            try
            {
                if (Connectivity.NetworkAccess != NetworkAccess.Internet)
                {
                    await App.NaviationPage.DisplayAlert("", AppConstants.InternetConnectionText, AppConstants.OkStr);
                    return;
                }
                if (supportdetail == null)
                    return;
                HomeViewModel.Instance.IsLoading = true;
                ResponseGetGuid_Mail getGuid_Mail = await ApiService.GetApiAsync<ResponseGetGuid_Mail>(string.Format(AppConstants.GetEmailGuid_userUri, App.PersonalDetail.UserID));
                HomeViewModel.Instance.IsLoading = false;
                if (string.IsNullOrWhiteSpace(getGuid_Mail.profileReportURI))
                {
                    //  await App.NaviationPage.DisplayAlert("", AppConstants.GenralError, AppConstants.OkStr);
                    return;
                }
                var emailmsg = new EmailMessage
                {
                    Subject = AppConstants.EmailTitleTemplate,
                    Body = string.Format(AppConstants.EmailBodyTemplate, string.Format(AppConstants.Email_ContentUri, getGuid_Mail.profileReportURI)),
                    To = new List<string>
                {
                    supportdetail.Email
                }
                };
                await Email.ComposeAsync(emailmsg);
                HomeViewModel.Instance.TabSelectIndex = 0;
            }
            catch(FeatureNotSupportedException ex)
            {
                HomeViewModel.Instance.IsLoading = false;
                DependencyService.Get<IToastMsg>().ShortAlert(AppConstants.EmailNotSupporedErrorMsg);
            }
            catch (Exception ex)
            {
                HomeViewModel.Instance.IsLoading = false;
                Crashes.TrackError(ex);
                // await App.NaviationPage.DisplayAlert("", AppConstants.GenralError, AppConstants.OkStr);
            }
        }

        private void SpritualMethod(object obj)
        {
            First_UserReplyVisible = true;
            Second_ConnectMsgVisible = true;
            First_UserReplyText = "Spritual";
        }

        private void OfficialMethod(object obj)
        {
            First_UserReplyVisible = true;
            Second_ConnectMsgVisible = true;
            First_UserReplyText = "Official";
        }

        private void CounsellorMethod(object obj)
        {
            First_UserReplyVisible = true;
            Second_ConnectMsgVisible = true;
            First_UserReplyText = "Counselllor";
        }

        private void BuddyMethod(object obj)
        {
            First_UserReplyVisible = true;
            Second_ConnectMsgVisible = true;
            First_UserReplyText = "Buddy";
        }
    }
}
