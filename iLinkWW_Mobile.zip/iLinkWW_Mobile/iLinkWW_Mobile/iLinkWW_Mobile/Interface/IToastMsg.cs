﻿using System;
using System.Collections.Generic;
using System.Text;

namespace iLinkWW_Mobile.Interface
{
   public interface IToastMsg
    {
        void LongAlert(string message);
        void ShortAlert(string message);
    }
}
