﻿using iLinkWW_Mobile.Models;
using iLinkWW_Mobile.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace iLinkWW_Mobile.CustomControls
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CustomEventlListCellView : StackLayout
    {

        #region AnswerObjects (Bindable ObservableCollection<QuestionAnswerModel>)
        public static readonly BindableProperty AnswerObjectsProperty =
            BindableProperty.Create(propertyName: "AnswerObjects",
                                    returnType: typeof(ObservableCollection<QuestionAnswerModel>),
                                    declaringType: typeof(CustomEventlListCellView),
                                    defaultValue:null,
                                    defaultBindingMode:BindingMode.TwoWay,
                                    propertyChanged:OnPropertyChanged);

        private static void OnPropertyChanged(BindableObject bindable, object oldValue, object newValue)
        {
            
        }

        public ObservableCollection<QuestionAnswerModel> AnswerObjects
        {
            get 
            { 
                return  (ObservableCollection<QuestionAnswerModel>)GetValue(AnswerObjectsProperty); 
            }
            set 
            { 
                SetValue(AnswerObjectsProperty, value);
            }
        }
        #endregion AnswerObjects (Bindable IList<QuestionAnswerModel>)




        List<Frame> OptionFrame = new List<Frame>();

        QuestionAnswerModel QuestionAnswerModel;
        public CustomEventlListCellView()
        {
            InitializeComponent();
        }

        protected override void OnBindingContextChanged()
        {
            try
            {
                base.OnBindingContextChanged();
                AnswerObjects = ((Category)BindingContext).AnswerModel;
                var binding_context = ((Category)BindingContext).questions;
                OptionFrame = new List<Frame>();
                main_stack.Children.Clear();
                AnswerObjects?.Clear();
                main_stack.Spacing = 10;
                foreach (var item in binding_context)
                {
                    QuestionAnswerModel = new QuestionAnswerModel
                    {
                        QuestionId = item.questionId,
                        QuestionText = item.text,
                        OptionId = -1,
                        OptionText = null
                    };

                    main_stack.Children.Add(new Label { Text = item.text, FontSize = (double)App.Current.Resources["SubHeaderFontSize"], TextColor = (Color)App.Current.Resources["DarkBlueColor"] });
                    if (item.questionType.typeName == "option")
                    {
                        foreach (var option in item.questionOptions)
                        {
                            var tab_gesture = new TapGestureRecognizer();
                            tab_gesture.Tapped += Tab_gesture_Tapped;
                            Frame item1 = new Frame
                            {
                                Content = new Label
                                {
                                    Text = option.optionText,
                                    TextColor = (Color)App.Current.Resources["PlaceHolderGrayColor"],
                                    FontSize = AppConstants.SubLargeFontSize,
                                    HorizontalOptions = LayoutOptions.Center,
                                    HorizontalTextAlignment = TextAlignment.Center,
                                    FontAttributes = FontAttributes.Bold,
                                },
                                ClassId = item.questionId.ToString(),
                                BackgroundColor = Color.White,
                                Padding = new Thickness(10),
                                BorderColor = (Color)App.Current.Resources["Light_Gray_Color"],
                                CornerRadius = 40,
                                BindingContext = option,
                                Margin = new Thickness(0, 10, 0, 0)
                            };
                            item1.GestureRecognizers.Add(tab_gesture);
                            OptionFrame.Add(
                            item1
                            );
                            main_stack.Children.Add(item1);
                        }
                    }
                    else if (item.questionType.typeName == "text")
                    {
                        CustomEditor customEditor = new CustomEditor
                        {
                            HeightRequest = 100,
                            Placeholder = "Write your thoughts here.."
                        };
                        customEditor.SetBinding(Editor.TextProperty, new Binding("OptionText", source: QuestionAnswerModel));
                        main_stack.Children.Add(new Frame
                        {
                            Content = customEditor,
                            CornerRadius = 15,
                            BorderColor = (Color)App.Current.Resources["Light_Gray_Color"],
                            Padding = new Thickness(10),
                        });
                        QuestionAnswerModel.OptionId = -1;
                        QuestionAnswerModel.QuestionText = item.text;
                    }

                    AnswerObjects?.Add(QuestionAnswerModel);
                }
            }
            catch(Exception)
            {

            }
        }

        private void Tab_gesture_Tapped(object sender, EventArgs e)
        {
            OptionFrame.Where(a=>a.ClassId==((Frame)sender).ClassId).ToList().ForEach((item)=>
            {
                if (item.BindingContext == ((Frame)sender).BindingContext)
                {

                    item.BackgroundColor = (Color)App.Current.Resources["Sky_Blue_Color"];
                    item.BorderColor = Color.Transparent;
                    ((Label)item.Content).TextColor = (Color)App.Current.Resources["LightBlueColor"];

                    AnswerObjects.Where(itm => itm.QuestionId.ToString() == ((Frame)sender).ClassId).FirstOrDefault().OptionId = ((QuestionOption)(((Frame)sender).BindingContext)).optionId;
                    AnswerObjects.Where(itm => itm.QuestionId.ToString() == ((Frame)sender).ClassId).FirstOrDefault().OptionText = ((QuestionOption)(((Frame)sender).BindingContext)).optionText;
                }
                else
                {
                    item.BackgroundColor = Color.White;
                    item.BorderColor = (Color)App.Current.Resources["Light_Gray_Color"];
                    ((Label)item.Content).TextColor = (Color)App.Current.Resources["PlaceHolderGrayColor"];
                }
                            
                            
            });
        }
    }
}