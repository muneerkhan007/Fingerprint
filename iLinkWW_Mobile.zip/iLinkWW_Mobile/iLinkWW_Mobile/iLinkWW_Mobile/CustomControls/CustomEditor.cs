﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace iLinkWW_Mobile.CustomControls
{
   public class CustomEditor:Editor
    {
    }
}
