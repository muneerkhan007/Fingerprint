﻿using iLinkWW_Mobile.Models;
using iLinkWW_Mobile.ViewModal;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace iLinkWW_Mobile.CustomControls
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CustomEventCarouselCellView : StackLayout
    {
        #region AnswerObjects (Bindable ObservableCollection<QuestionAnswerModel>)
        public static readonly BindableProperty AnswerObjectsProperty =
            BindableProperty.Create(propertyName: "AnswerObjects",
                                    returnType: typeof(ObservableCollection<QuestionAnswerModel>),
                                    declaringType: typeof(CustomEventlListCellView),
                                    defaultValue: null,
                                    defaultBindingMode: BindingMode.TwoWay,
                                    propertyChanged: OnPropertyChanged);

        private static void OnPropertyChanged(BindableObject bindable, object oldValue, object newValue)
        {

        }

        public ObservableCollection<QuestionAnswerModel> AnswerObjects
        {
            get
            {
                return (ObservableCollection<QuestionAnswerModel>)GetValue(AnswerObjectsProperty);
            }
            set
            {
                SetValue(AnswerObjectsProperty, value);
            }
        }
        #endregion AnswerObjects (Bindable IList<QuestionAnswerModel>)


        #region Next_Submit_Command (Bindable ICommand)
        public static readonly BindableProperty Next_Submit_CommandProperty =
            BindableProperty.Create(propertyName: nameof(Next_Submit_Command),
                                    returnType: typeof(ICommand),
                                    declaringType: typeof(CustomEventCarouselCellView),
                                    defaultValue: null);
        public ICommand Next_Submit_Command
        {
            get { return (ICommand)GetValue(Next_Submit_CommandProperty); }
            set { SetValue(Next_Submit_CommandProperty, value); }
        }
        #endregion Next_Submit_Command (Bindable ICommand)



        public CustomEventCarouselCellView()
        {
            InitializeComponent();
        }

        protected override void OnBindingContextChanged()
        {
            base.OnBindingContextChanged();
            if (BindingContext == null)
                return;
            if (((Question)BindingContext)?.questionType?.typeName == "text")
            {
                ((Question)BindingContext).OptionId = -1;
                next_sumitText.Text = "Submit";
            }
            else
            {
                ((Question)BindingContext).OptionId = -1;
                next_sumitText.Text = "Next";
            }
        }

        private void TapGestureRecognizer_Tapped(object sender, EventArgs e)
        {
            flash1.Children.ToList().ForEach(itm =>
            {
                var frame = (Frame)itm;
                if ((Frame)sender == frame)
                {
                    ((Question)BindingContext).OptionText = ((QuestionOption)((Frame)sender).BindingContext).optionText;
                    ((Question)BindingContext).OptionId = ((QuestionOption)((Frame)sender).BindingContext).optionId;
                    // ((EventViewModel)BindingContext).SelectedCategory = (iLinkWW_Mobile.Models.Category)(((Frame)sender).BindingContext);
                    frame.BackgroundColor = (Color)App.Current.Resources["Sky_Blue_Color"];
                    frame.BorderColor = Color.Transparent;
                    ((Label)frame.Content).TextColor = (Color)App.Current.Resources["LightBlueColor"];
                }
                else
                {
                    frame.BackgroundColor = Color.White;
                    frame.BorderColor = (Color)App.Current.Resources["Light_Gray_Color"];
                    ((Label)frame.Content).TextColor = (Color)App.Current.Resources["PlaceHolderGrayColor"];
                }
            });
        }

        void TapGestureRecognizer_Tapped_1(object sender, EventArgs e)
        {
            Next_Submit_Command?.Execute(null);
        }
    }
}