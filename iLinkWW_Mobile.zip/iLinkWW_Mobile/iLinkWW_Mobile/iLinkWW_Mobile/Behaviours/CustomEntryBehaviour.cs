﻿using iLinkWW_Mobile.CustomControls;
using iLinkWW_Mobile.ViewModal;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace iLinkWW_Mobile.Behaviours
{
    public class CustomEntryBehaviour : Behavior<CustomEntry>
    {
        public static readonly BindableProperty unfocusedCommandParameterProperty = BindableProperty.Create("UnFocusedCommandParameter", typeof(object), typeof(CustomEntryBehaviour));

        public object UnFocusedCommandParameter { get { return (object)GetValue(unfocusedCommandParameterProperty); } set { SetValue(unfocusedCommandParameterProperty, value); } }


        public static readonly BindableProperty UnfocusedCommandProperty = BindableProperty.Create(nameof(UnfocusedCommand), typeof(ICommand), typeof(CustomEntryBehaviour),null,BindingMode.TwoWay,propertyChanged:UnfocusedPropertyChanged);

        private static void UnfocusedPropertyChanged(BindableObject bindable, object oldValue, object newValue)
        {

        }

        //public ICommand UnfocusedCommand 
        //{   get 
        //    { 
        //        return (ICommand) GetValue(UnfocusedCommandProperty); 
        //    } 
        //    set
        //    {
        //        SetValue(UnfocusedCommandProperty, value); 
        //    }
        //}

        public ICommand UnfocusedCommand { get=>(ICommand)GetValue(UnfocusedCommandProperty); set=>SetValue(UnfocusedCommandProperty,value); }
        protected override void OnAttachedTo(CustomEntry bindable)
        {
            base.OnAttachedTo(bindable);
            bindable.Unfocused += Bindable_Unfocused;
           
        }

        protected override void OnDetachingFrom(CustomEntry bindable)
        {
            base.OnDetachingFrom(bindable);
            bindable.Unfocused -= Bindable_Unfocused;

        }

        private void Bindable_Unfocused(object sender, FocusEventArgs e)
        {
            if(UnfocusedCommand==null)
                UnfocusedCommand = ((RegistrationViewModel)((CustomEntry)sender)?.BindingContext)?.UnFocesedUserIDCommand;
            UnfocusedCommand.Execute(UnFocusedCommandParameter);
        }
    }
}
