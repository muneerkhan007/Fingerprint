﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace iLinkWW_Mobile.Utils
{
    public class AppConstants
    {
        #region Genral Text
        public static readonly string GenralError = "Please try later";
        public static readonly string OkStr = "Ok";
        public static readonly string AllfieldMendatoryText = "Please fill all mandatory field";
        public static readonly string InternetConnectionText = "Internet Connection is not available";
        public static readonly string EventQuestion = "What was the event type?";
        public static readonly string RoleQuestion = "What is your role?";
        public static readonly string FreeTextQuestion = "Say how you feel about the event in your own words";
        public static readonly string ExperienceQuestion = "What is your experience level?";
        public static readonly string StressLevelQuestion = "How would you rate the stress level of the event?";
        public static readonly string SyncFlagPrefrence = "Sync_Flag_Prefrence";
        public static readonly string SyncSentMsg = "Data sent successfully";
        public static readonly string AboutYouCategory = "About You";
        public static readonly string Home_Route= "Home_Route";
        public static readonly int MinimumPasswordValidation = 8;
        public static readonly string PasswordValidationText = $"Password must have {MinimumPasswordValidation.ToString()} letters";
        #endregion



        #region ApiConstants
        public static readonly string Scheme = "Bearer";
        public static readonly string PrfileReportBase = "https://ilinkwwweb.azurewebsites.net/";
         public static readonly string ApiBase = "https://ilinkww.azurewebsites.net/api/";
        // public static readonly string ApiBase = "https://safewaste.azurewebsites.net/api/";
        //  public static readonly string ApiBase = "https://5a930e49282a.ngrok.io/api/";
        public static readonly string VerifyUserIDUri = "users/{0}";
        public static readonly string  RegisterUri = "users";
        public static readonly string LoginUri = "Login";
        public static readonly string GetEventDataUri = "Organization/{0}";
        public static readonly string SubmitEventDataUri = "Events";
      //  public static readonly string DataGetSyncUri = "DataSync/{0}";
        public static readonly string DataGetSyncUri = "DataSync?UserId={0}&FromVersion={1}";
        public static readonly string GetEmailGuid_userUri = "users/profile-uri/{0}";
        public static readonly string Email_ContentUri = PrfileReportBase+"profile-report/{0}";
        /// <summary>
        /// azure authentication key
        /// </summary> 
        public static readonly string Azure_Authentication_Key = "59c5dbf479a64c7aa780b2fa92452e09";
        /// <summary>
        /// Azure Sentiment Uri
        /// </summary>
        public static readonly string Azure_Sentiment_Uri = "https://japanwest.api.cognitive.microsoft.com/text/analytics/v3.0/sentiment";
        #endregion

        #region FontSize Region
        /// <summary>
        /// 50
        /// </summary>
       // public static readonly double TemplateFontSize = 50;
        /// <summary>
        /// 35
        /// </summary>
      //  public static readonly double HeaderFontSize = 35;
        /// <summary>
        /// 20
        /// </summary>
       // public static readonly double SubHeaderFontSize = 20;
        /// <summary>
        /// 15
        /// </summary>
        public static readonly double NormalFontSize = 15;
        /// <summary>
        /// 18
        /// </summary>
        public static readonly double SubLargeFontSize = 18;
        /// <summary>
        /// 25
        /// </summary>
        public static readonly double LargeFontSize = 25;
        /// <summary>
        /// 30
        /// </summary>
        public static readonly double TabiconSize = 30;
        /// <summary>
        /// 30
        /// </summary>
        public static readonly double TitleFontSize = 30;
        /// <summary>
        /// 20
        /// </summary>
        public static readonly double TabLblFontSize = 20;
        #endregion



        #region LoginPageText
        public static readonly string UnAuthrizeText = "Username or password are not correct";
        public static readonly string RegisterText = "New User? Register Now";
        public static readonly string PasswordText = "Please enter valid password";
        public static readonly string UserNameText = "Please enter valid username";
        public static readonly string DeviceChangeText= "Device changed";
        

        #endregion

        #region RegisterPageText
        public static readonly string PasswordSameText = "Password and re-enter password must be same";
        public static readonly string RegisetSuccessText = "Registration successfully done!";
        public static readonly string UserIdNotVerifyText = "User ID is not valid";
        public static readonly string DisclaimerText = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Est ultricies integer quis auctor elit. Curabitur vitae nunc sed velit. Etiam dignissim diam quis enim lobortis scelerisque fermentum. Sed elementum tempus egestas sed sed risus pretium quam. Purus ut faucibus pulvinar elementum integer enim. Sagittis nisl rhoncus mattis rhoncus urna neque viverra justo nec. Pellentesque pulvinar pellentesque habitant morbi. Lectus magna fringilla urna porttitor rhoncus dolor purus non enim. Diam in arcu cursus euismod quis viverra nibh cras pulvinar." +
            "\nEget mauris pharetra et ultrices neque ornare aenean euismod elementum.Semper auctor neque vitae tempus quam pellentesque nec nam aliquam.At imperdiet dui accumsan sit.Amet nulla facilisi morbi tempus iaculis urna id volutpat lacus. Adipiscing elit ut aliquam purus sit amet luctus venenatis lectus. Et malesuada fames ac turpis egestas maecenas.In massa tempor nec feugiat nisl. Tempus egestas sed sed risus pretium. Morbi blandit cursus risus at ultrices mi tempus. Nunc mattis enim ut tellus elementum sagittis vitae et leo. Amet consectetur adipiscing elit pellentesque habitant morbi.Ac ut consequat semper viverra nam libero.Egestas purus viverra accumsan in nisl.Mi sit amet mauris commodo quis imperdiet massa. Neque vitae tempus quam pellentesque nec nam aliquam sem.Pharetra vel turpis nunc eget lorem." +
            "\nNec ultrices dui sapien eget.In massa tempor nec feugiat nisl pretium fusce id.Vulputate sapien nec sagittis aliquam malesuada. Non sodales neque sodales ut.Sed arcu non odio euismod lacinia at quis risus sed. Aliquam sem fringilla ut morbi tincidunt augue.Morbi non arcu risus quis varius quam.Id diam vel quam elementum.Commodo odio aenean sed adipiscing diam donec adipiscing tristique.Nisi est sit amet facilisis magna etiam tempor. Massa sed elementum tempus egestas sed sed.Id volutpat lacus laoreet non curabitur gravida.Netus et malesuada fames ac turpis egestas maecenas pharetra convallis. Nisl rhoncus mattis rhoncus urna.Rhoncus aenean vel elit scelerisque mauris pellentesque pulvinar pellentesque habitant. Vulputate mi sit amet mauris commodo quis imperdiet massa tincidunt." +
            "\nArcu bibendum at varius vel pharetra vel turpis nunc eget. Lectus sit amet est placerat in egestas erat imperdiet sed. Vel elit scelerisque mauris pellentesque pulvinar pellentesque.Diam volutpat commodo sed egestas egestas fringilla.Quis lectus nulla at volutpat diam ut venenatis. Posuere sollicitudin aliquam ultrices sagittis orci a scelerisque purus.Feugiat nibh sed pulvinar proin gravida hendrerit lectus a.Volutpat maecenas volutpat blandit aliquam etiam erat velit. Non curabitur gravida arcu ac tortor. Aliquet nec ullamcorper sit amet.Sit amet mauris commodo quis imperdiet massa.Tortor aliquam nulla facilisi cras fermentum odio eu. Maecenas ultricies mi eget mauris.Nisi est sit amet facilisis magna etiam tempor orci eu. Nibh sit amet commodo nulla facilisi nullam vehicula ipsum a. Diam sit amet nisl suscipit adipiscing bibendum." +
            "\nNunc consequat interdum varius sit.Ultricies integer quis auctor elit sed vulputate mi sit amet. Euismod nisi porta lorem mollis aliquam ut porttitor leo.Commodo quis imperdiet massa tincidunt nunc. Donec massa sapien faucibus et molestie. Orci eu lobortis elementum nibh tellus molestie nunc non.Nullam eget felis eget nunc.Magna fringilla urna porttitor rhoncus dolor purus.Morbi tempus iaculis urna id volutpat lacus laoreet non curabitur. Tempor orci eu lobortis elementum nibh tellus molestie. Lobortis feugiat vivamus at augue eget arcu.Pulvinar sapien et ligula ullamcorper malesuada proin libero. Cursus eget nunc scelerisque viverra mauris. Purus faucibus ornare suspendisse sed nisi lacus sed viverra.Arcu dictum varius duis at consectetur lorem donec massa.Dui sapien eget mi proin.";

        #endregion

        #region EventHomePageText
        public static readonly string AboutUsText = "ILinkWW stands for making the right connections at the right time. Connections to one’s own mental state or to external trusted parties is what this app is all about. " +
            "\nUse iLinkWW as a tool to check your moods and get suggestions to help you help yourself." +
            "\nAnything you enter is completely anonymous and will never be revealed without your consent." +
            "\nYou can trust iLinkWW to help you be kind to your mind";
        #endregion

        #region ReviewPageText
        public static readonly string PageHeader = "Review";
        public static readonly string NoDataFound = "Hooray, you're doing great! There are no suggestions needed,well done!";
        public static readonly string FirstFrame_Header = "Counsellor";
        public static readonly string FirstFrame_Body= "Your mood tracker indicates you should reach out to a Counsellor";
        public static readonly string FirstFrameCaption = "(Gathered from the last 7 events)";

        public static readonly string SecondFrameSubHeader = "Some suggestion for you:";
        public static readonly string SecondFrame_FirstPoint = "You need to get additional training to help cope with events like last week";
        public static readonly string secondFrame_SecondPoint = "You Should record at least 2 events a week";
        #endregion

        #region ProfilePageText
        public static readonly string ProfilePageHeader = "Profile";
        #endregion

        #region EventPage
        public static readonly string EventPageHeader = "Event";
        public static readonly string EventSuccessMessage = "Event successfully saved.";
        public static readonly string EventTypeValidationMsg = "Please select event type";
        public static readonly string FreeTextValidationMsg = "Please write your words";
        public static readonly string StressLevelValidationMsg = "Please select any stress level";
        public static readonly string RolevalidationMsg = "Please select your role";
        public static readonly string ExperienceMsg = "Please select your experience";
        #endregion

        #region ConnectPage
        public static readonly string ConnectPageHeader = "Connect";
        public static readonly string EmailNotSupporedErrorMsg = "Please configure email supported app";
        public static readonly string MsgNotSupportedErrorMsg = "Please configure message supported app";
        public static readonly string EmailTitleTemplate = "iLinkWW Intervention Request";
        public static readonly string EmailBodyTemplate = "I am reaching out as part of the iLinkWW intervention service. \n\n Please find a link to my profile below: \n\n {0} ";
        public static readonly string MsgBodyTemplate = "Hi \n I am reaching out as part of the iLinkWW intervention service. Please contact me at your convenience.";
        #endregion
    }
}
