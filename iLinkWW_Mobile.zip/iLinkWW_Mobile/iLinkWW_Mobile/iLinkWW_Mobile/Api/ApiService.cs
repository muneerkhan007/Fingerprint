﻿using iLinkWW_Mobile.Database;
using iLinkWW_Mobile.Models;
using iLinkWW_Mobile.Utils;
using Microsoft.AppCenter.Crashes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iLinkWW_Mobile.Api
{
    public class ApiService
    {
        public static HttpClient HttpClient{ get; set; }
        public delegate void OnTokenupdate(string tokenvalue = null);

        public static OnTokenupdate OnTokenUpdate;

        static ApiService()
        {
            HttpClient = new HttpClient();
            HttpClient.BaseAddress = new Uri(AppConstants.ApiBase);
            HttpClient.Timeout = TimeSpan.FromMinutes(5);
            HttpClient.DefaultRequestHeaders.Clear();
            OnTokenUpdate = new OnTokenupdate((token) =>
            {
                if (!string.IsNullOrWhiteSpace(token))
                    HttpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue(AppConstants.Scheme, token);
            });
            InitHttpClient();
        }

        private static async void InitHttpClient()
        {
            List<PersonalDetailModel> data = await AppDatabase.GetItemsAsync<PersonalDetailModel>();
            if (data.Count != 0)
            {
                HttpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue(AppConstants.Scheme, data[0].Api_Token);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T">Response Modal</typeparam>
        /// <param name="Url"></param>
        /// <returns></returns>
        public static async System.Threading.Tasks.Task<T> GetApiAsync<T>(string Url) where T:new()
        {
           HttpResponseMessage response=await HttpClient.GetAsync(Url);
            if (response?.Content != null)
            {
                var res=await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<T>(res);
            }
            return default(T);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T">Request Modal</typeparam>
        /// <typeparam name="F">Response Modal</typeparam>
        /// <returns></returns>
        public static async Task<F> PostApiAsyc<T, F>(string Url,T InputContent) where T : new() where F:new()
        {
            try
            {
                var a = JsonConvert.SerializeObject(InputContent);
                var Content = new StringContent(a, Encoding.UTF8, "application/json");
                HttpResponseMessage response = await HttpClient.PostAsync(Url, Content);
                if (response?.Content != null)
                {
                    var res = await response.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<F>(res);
                }
                return default(F);

            }
            catch (Exception ex)
            {
                Crashes.TrackError(ex);
                return default(F);
            }
            //HttpClient.DefaultRequestHeaders.Add("Content-Type",)
           }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T">Request Modal</typeparam>
        /// <typeparam name="F">Response Modal</typeparam>
        /// <returns></returns>

        public static async Task<F> PutApiAsync<T,F>(string Url, T InputContent) where T : new() where F : new()
        {
           var json= JsonConvert.SerializeObject(InputContent);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
           HttpResponseMessage response=await HttpClient.PutAsync(Url,content);
            if (response?.Content != null)
            {
                var res = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<F>(res);
            }
            return default(F);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T">Request Modal</typeparam>
        /// <typeparam name="F">Response Modal</typeparam>
        /// <returns></returns>

        public static async Task<F> Azure_PostAsync<T,F>(string url,T InputContent) where T : new() where F : new()
        {
            var httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Clear();
            httpClient.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", AppConstants.Azure_Authentication_Key);
            httpClient.Timeout = TimeSpan.FromMinutes(1);
            var json = JsonConvert.SerializeObject(InputContent);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
             HttpResponseMessage httpResponse=  await httpClient.PostAsync(url, content);
            if(httpResponse.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var res = await httpResponse.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<F>(res);
            }
            return default(F);
        }


    }
}