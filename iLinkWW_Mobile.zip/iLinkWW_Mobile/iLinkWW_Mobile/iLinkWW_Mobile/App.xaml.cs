﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Xamarin.Essentials;
using iLinkWW_Mobile.Views;
using iLinkWW_Mobile.Utils;
using iLinkWW_Mobile.Database;
using iLinkWW_Mobile.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using iLinkWW_Mobile.Api;
using System.Linq;
using Plugin.Fingerprint;
using Plugin.Fingerprint.Abstractions;
using Microsoft.AppCenter;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;

namespace iLinkWW_Mobile
{
    public partial class App : Application
    {
        private static PersonalDetailModel apiToken;

        public static PersonalDetailModel PersonalDetail { get => apiToken; set { apiToken = value; ApiService.OnTokenUpdate.Invoke(value?.Api_Token); } }


        public static App Instance { get; set; }
        public static NavigationPage NaviationPage { get; set; }
        public App()
        {
            try
            {
                AppCenter.Start("android=bac962d6-4768-4913-bcd1-f43f6a56c1d4;", typeof(Analytics), typeof(Crashes));
                Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense("Mjg4NzUwQDMxMzgyZTMyMmUzMGx6QngycHRWd3Z1UWZwN00rUkM1aWFtNEsrL0JscC9HSTY4dlgyK054WWM9");
                if (!Preferences.ContainsKey(AppConstants.SyncFlagPrefrence))
                    Preferences.Set(AppConstants.SyncFlagPrefrence, false);

                Instance = this;
            }
            catch (Exception ex)
            {
                Crashes.TrackError(ex);
            }
            InitializeComponent();
            AppNavigation();

        }

        // private async void AppNavigation()
        private async void AppNavigation()
        {
            Analytics.TrackEvent(DateTime.Now.ToString() + "Before check existance of PersonalDetailModel table");
            if (AppDatabase.TableExists<PersonalDetailModel>(AppDatabase.Database))
            {
                App.NaviationPage = new NavigationPage(new LoginPage());
                MainPage = App.NaviationPage;
            }
            else
            {
                AppDatabase.InitializeAsync();
                App.NaviationPage = new NavigationPage(new LoginPage());
                //Analytics.TrackEvent(DateTime.Now.ToString() + "after not existance of PersonalDetailModel  ");
                MainPage = App.NaviationPage;
            }

            // await App.Current.MainPage.DisplayAlert("", "AppNavigation_end", "Ok");
        }

        protected override void OnStart()
        {
            Connectivity.ConnectivityChanged += Connectivity_ConnectivityChanged;
            // App.Current.MainPage?.DisplayAlert("", "On_Start of app", "Ok");
        }

        private async void Connectivity_ConnectivityChanged(object sender, ConnectivityChangedEventArgs e)
        {
            try
            {
                await SyncOfflineQuestion(e);
            }
            catch (Exception ex)
            {
                Crashes.TrackError(ex);
            }
        }
        static bool isofflinesync_enter = false;
        public static async Task SyncOfflineQuestion(ConnectivityChangedEventArgs e)
        {
            try
            {
                if (isofflinesync_enter)
                    return;
                isofflinesync_enter = true;
                if (e.NetworkAccess == NetworkAccess.Internet)
                {
                    if (Preferences.ContainsKey(AppConstants.SyncFlagPrefrence))
                    {
                        if (Preferences.Get(AppConstants.SyncFlagPrefrence, false))
                        {
                            App.NaviationPage.IsBusy = true;
                            var EventList = await AppDatabase.GetItemsAsync<EventModel>();
                            var AnswerList = await AppDatabase.GetItemsAsync<Event_Question_AnswersModel>();
                            EventList.Where(item => item.IsSync == false).ToList().ForEach(async (itm) =>
                            {
                                List<QuestionAnswerModel> answerModels = new List<QuestionAnswerModel>();
                                var FreetextObject = AnswerList.Find(freetextobj => freetextobj.EventId == itm.EventId && freetextobj.OptionId == -1 && !string.IsNullOrWhiteSpace(freetextobj.AnswerText));
                                if (FreetextObject != null)
                                {
                                    var request = new RequestAzureSentimentModel
                                    {
                                        documents = new List<Document>
                                                {
                                        new Document
                                        {
                                            id="1",
                                            language="en",
                                            text=FreetextObject.AnswerText
                                        }

                                               }
                                    };
                                    ResponseAzureSentimentModel responseAzureSentiment = await ApiService.Azure_PostAsync<RequestAzureSentimentModel, ResponseAzureSentimentModel>(AppConstants.Azure_Sentiment_Uri, request);
                                    if (responseAzureSentiment?.documents != null)
                                    {
                                        var sentimentalEnum = SentimentalEnum.Unknown;
                                        Enum.TryParse(responseAzureSentiment.documents.FirstOrDefault().sentiment, out sentimentalEnum);
                                        FreetextObject.SentimentalValue = sentimentalEnum;
                                    }
                                    int a = await AppDatabase.UpdateItem<Event_Question_AnswersModel>(FreetextObject);
                                }
                                AnswerList = await AppDatabase.GetItemsAsync<Event_Question_AnswersModel>();
                                AnswerList.Where(ansObject => ansObject.EventId == itm.EventId).ToList().ForEach(obj =>
                                {
                                    answerModels.Add(new QuestionAnswerModel
                                    {
                                        ID = obj.AnswerId,
                                        OptionId = obj.OptionId,
                                        OptionText = obj.AnswerText,
                                        QuestionId = obj.QuestionId,
                                        QuestionText = obj.QuestionText,
                                        Value = obj.value,
                                        SentimentalValue = obj.SentimentalValue
                                    });
                                });
                                var requestAns = new RequestEventAnswerSubmitModel
                                {
                                    ID = itm.EventId,
                                    EventDate = itm.EventDate,
                                    QuestionAnswerModels = answerModels
                                };
                                ResponseSubmitEventModel responseSubmitEvent = await ApiService.PostApiAsyc<RequestEventAnswerSubmitModel, ResponseSubmitEventModel>(AppConstants.SubmitEventDataUri, requestAns);
                                if (responseSubmitEvent == null || !string.IsNullOrWhiteSpace(responseSubmitEvent?.title))
                                {
                                    isofflinesync_enter = false;
                                    //   await App.NaviationPage.DisplayAlert("", AppConstants.GenralError, AppConstants.OkStr);
                                    return;
                                }
                                itm.IsSync = true;
                                AppDatabase.UpdateItem(itm);
                            });
                            App.NaviationPage.IsBusy = false;
                            Preferences.Set(AppConstants.SyncFlagPrefrence, false);
                        }
                    }
                }
                isofflinesync_enter = false;
            }
            catch(Exception ex)
            {
                isofflinesync_enter = false;
                Crashes.TrackError(ex);
            }
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {

        }
    }
}
