﻿using iLinkWW_Mobile.Models;
using iLinkWW_Mobile.Utils;
using SQLite;
using SQLiteNetExtensionsAsync.Extensions;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Xamarin.Essentials;

namespace iLinkWW_Mobile.Database
{
    public class AppDatabase
    {
        public const string DatabaseFileName = "iLinkWWSQLite.db3";
        public const SQLite.SQLiteOpenFlags Flags =
       // open the database in read/write mode
       SQLite.SQLiteOpenFlags.ReadWrite |
       // create the database if it doesn't exist
       SQLite.SQLiteOpenFlags.Create |
       // enable multi-threaded database access
       SQLite.SQLiteOpenFlags.SharedCache;

        public static string DatabasePath
        {
            get
            {
                var basePath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                return Path.Combine(basePath, DatabaseFileName);
            }
        }

        public static SQLiteAsyncConnection Database { get; }
        static AppDatabase()
        {
            Database = new SQLiteAsyncConnection(DatabasePath);

        }

        public static bool TableExists<T>(SQLiteAsyncConnection connection)
        {
            try
            {
                var tableInfo = connection.GetConnection().GetTableInfo(typeof(T).Name);
                if (tableInfo.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

         public static async Task FillingData(SYNCEDDATA responseSync)
         {
            try
            {
                await AppDatabase.DeleteDataFromAllTables();
                List<EventType_Organization_QuestionValueModel> eventType_Organization_Questions = new List<EventType_Organization_QuestionValueModel>();
                if (responseSync == null)
                    return;
                responseSync.EventType.ForEach((item) =>
                {
                    eventType_Organization_Questions.Add(new EventType_Organization_QuestionValueModel
                    {
                        EventTypeId = item.EventTypeId,
                        QuestionValueId = item.QuestionId,
                        Value = responseSync?.EventType_Organization_QuestionValue?.Find(a => a.EventTypeId == item.EventTypeId)?.Value,
                    });
                });
                List<Sector_Question_OptionModel> sector_Question_Options = responseSync.Sector_Question_Options;
                await AppDatabase.InsertItems<EventType_Organization_QuestionValueModel>(eventType_Organization_Questions);
                await AppDatabase.InsertItems<Sector_Question_OptionModel>(sector_Question_Options);
                List<EventTypeModel> eventTypeModels = responseSync.EventType;
                await AppDatabase.InsertItems<EventTypeModel>(eventTypeModels);
                List<TypeModel> typeModels = responseSync?.Question_Types;
                await AppDatabase.InsertItems<TypeModel>(typeModels);
                List<QuestionCategoryModel> questionCategoryModels = responseSync?.Question_Categories;
                await AppDatabase.InsertItems<QuestionCategoryModel>(questionCategoryModels);
                List<Event_Question_AnswersModel> event_Question_Answers = responseSync?.Event_Question_Answers ?? new List<Event_Question_AnswersModel>();
                await AppDatabase.InsertItems<Event_Question_AnswersModel>(event_Question_Answers);
                var temp = await AppDatabase.GetItemsAsync<EventModel>();
                responseSync?.Events?.ForEach((item) => { item.IsSync = true; });
                await AppDatabase.InsertItems<EventModel>(responseSync.Events?? new List<EventModel>());
                var temp1 = await AppDatabase.GetItemsAsync<EventModel>();
                List<QuestionModel> questionModels = responseSync?.Questions;
                await AppDatabase.InsertItems<QuestionModel>(questionModels ?? new List<QuestionModel>());
                List<OrgnizationSupportDetailModel> detailModels = responseSync?.Organization_Support_Details;
                await AppDatabase.InsertItems<OrgnizationSupportDetailModel>(detailModels ?? new List<OrgnizationSupportDetailModel>());
                List<OrganizationSupportTypeModel> support_type_model = responseSync?.Organization_Support_Type;
                await AppDatabase.InsertItems<OrganizationSupportTypeModel>(support_type_model ?? new List<OrganizationSupportTypeModel>());



                questionCategoryModels.ForEach(async (questionCategoryModels) =>
                {
                    if (questionCategoryModels.QuestionModel == null)
                        questionCategoryModels.QuestionModel = new ObservableCollection<QuestionModel>();
                    questionCategoryModels.QuestionModel = new ObservableCollection<QuestionModel>(questionModels.Where(questionModels => questionModels.QuestionCategoryId == questionCategoryModels.QuestionCategoryId));
                    await AppDatabase.UpdateWithChildrenAsync(questionCategoryModels);
                });

                typeModels.ForEach(async (typeModels) =>
                {
                    if (typeModels.QuestionModel_Lists == null)
                        typeModels.QuestionModel_Lists = new ObservableCollection<QuestionModel>();
                    typeModels.QuestionModel_Lists = new ObservableCollection<QuestionModel>(questionModels.Where(question => question.QuestionTypeId == typeModels.TypeId));
                    await AppDatabase.UpdateWithChildrenAsync(typeModels);

                });

                questionModels.ForEach(async (questionModels) =>
                {
                    if (questionModels.sector_Question_Options == null)
                        questionModels.sector_Question_Options = new List<Sector_Question_OptionModel>();
                    if (questionModels.Text == AppConstants.EventQuestion)
                    {
                        questionModels.eventTypeModels = eventTypeModels;
                    }
                    else
                    {
                        questionModels.sector_Question_Options = sector_Question_Options.Where(Question_Option => Question_Option.Questionid == questionModels.QuestionId).ToList();
                    }
                    await AppDatabase.UpdateWithChildrenAsync(questionModels);
                });
            }
            catch(Exception ex)
            {
                Microsoft.AppCenter.Crashes.Crashes.TrackError(ex);
            }
            }

        public static async void InitializeAsync()
        {
            //await App.Current.MainPage.DisplayAlert("", "First hit", "Ok");
           await AppDatabase.CreateTables();
           //await FillingData();
            //await App.Current.MainPage.DisplayAlert("", "second hit", "Ok");
        }

        public static async Task CreateTables()
        {
            await Database?.CreateTableAsync<DBMetaDataModel>();
            await Database?.CreateTableAsync<PersonalDetailModel>();
            await Database?.CreateTableAsync<Event_Question_AnswersModel>();
            await Database?.CreateTableAsync<EventType_Organization_QuestionValueModel>();
            await Database?.CreateTableAsync<EventTypeModel>();

            await Database?.CreateTableAsync<Question_SectorModel>();
            await Database?.CreateTableAsync<EventModel>();
            await Database?.CreateTableAsync<QuestionCategoryModel>();
            await Database?.CreateTableAsync<QuestionModel>();
            await Database?.CreateTableAsync<Sector_Question_OptionModel>();
            await Database?.CreateTableAsync<TypeModel>();
            await Database?.CreateTableAsync<Stress_EventModel>();
            await Database?.CreateTableAsync<OrgnizationSupportDetailModel>();
            await Database?.CreateTableAsync<OrganizationSupportTypeModel>();
        }

        public static async Task DeleteDataFromAllTables()
        {
          //  await AppDatabase.DeleteAllDataAsyn<PersonalDetailModel>();
            await AppDatabase.Database.DropTableAsync<Event_Question_AnswersModel>();
            await AppDatabase.Database.DropTableAsync<EventModel>();
            await AppDatabase.Database.DropTableAsync<EventType_Organization_QuestionValueModel>();
            await AppDatabase.Database.DropTableAsync<EventTypeModel>();
            await AppDatabase.Database.DropTableAsync<Question_SectorModel>();
            await AppDatabase.Database.DropTableAsync<QuestionCategoryModel>();
            await AppDatabase.Database.DropTableAsync<QuestionModel>();
            await AppDatabase.Database.DropTableAsync<Sector_Question_OptionModel>();
            await AppDatabase.Database.DropTableAsync<TypeModel>();
            await AppDatabase.Database?.DropTableAsync<Stress_EventModel>();
            await AppDatabase.Database?.DropTableAsync<OrgnizationSupportDetailModel>();
            await AppDatabase.Database?.DropTableAsync<OrganizationSupportTypeModel>();
            await CreateTables();
        }

        public static async Task DropTable<T>() where T:new()
        {
            await Database.DropTableAsync<T>();
        }

        public static async Task DeleteAsync(object item)
        {
           await AppDatabase.Database.DeleteAsync(item);
        }

        public static async Task DeleteAllAsync(IEnumerable list)
        {
            await AppDatabase.Database.DeleteAllAsync(list);
        }

        public static async Task<List<T>> GetItemsAsync<T>() where T : new()
        {
            return await Database?.Table<T>().ToListAsync();
        }

        public static async Task<T> GetItemAsync<T>(string parameter, object value) where T : new()
        {
            try
            {

                var a = typeof(T).Name;
                return (await Database?.QueryAsync<T>($"SELECT * FROM {typeof(T).Name} where {parameter}=?", value?.ToString())).FirstOrDefault<T>();

            }
            catch (Exception ex)
            {

                return default(T);
            }
        }

        public static async Task<int> InsertItem<T>(T item) where T : new()
        {
            return await Database?.InsertAsync(item);
        }

        public static async Task<int> UpdateItem<T>(T item)
        {
            return await Database?.UpdateAsync(item);
        }

        public static async Task<int> DeleteAllDataAsyn<T>() where T : new()
        {
            return await Database?.ExecuteAsync($"DELETE FROM {typeof(T).Name}");
        }


        public static async Task<int> InsertItems<T>(IList<T> item) where T : new()
        {
            return await Database?.InsertAllAsync(item);
        }

        public static async Task<List<T>> QueryAsync<T>(string qurery, params string[] parameter) where T : new()
        {
            return await Database?.QueryAsync<T>(qurery, parameter);
        }

        public static async Task UpdateWithChildrenAsync(object itm)
        {
            await Database.UpdateWithChildrenAsync(itm);
        }
        public static async Task<List<T>> GetAllWithChildrenAsync<T>() where T : new()
        {
            return await Database.GetAllWithChildrenAsync<T>();
        }
        public static async Task<T> GetWithChildrenAsync<T>(object pk) where T : new()
        {
            return await Database.GetWithChildrenAsync<T>(pk);
        }
    }
}
