﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using iLinkWW_Mobile.ViewModal;
using System.Collections.ObjectModel;
using Microcharts;
using Microcharts.Forms;
using SkiaSharp;
using Syncfusion.SfChart.XForms;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Reflection;
using System.Collections.Specialized;

namespace iLinkWW_Mobile.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ProfilePage : ContentView
    {
        public ProfilePage()
        {
            InitializeComponent();
            StackingColumn100Series stackingColumn1 = new StackingColumn100Series
            {
                DataMarkerPosition = DataMarkerPosition.Center,
                XBindingPath = "Name",
                YBindingPath = "Number",
                DataMarker = new ChartDataMarker
                {
                    LabelStyle = new DataMarkerLabelStyle
                    {
                        LabelPosition = DataMarkerLabelPosition.Center
                    },
                    ShowLabel = true
                },
                Label= "Negative",
                Color =Color.Red
            };
            ((ProfileViewModel)BindingContext).NagativeData.CollectionChanged += (sender, e) =>
            {
                var collection = (ObservableCollection<ChartData>)sender;
                if (collection?.Count == 0)
                    stackingColumn1.DataMarker = new ChartDataMarker { ShowLabel = false };
                else
                {
                    if(collection.FirstOrDefault().Number==0)
                    {
                        stackingColumn1.DataMarker = new ChartDataMarker { ShowLabel = false };
                    }
                    stackingColumn1.DataMarker = new ChartDataMarker { ShowLabel = true };
                }
            };
            if (((ProfileViewModel)BindingContext)?.NagativeData?.Count == 0)
                stackingColumn1.DataMarker = new ChartDataMarker { ShowLabel = false };
            stackingColumn1.SetBinding(StackingArea100Series.ItemsSourceProperty,new Binding("NagativeData", source:((ProfileViewModel)BindingContext)));
            StackingColumn100Series stackingColumn2 = new StackingColumn100Series
            {
                DataMarkerPosition = DataMarkerPosition.Center,
                XBindingPath = "Name" ,
                YBindingPath = "Number",
                DataMarker = new ChartDataMarker
                {
                    LabelStyle=new DataMarkerLabelStyle
                    {
                        LabelPosition=DataMarkerLabelPosition.Center
                    },
                    ShowLabel = true
                },

                Label= "Neutral",

                Color = Color.Orange
            };
            ((ProfileViewModel)BindingContext).NeutralData.CollectionChanged+= (sender, e) =>
            {
                var collection = (ObservableCollection<ChartData>)sender;
                if (collection?.Count == 0)
                    stackingColumn2.DataMarker = new ChartDataMarker { ShowLabel = false };
                else
                {
                 stackingColumn2.DataMarker = new ChartDataMarker { ShowLabel = true };
                    if (collection.FirstOrDefault().Number == 0)
                    {
                        stackingColumn2.DataMarker = new ChartDataMarker { ShowLabel = false };
                    }
                }
                };
            stackingColumn2.SetBinding(StackingArea100Series.ItemsSourceProperty, new Binding("NeutralData", source: ((ProfileViewModel)BindingContext)));
            StackingColumn100Series stackingColumn3 = new StackingColumn100Series
            {
                
                XBindingPath = "Name",
                YBindingPath = "Number",
                Label= "Positive",
                DataMarkerPosition=DataMarkerPosition.Center,
                DataMarker =new ChartDataMarker {
                    LabelStyle = new DataMarkerLabelStyle
                    {
                        LabelPosition = DataMarkerLabelPosition.Center
                    },
                    ShowLabel =true,
                },
                Color=Color.Green,
            };
            ((ProfileViewModel)BindingContext).PositiveData.CollectionChanged += (sender, e) => 
            {
                var collection = (ObservableCollection<ChartData>)sender;
                if (collection?.Count == 0)
                    stackingColumn3.DataMarker = new ChartDataMarker { ShowLabel = false };
                else
                {
                    stackingColumn3.DataMarker = new ChartDataMarker { ShowLabel = true };
                    if (collection.FirstOrDefault().Number == 0)
                    {
                        stackingColumn3.DataMarker = new ChartDataMarker { ShowLabel = false };
                    }
                }
                };
            stackingColumn3.SetBinding(StackingArea100Series.ItemsSourceProperty, new Binding("PositiveData", source: ((ProfileViewModel)BindingContext)));
            chart1.Series.Add(stackingColumn1);
            chart1.Series.Add(stackingColumn2);
            chart1.Series.Add(stackingColumn3);
        }
    }
}