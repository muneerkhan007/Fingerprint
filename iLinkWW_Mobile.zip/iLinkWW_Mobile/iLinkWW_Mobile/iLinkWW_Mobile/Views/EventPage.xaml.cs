﻿using iLinkWW_Mobile.Models;
using iLinkWW_Mobile.ViewModal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Syncfusion.SfPicker.XForms;
using Syncfusion.XForms.ComboBox;
using Microsoft.AppCenter.Crashes;
using Microsoft.AppCenter.Analytics;

namespace iLinkWW_Mobile.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class EventPage : ContentView
    {
        public static EventPage Instance { get; set; }

        #region SelectedCategory (Bindable Category)
        public static readonly BindableProperty SelectedCategoryProperty =
            BindableProperty.Create(propertyName: nameof(SelectedCategory),
                                    returnType: typeof(Category),
                                    declaringType: typeof(EventPage),
                                    defaultValue:null,
                                    propertyChanged:SelectedCategoryPropertyChanged);

        private static void SelectedCategoryPropertyChanged(BindableObject bindable, object oldValue, object newValue)
        {
            Instance?.selectPropertyChanged((Category)newValue);
        }

        private void selectPropertyChanged(Category selectedCategory)
        {
            flash.Children.ToList().ForEach(itm =>
            {
                var frame = (Frame)itm;
                if ((Category)frame.BindingContext == selectedCategory)
                {
                    frame.BackgroundColor = (Color)App.Current.Resources["ThemeColor"];
                    frame.BorderColor = Color.Transparent;
                }
                else
                {
                    frame.BackgroundColor = Color.Transparent;
                    frame.BorderColor = Color.FromHex("#f1f1f1");
                }
            });
        }
        public Category SelectedCategory
        {
            get { return (Category)GetValue(SelectedCategoryProperty); }
            set { SetValue(SelectedCategoryProperty, value); }
        }
        #endregion MyProperty (Bindable Category)


        public EventPage()
        {
            InitializeComponent();
            Instance = this;
        }

        protected override void OnBindingContextChanged()
        {
            base.OnBindingContextChanged();
        }

        private void TapGestureRecognizer_Tapped(object sender, EventArgs e)
        {
            flash.Children.ToList().ForEach(itm =>
            {
                var frame = (Frame)itm;
                if ((Frame)sender == frame)
                {
                    ((EventViewModel)BindingContext).SelectedCategory = (iLinkWW_Mobile.Models.Category)(((Frame)sender).BindingContext);
                    frame.BackgroundColor = (Color)App.Current.Resources["ThemeColor"];
                    frame.BorderColor = Color.Transparent;
                }
                else
                {
                    frame.BackgroundColor = Color.Transparent;
                    frame.BorderColor = Color.FromHex("#f1f1f1");
                }
            });
        }

        private void Frame_BindingContextChanged(object sender, EventArgs e)
        {
            if (((Frame)sender).BindingContext == ((EventViewModel)BindingContext).SelectedCategory)
            {
                var frame = (Frame)sender;
                frame.BackgroundColor = (Color)App.Current.Resources["ThemeColor"];
                frame.BorderColor = Color.Transparent;
            }
        }

        private void StackLayout_BindingContextChanged(object sender, EventArgs e)
        {
            var tab_gesture = new TapGestureRecognizer();
                tab_gesture.Tapped += (s, e)=>
            {

                ((SfPicker)((StackLayout)sender).Children[2]).IsOpen = true; 
            };
            ((Frame)((StackLayout)sender).Children[1]).GestureRecognizers.Add(tab_gesture);
            if (((StackLayout)sender).BindingContext == null)
                return;
           

            if(!((Question)(((StackLayout)sender).BindingContext)).questionType.isMultipleChoice)
            {
                ((Question)(((StackLayout)sender).BindingContext)).OptionId = -1;
            }
        }

        private void SfPicker_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (((SfPicker)sender).SelectedItem == null)
                return;
            Question bindingContext = (Question)((SfPicker)sender).BindingContext;
            if (bindingContext == null || (QuestionOption)((SfPicker)sender).SelectedItem==null)
                return;
            bindingContext.OptionId = ((QuestionOption)((SfPicker)sender).SelectedItem).optionId;
            bindingContext.OptionText = ((QuestionOption)((SfPicker)sender).SelectedItem).optionText;
        }

        private void picker_BindingContextChanged(object sender, EventArgs e)
        {   
            var Object = (Question)((SfPicker)sender).BindingContext;
            if (Object == null)
                return;
            if (Object.OptionId != 0 && ((Question)Object).questionType.isMultipleChoice)
            {
                QuestionOption questionOption = ((Question)Object).questionOptions.Find(a => a.optionId == Object.OptionId);
                ((SfPicker)sender).SelectedItem = questionOption;
            }
        }

        private void SfComboBox_SelectionChanged(object sender, Syncfusion.XForms.ComboBox.SelectionChangedEventArgs e)
        {
            try
            {
                Question bindingContext = (Question)((SfComboBox)sender).BindingContext;
                if (bindingContext == null || ((SfComboBox)sender).SelectedItem == null || e.Value == null)
                {
                    Analytics.TrackEvent("SfComboBox_SelectionChanged : "+ "Null item");
                    return;
                }
                bindingContext.OptionId = ((QuestionOption)e.Value).optionId;
                bindingContext.OptionText = ((QuestionOption)e.Value).optionText;
            }
            catch(Exception ex)
            {
                Crashes.TrackError(ex);
            }

        }

        private void SfComboBox_BindingContextChanged(object sender, EventArgs e)
        {
            try
            {
                Question bindingContext = (Question)((SfComboBox)sender).BindingContext;
                if (bindingContext == null || bindingContext.OptionId == 0)
                {
                    ((SfComboBox)sender).Text = "";
                    return;
                }
            ((SfComboBox)sender).SelectedItem = bindingContext.questionOptions?.Find(a => a.optionId == bindingContext.OptionId);
                ((SfComboBox)sender).Text = bindingContext.questionOptions?.Find(a => a.optionId == bindingContext.OptionId)?.optionText;
            }
            catch(Exception ex)
            {
                Crashes.TrackError(ex);
            }
        }

        private void next_sumitText_BindingContextChanged(object sender, EventArgs e)
        {
            var obj = (Question)((Label)sender).BindingContext;
            if(obj!=null)
            {
                ((Label)sender).Text = obj.questionType.isMultipleChoice ? "Next" : "Submit";
            }
        }

        private void Frame_BindingContextChanged_1(object sender, EventArgs e)
        {
            var obj = (Question)((Frame)sender).BindingContext;
            if(obj!=null)
            {
                if (!obj.questionType.isMultipleChoice)
                    obj.OptionId = -1;
            }
        }

        void SfComboBox_SelectionChanging(System.Object sender, Syncfusion.XForms.ComboBox.SelectionChangingEventArgs e)
        {
            try
            {
                Question bindingContext = (Question)((SfComboBox)sender).BindingContext;
                if (bindingContext == null || ((SfComboBox)sender).SelectedItem == null || e.Value == null)
                {
                    Analytics.TrackEvent("SfComboBox_SelectionChanged : " + "Null item");
                    return;
                }
                bindingContext.OptionId = ((QuestionOption)e.Value).optionId;
                bindingContext.OptionText = ((QuestionOption)e.Value).optionText;
            }
            catch (Exception ex)
            {
                Crashes.TrackError(ex);
            }
        }
    }
}