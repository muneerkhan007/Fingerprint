﻿using iLinkWW_Mobile.Utils;
using iLinkWW_Mobile.ViewModal;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using Plugin.Fingerprint;
using Plugin.Fingerprint.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace iLinkWW_Mobile.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class HomePage : ContentPage
    {
        public HomePage(string flag="")
        {
            try
            {
                BindingContext = new HomeViewModel(flag);
                InitializeComponent();
                Analytics.TrackEvent(DateTime.Now.ToString()+" HomePage contructor");
            }
            catch(Exception ex)
            {
                Crashes.TrackError(ex);
            }
        }


        private void TabHost_SelectedTabIndexChanged(object sender, SelectedPositionChangedEventArgs e)
        {
            ((HomeViewModel)BindingContext).SelectIndexchanged?.Execute(null);
        }

        protected async override void OnAppearing()
        {
            base.OnAppearing();
            ((HomeViewModel)BindingContext)?.OnApperingCommand?.Execute(null);
            // await App.NaviationPage.DisplayAlert("", "HomePage_Load", "Ok");
            Analytics.TrackEvent("HomePage apearing");
        }


    } 
}